import React, { useState } from 'react';
import {
  GraduationCap,
  Briefcase,
  Clock,
  Plus,
  Trash2,
  Calendar,
  Lock,
  Sparkles,
  Zap,
  CheckCircle2,
  AlertCircle,
  Coffee,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  Upload,
  AlarmClock,
  Bell,
  BellOff,
  BookOpen,
} from 'lucide-react';
import {
  CollegeClassSlot,
  CollegeConfig,
  NotificationSettings,
  SleepConfig,
  Task,
  TaskCategory,
} from '../types/routine';
import {
  calculateDurationMinutes,
  calculateFreeTimeSlots,
  formatDuration,
  formatTime12h,
} from '../utils/dateUtils';
import { Edit3, ArrowLeftRight, Check, X, Moon } from 'lucide-react';

interface CollegeTimetablePlannerProps {
  collegeConfig: CollegeConfig;
  onUpdateCollegeConfig: (config: CollegeConfig) => void;
  tasks: Task[];
  selectedDate: string;
  onAssignFreeSlot: (startTime: string, endTime: string) => void;
  onOpenUploadModal?: () => void;
  sleepConfig?: SleepConfig;
  notificationSettings?: NotificationSettings;
  onUpdateNotifications?: (settings: NotificationSettings) => void;
  onTriggerClassAlarm?: (slot: CollegeClassSlot, mode: 'end' | 'start') => void;
  activeUser?: UserAccount | null;
  onOpenAuthModal?: (reason?: string) => void;
}

const WEEKDAYS = [
  { day: 1, name: 'Monday', short: 'Mon' },
  { day: 2, name: 'Tuesday', short: 'Tue' },
  { day: 3, name: 'Wednesday', short: 'Wed' },
  { day: 4, name: 'Thursday', short: 'Thu' },
  { day: 5, name: 'Friday', short: 'Fri' },
  { day: 6, name: 'Saturday', short: 'Sat' },
];

export const CollegeTimetablePlanner: React.FC<CollegeTimetablePlannerProps> = ({
  collegeConfig,
  onUpdateCollegeConfig,
  tasks,
  selectedDate,
  onAssignFreeSlot,
  onOpenUploadModal,
  sleepConfig,
  notificationSettings,
  onUpdateNotifications,
  onTriggerClassAlarm,
  activeUser,
  onOpenAuthModal,
}) => {
  const [selectedDayTab, setSelectedDayTab] = useState<number>(() => {
    const [y, m, d] = selectedDate.split('-').map(Number);
    const day = new Date(y, m - 1, d).getDay();
    return day >= 1 && day <= 6 ? day : 1;
  });

  const [showAddClass, setShowAddClass] = useState(false);
  const [newClassName, setNewClassName] = useState('');
  const [newClassRoom, setNewClassRoom] = useState('');
  const [newClassStart, setNewClassStart] = useState('10:00');
  const [newClassEnd, setNewClassEnd] = useState('11:30');
  const [newClassType, setNewClassType] = useState<CollegeClassSlot['type']>('lecture');

  // Compute live day occupancy and free time left taking sleep into account
  const occupancy = calculateFreeTimeSlots(tasks, collegeConfig, selectedDate, sleepConfig);

  const collegePct =
    occupancy.wakingMinutes > 0
      ? Math.round((occupancy.collegeMinutes / occupancy.wakingMinutes) * 100)
      : 0;

  const routinePct =
    occupancy.wakingMinutes > 0
      ? Math.round((occupancy.routineMinutes / occupancy.wakingMinutes) * 100)
      : 0;

  const freePct = Math.max(0, 100 - collegePct - routinePct);

  // Get active day slots (fallback to default slots if no custom per-day timetable)
  const currentDaySlots =
    collegeConfig.weeklyTimetable?.[selectedDayTab] || collegeConfig.slots;

  const handleAddSlot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassName.trim()) return;

    const newSlot: CollegeClassSlot = {
      id: `slot-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: newClassName.trim(),
      room: newClassRoom.trim() || undefined,
      startTime: newClassStart,
      endTime: newClassEnd,
      type: newClassType,
      dayOfWeek: selectedDayTab,
    };

    const updatedWeekly = { ...(collegeConfig.weeklyTimetable || {}) };
    const currentList = updatedWeekly[selectedDayTab] || [...collegeConfig.slots];
    updatedWeekly[selectedDayTab] = [...currentList, newSlot].sort((a, b) =>
      a.startTime.localeCompare(b.startTime)
    );

    onUpdateCollegeConfig({
      ...collegeConfig,
      weeklyTimetable: updatedWeekly,
    });

    setNewClassName('');
    setNewClassRoom('');
    setShowAddClass(false);
  };

  // Fixed Task Editing / Swapping State
  const [editingSlot, setEditingSlot] = useState<CollegeClassSlot | null>(null);
  const [editSlotName, setEditSlotName] = useState('');
  const [editSlotRoom, setEditSlotRoom] = useState('');
  const [editSlotProfessor, setEditSlotProfessor] = useState('');
  const [editSlotStart, setEditSlotStart] = useState('10:00');
  const [editSlotEnd, setEditSlotEnd] = useState('11:30');
  const [editSlotType, setEditSlotType] = useState<CollegeClassSlot['type']>('lecture');
  const [editSlotDay, setEditSlotDay] = useState<number>(1);

  const QUICK_SWAP_SUBJECTS = [
    'Database Systems (DBMS)',
    'Operating Systems (OS)',
    'Computer Networks (CN)',
    'Data Structures & Algorithms',
    'AI & Machine Learning',
    'Software Engineering',
    'Advanced Mathematics',
    'Computer Science Lab',
    'Physics / Electronics Lab',
    'Seminar & Project Work',
    'Lunch / Refreshment Break',
  ];

  const handleStartEditSlot = (slot: CollegeClassSlot) => {
    setEditingSlot(slot);
    setEditSlotName(slot.name);
    setEditSlotRoom(slot.room || '');
    setEditSlotProfessor(slot.professor || '');
    setEditSlotStart(slot.startTime);
    setEditSlotEnd(slot.endTime);
    setEditSlotType(slot.type);
    setEditSlotDay(slot.dayOfWeek || selectedDayTab);
  };

  const handleSaveEditSlot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSlot || !editSlotName.trim()) return;

    const updatedSlot: CollegeClassSlot = {
      ...editingSlot,
      name: editSlotName.trim(),
      room: editSlotRoom.trim() || undefined,
      professor: editSlotProfessor.trim() || undefined,
      startTime: editSlotStart,
      endTime: editSlotEnd,
      type: editSlotType,
      dayOfWeek: editSlotDay,
    };

    const updatedWeekly = { ...(collegeConfig.weeklyTimetable || {}) };
    
    // Ensure all days 1..6 exist in weeklyTimetable
    WEEKDAYS.forEach((w) => {
      if (!updatedWeekly[w.day]) {
        updatedWeekly[w.day] = [...collegeConfig.slots];
      }
    });

    const sourceDay = editingSlot.dayOfWeek || selectedDayTab;
    const targetDay = editSlotDay;

    if (sourceDay === targetDay) {
      // Update in same day
      const currentList = updatedWeekly[sourceDay] || [];
      updatedWeekly[sourceDay] = currentList
        .map((s) => (s.id === editingSlot.id ? updatedSlot : s))
        .sort((a, b) => a.startTime.localeCompare(b.startTime));
    } else {
      // Swapped / moved to a different day
      const sourceList = updatedWeekly[sourceDay] || [];
      updatedWeekly[sourceDay] = sourceList.filter((s) => s.id !== editingSlot.id);

      const targetList = updatedWeekly[targetDay] || [];
      updatedWeekly[targetDay] = [...targetList, updatedSlot].sort((a, b) =>
        a.startTime.localeCompare(b.startTime)
      );
    }

    onUpdateCollegeConfig({
      ...collegeConfig,
      weeklyTimetable: updatedWeekly,
    });

    setEditingSlot(null);
  };

  const handleRemoveSlot = (slotId: string) => {
    const updatedWeekly = { ...(collegeConfig.weeklyTimetable || {}) };
    const currentList = updatedWeekly[selectedDayTab] || [...collegeConfig.slots];
    updatedWeekly[selectedDayTab] = currentList.filter((s) => s.id !== slotId);

    onUpdateCollegeConfig({
      ...collegeConfig,
      weeklyTimetable: updatedWeekly,
    });
  };

  const isJob = collegeConfig.commitmentType === 'job';

  const handleToggleCommitmentType = (type: 'college' | 'job') => {
    if (!activeUser && onOpenAuthModal) {
      onOpenAuthModal(type === 'job' ? 'Work and Job' : 'Add College Timetable');
      return;
    }
    onUpdateCollegeConfig({
      ...collegeConfig,
      commitmentType: type,
    });
  };

  const classEndAlarmEnabled = notificationSettings?.classEndAlarmEnabled !== false;
  const classStartAlarmEnabled = notificationSettings?.classStartAlarmEnabled !== false;

  const handleToggleEndAlarm = () => {
    if (!notificationSettings || !onUpdateNotifications) return;
    onUpdateNotifications({
      ...notificationSettings,
      classEndAlarmEnabled: !classEndAlarmEnabled,
      soundEnabled: !classEndAlarmEnabled ? true : notificationSettings.soundEnabled,
    });
  };

  const handleToggleStartAlarm = () => {
    if (!notificationSettings || !onUpdateNotifications) return;
    onUpdateNotifications({
      ...notificationSettings,
      classStartAlarmEnabled: !classStartAlarmEnabled,
      soundEnabled: !classStartAlarmEnabled ? true : notificationSettings.soundEnabled,
    });
  };

  const handleToggleSlotAlarm = (slotId: string) => {
    const updatedWeekly = { ...(collegeConfig.weeklyTimetable || {}) };
    const currentList = updatedWeekly[selectedDayTab] || [...collegeConfig.slots];
    updatedWeekly[selectedDayTab] = currentList.map((s) =>
      s.id === slotId ? { ...s, alarmEnabled: s.alarmEnabled === false ? true : false } : s
    );

    const updatedDefaultSlots = collegeConfig.slots.map((s) =>
      s.id === slotId ? { ...s, alarmEnabled: s.alarmEnabled === false ? true : false } : s
    );

    onUpdateCollegeConfig({
      ...collegeConfig,
      slots: updatedDefaultSlots,
      weeklyTimetable: updatedWeekly,
    });
  };

  return (
    <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl border border-slate-800/80 p-4 sm:p-5 shadow-2xl space-y-5">
      
      {/* Top Header & Free Time Left Summary */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-500/15 border border-sky-500/30 text-sky-400 flex items-center justify-center shrink-0 mt-0.5">
            {isJob ? <Briefcase className="w-5 h-5" /> : <GraduationCap className="w-5 h-5" />}
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-base font-bold text-white tracking-tight">
                {isJob ? 'Weekly Workplace Shift & Meeting Timetable' : 'Weekly College Class & Lab Timetable'}
              </h3>
              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/30">
                <Lock className="w-3 h-3 text-sky-400" />
                Fixed Schedule
              </span>

              {/* Quick Commitment Switcher Pill */}
              <div className="inline-flex items-center p-0.5 rounded-lg bg-slate-950 border border-slate-800 ml-1">
                <button
                  type="button"
                  onClick={() => handleToggleCommitmentType('college')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-bold transition-all cursor-pointer ${
                    !isJob
                      ? 'bg-sky-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="Switch to College classes mode (Prompts login if guest)"
                >
                  <GraduationCap className="w-3 h-3" />
                  <span>College</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleToggleCommitmentType('job')}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-bold transition-all cursor-pointer ${
                    isJob
                      ? 'bg-cyan-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                  title="Switch to Job / Workplace shifts mode (Prompts login if guest)"
                >
                  <Briefcase className="w-3 h-3" />
                  <span>Job / Work</span>
                </button>
              </div>

              {/* Direct Login / Account Trigger Button */}
              {onOpenAuthModal && (
                <button
                  type="button"
                  onClick={() => onOpenAuthModal(isJob ? 'Work and Job' : 'Add College Timetable')}
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[11px] font-semibold transition-all cursor-pointer ${
                    activeUser
                      ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-300 hover:bg-emerald-500/25'
                      : 'bg-amber-400/15 border-amber-400/45 text-amber-200 hover:bg-amber-400/25 shadow-sm'
                  }`}
                  title="Open Login & Cloud Sync Interface"
                >
                  <Lock className="w-3 h-3 text-amber-300" />
                  <span>{activeUser ? `Synced: ${activeUser.name}` : 'Login for Timetable & Work'}</span>
                </button>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {isJob
                ? 'Manage your fixed workplace shifts and recurring meetings for each day of the week.'
                : 'Manage your fixed college lectures, labs, and tutorials for each day of the week.'}
            </p>
          </div>
        </div>

        {/* Top After-Every-Class Alarm Option Bar */}
        <div className="flex flex-wrap items-center gap-2 bg-slate-950/90 border border-cyan-500/35 rounded-2xl p-2.5 shadow-lg shadow-cyan-950/30">
          <div className="flex items-center gap-2 pr-2 border-r border-slate-800">
            <div
              className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                classEndAlarmEnabled
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                  : 'bg-slate-900 text-slate-500 border border-slate-800'
              }`}
            >
              <AlarmClock className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[11px] font-extrabold text-white flex items-center gap-1.5">
                <span>After-Every-Class Alarm</span>
                <span
                  className={`px-1.5 py-0.2 rounded text-[9px] font-black uppercase ${
                    classEndAlarmEnabled
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {classEndAlarmEnabled ? 'Active' : 'Muted'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400">
                Rings with melodic chime &amp; learned-notes prompt after every class ends
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={handleToggleEndAlarm}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                classEndAlarmEnabled
                  ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/50 shadow-sm'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
              }`}
              title="Alert immediately when each class period finishes"
            >
              {classEndAlarmEnabled ? (
                <Bell className="w-3.5 h-3.5 text-cyan-300" />
              ) : (
                <BellOff className="w-3.5 h-3.5 text-slate-500" />
              )}
              <span>After-Class Alert: {classEndAlarmEnabled ? 'ON' : 'OFF'}</span>
            </button>

            <button
              type="button"
              onClick={handleToggleStartAlarm}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                classStartAlarmEnabled
                  ? 'bg-amber-500/20 text-amber-200 border border-amber-400/50 shadow-sm'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
              }`}
              title="Remind when each class period starts"
            >
              <Clock className="w-3.5 h-3.5 text-amber-300" />
              <span>Start Alert: {classStartAlarmEnabled ? 'ON' : 'OFF'}</span>
            </button>

            {onTriggerClassAlarm && currentDaySlots.length > 0 && (
              <button
                type="button"
                onClick={() => onTriggerClassAlarm(currentDaySlots[0], 'end')}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-indigo-500 hover:from-cyan-300 hover:to-indigo-400 text-slate-950 text-[11px] font-extrabold shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
                title="Test the After-Class Alarm chime and quick learned-notes popup now"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Test Class Alert</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* College Timetable Day-by-Day Editor */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-sky-400" />
            <h4 className="text-sm font-bold text-white tracking-wide">
              Weekly Class & Lecture Timetable
            </h4>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
            {onOpenUploadModal && (
              <button
                type="button"
                onClick={() => {
                  if (!activeUser && onOpenAuthModal) {
                    onOpenAuthModal(isJob ? 'Work and Job' : 'Add College Timetable');
                    return;
                  }
                  onOpenUploadModal();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-sky-900/50 to-indigo-900/50 hover:from-sky-800/60 hover:to-indigo-800/60 border border-sky-400/40 text-xs font-semibold text-sky-200 transition-all shadow-sm hover:scale-[1.02] cursor-pointer"
                title="Instant 1-3s AI scan of College Timetable or Work/Job Schedule (PDF / Photo)"
              >
                <Upload className="w-3.5 h-3.5 text-sky-400" />
                <span>{isJob ? 'Scan Work Schedule (PDF / Photo)' : 'Scan Timetable / Work PDF & Photo'}</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                  ⚡ Turbo AI
                </span>
              </button>
            )}

            <button
              onClick={() => {
                if (!activeUser && onOpenAuthModal) {
                  onOpenAuthModal(isJob ? 'Work and Job' : 'Add College Timetable');
                  return;
                }
                setShowAddClass(!showAddClass);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-900/40 hover:bg-sky-800/50 border border-sky-500/40 text-xs font-semibold text-sky-200 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>
                {showAddClass
                  ? 'Cancel'
                  : isJob
                  ? '+ Add Work Shift / Meeting'
                  : '+ Add Class / Lab'}
              </span>
            </button>
          </div>
        </div>

        {/* Day Tabs (Mon - Sat) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {WEEKDAYS.map((w) => {
            const isSelected = selectedDayTab === w.day;
            const daySlotCount =
              (collegeConfig.weeklyTimetable?.[w.day] || collegeConfig.slots).length;

            return (
              <button
                key={w.day}
                onClick={() => setSelectedDayTab(w.day)}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all shrink-0 ${
                  isSelected
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-600/20 ring-1 ring-sky-400'
                    : 'bg-slate-950 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <span>{w.name}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isSelected ? 'bg-sky-800 text-white' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {daySlotCount}
                </span>
              </button>
            );
          })}
        </div>

        {/* Add Class Form */}
        {showAddClass && (
          <form
            onSubmit={handleAddSlot}
            className="p-4 rounded-2xl bg-slate-950 border border-sky-500/40 space-y-3 animate-fadeIn"
          >
            <div className="text-xs font-bold text-sky-300 uppercase tracking-wider">
              Add Period to {WEEKDAYS.find((w) => w.day === selectedDayTab)?.name} Timetable:
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Subject / Class Name</label>
                <input
                  type="text"
                  required
                  value={newClassName}
                  onChange={(e) => setNewClassName(e.target.value)}
                  placeholder="e.g. Database Systems, Linear Algebra, Lab..."
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Room / Location (Optional)</label>
                <input
                  type="text"
                  value={newClassRoom}
                  onChange={(e) => setNewClassRoom(e.target.value)}
                  placeholder="e.g. Hall 302, Lab 4B"
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Start Time</label>
                <input
                  type="time"
                  required
                  value={newClassStart}
                  onChange={(e) => setNewClassStart(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">End Time</label>
                <input
                  type="time"
                  required
                  value={newClassEnd}
                  onChange={(e) => setNewClassEnd(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Session Type</label>
                <select
                  value={newClassType}
                  onChange={(e) => setNewClassType(e.target.value as any)}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-500"
                >
                  <option value="lecture">Lecture</option>
                  <option value="lab">Lab / Practical</option>
                  <option value="break">Lunch Break</option>
                  <option value="tutorial">Tutorial</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowAddClass(false)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-md transition-colors"
              >
                Save Period
              </button>
            </div>
          </form>
        )}

        {/* Timetable Class Slots List */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {currentDaySlots.map((slot) => {
            const isSlotAlarmOn = slot.alarmEnabled !== false && classEndAlarmEnabled;
            return (
              <div
                key={slot.id}
                className={`p-3 rounded-xl bg-slate-950/70 border transition-all flex flex-col justify-between gap-2 ${
                  isSlotAlarmOn
                    ? 'border-slate-800 hover:border-cyan-500/40'
                    : 'border-slate-800/60 opacity-85'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="font-bold text-white text-xs truncate flex items-center gap-1.5">
                      <span className="truncate">{slot.name}</span>
                    </div>
                    <div className="text-[11px] text-sky-400 font-mono mt-0.5 flex items-center gap-1.5">
                      <span>
                        {formatTime12h(slot.startTime)} – {formatTime12h(slot.endTime)} (
                        {calculateDurationMinutes(slot.startTime, slot.endTime)}m)
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400 flex flex-wrap items-center gap-1.5 mt-1">
                      {slot.room && <span>Room: {slot.room} •</span>}
                      <span className="capitalize px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-semibold">
                        {slot.type}
                      </span>
                      <span
                        className={`inline-flex items-center gap-1 px-1.5 py-0.2 rounded font-semibold ${
                          isSlotAlarmOn
                            ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                            : 'bg-slate-900 text-slate-500 border border-slate-800'
                        }`}
                      >
                        <AlarmClock className="w-2.5 h-2.5" />
                        {isSlotAlarmOn ? 'End Alert ON' : 'Muted'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleToggleSlotAlarm(slot.id)}
                      className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                        isSlotAlarmOn
                          ? 'text-cyan-300 hover:bg-cyan-950/60 bg-cyan-500/10'
                          : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800'
                      }`}
                      title={
                        isSlotAlarmOn
                          ? 'After-class alarm enabled for this period (click to mute)'
                          : 'After-class alarm muted for this period (click to enable)'
                      }
                    >
                      {isSlotAlarmOn ? (
                        <Bell className="w-3.5 h-3.5" />
                      ) : (
                        <BellOff className="w-3.5 h-3.5" />
                      )}
                    </button>
                    {onTriggerClassAlarm && (
                      <button
                        type="button"
                        onClick={() => onTriggerClassAlarm(slot, 'end')}
                        className="text-amber-300 hover:text-amber-200 p-1.5 rounded-lg hover:bg-amber-950/60 transition-colors cursor-pointer"
                        title="Ring After-Class Alert & log what you learned in this class"
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleStartEditSlot(slot)}
                      className="text-slate-400 hover:text-sky-300 p-1.5 rounded-lg hover:bg-sky-950/60 transition-colors cursor-pointer"
                      title="Change or swap this fixed class period"
                      aria-label="Edit or swap class period"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveSlot(slot.id)}
                      className="text-slate-500 hover:text-rose-400 p-1.5 rounded-lg hover:bg-rose-950/60 transition-colors cursor-pointer"
                      title="Remove period from timetable"
                      aria-label="Remove period"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {(slot.topic || slot.learned) && (
                  <div className="pt-1.5 border-t border-slate-800/80 text-[11px] space-y-0.5">
                    {slot.topic && (
                      <div className="text-cyan-300 font-semibold truncate">
                        Topic: {slot.topic}
                      </div>
                    )}
                    {slot.learned && (
                      <div className="text-slate-400 line-clamp-1 italic">
                        "{slot.learned}"
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Edit & Swap Fixed College Task Modal */}
      {editingSlot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto animate-fadeIn">
          <div className="relative w-full max-w-lg bg-slate-900 border border-sky-500/40 rounded-2xl shadow-2xl p-5 space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center border border-sky-500/30">
                  <ArrowLeftRight className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white tracking-tight">
                    Change / Swap Fixed College Task
                  </h4>
                  <p className="text-xs text-slate-400">
                    Update subject details or swap this fixed class into another without touching routine tasks
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingSlot(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Swap Suggestions */}
            <div>
              <label className="block text-[11px] font-bold text-sky-400 uppercase tracking-wider mb-1.5">
                Quick Swap Subject:
              </label>
              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1 bg-slate-950 rounded-xl border border-slate-800">
                {QUICK_SWAP_SUBJECTS.map((subj) => (
                  <button
                    key={subj}
                    type="button"
                    onClick={() => setEditSlotName(subj)}
                    className={`px-2.5 py-1 text-[11px] rounded-lg transition-colors font-medium ${
                      editSlotName === subj
                        ? 'bg-sky-600 text-white font-semibold'
                        : 'bg-slate-900 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800'
                    }`}
                  >
                    {subj}
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={handleSaveEditSlot} className="space-y-3.5 pt-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Subject / Class Name
                  </label>
                  <input
                    type="text"
                    required
                    value={editSlotName}
                    onChange={(e) => setEditSlotName(e.target.value)}
                    placeholder="e.g. Database Systems"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Room / Hall (Optional)
                  </label>
                  <input
                    type="text"
                    value={editSlotRoom}
                    onChange={(e) => setEditSlotRoom(e.target.value)}
                    placeholder="e.g. Hall 401, Lab B"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Faculty / Professor (Optional)
                  </label>
                  <input
                    type="text"
                    value={editSlotProfessor}
                    onChange={(e) => setEditSlotProfessor(e.target.value)}
                    placeholder="e.g. Dr. Sharma"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Day of Week
                  </label>
                  <select
                    value={editSlotDay}
                    onChange={(e) => setEditSlotDay(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-sky-500"
                  >
                    {WEEKDAYS.map((w) => (
                      <option key={w.day} value={w.day}>
                        {w.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Start Time
                  </label>
                  <input
                    type="time"
                    required
                    value={editSlotStart}
                    onChange={(e) => setEditSlotStart(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-sky-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    End Time
                  </label>
                  <input
                    type="time"
                    required
                    value={editSlotEnd}
                    onChange={(e) => setEditSlotEnd(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-sky-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    Session Type
                  </label>
                  <select
                    value={editSlotType}
                    onChange={(e) => setEditSlotType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-sky-500"
                  >
                    <option value="lecture">Lecture</option>
                    <option value="lab">Lab / Practical</option>
                    <option value="break">Lunch Break</option>
                    <option value="tutorial">Tutorial</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingSlot(null)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-md shadow-sky-600/30 transition-colors"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Save Changes</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
