import React, { useState, useEffect } from 'react';
import {
  Smartphone,
  Download,
  CheckCircle2,
  X,
  Image as ImageIcon,
  ExternalLink,
  Package,
} from 'lucide-react';
import { usePWAInstall, SHARED_APP_URL } from '../hooks/usePWAInstall';
import { sounds } from '../utils/audio';

interface PwaAutoInstallBannerProps {
  onOpenApkModal: () => void;
}

export const PwaAutoInstallBanner: React.FC<PwaAutoInstallBannerProps> = ({
  onOpenApkModal,
}) => {
  const {
    isInstallable,
    isInstalled,
    isAndroid,
    isInIframe,
    swReady,
    manifestReady,
    promptInstall,
    downloadOfficialApkIcon,
    topLevelInstallUrl,
  } = usePWAInstall();

  const [dismissed, setDismissed] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [isBusy, setIsBusy] = useState(false);

  // Check if user opened the app via ?install=1 in top-level browser
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('install') === '1') {
      setDismissed(false);
    }
  }, []);

  if (isInstalled || dismissed) return null;

  // Show automatically once Service Worker or Manifest or Install Prompt is ready
  const shouldShow = swReady || manifestReady || isInstallable;
  if (!shouldShow) return null;

  const handleInstallAndDownloadIcon = async () => {
    setIsBusy(true);
    try {
      // 1. Always download the official AR BISWANATH BEHERA 512x512 APK Icon
      await downloadOfficialApkIcon('512');
      sounds.playComplete();

      // 2. Immediately trigger native browser PWA installation dialog if available
      if (isInstallable) {
        const accepted = await promptInstall();
        if (accepted) {
          setStatusMessage('RoutineHub installed & AR BISWANATH BEHERA icon downloaded!');
        } else {
          setStatusMessage('AR BISWANATH BEHERA APK Icon (512×512) downloaded! Tap Install anytime.');
        }
        return;
      }

      // 3. If on Android inside an iframe/WebView, trigger Chrome WebAPK intent
      if (isAndroid) {
        const hostAndPath = SHARED_APP_URL.replace(/^https?:\/\//, '');
        const chromeIntentUrl = `intent://${hostAndPath}/?install=1#Intent;scheme=https;package=com.android.chrome;S.browser_fallback_url=${encodeURIComponent(
          `${SHARED_APP_URL}/?install=1`
        )};end`;
        setStatusMessage('Downloaded AR Icon & opening Android Chrome to install APK...');
        window.location.href = chromeIntentUrl;
        return;
      }

      // 4. If inside preview iframe on desktop/mobile where browser blocks beforeinstallprompt,
      // also open the full APK & Icon Installer modal so user has 1-tap access to top-level prompt & ZIP
      setStatusMessage('Downloaded AR-BISWANATH-BEHERA-APK-Icon-512x512.png! Opening installer...');
      setTimeout(() => {
        onOpenApkModal();
      }, 600);
    } finally {
      setIsBusy(false);
    }
  };

  return (
    <div className="no-print relative z-50 bg-gradient-to-r from-[#090E1A] via-[#111C35] to-[#090E1A] border-b border-[#D4AF77]/45 shadow-[0_4px_24px_rgba(0,0,0,0.45)] px-3 sm:px-6 py-2.5">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
        {/* Left: Official AR BISWANATH BEHERA Icon + Status */}
        <div className="flex items-center justify-between sm:justify-start gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <img
              src="/pwa-192x192.png"
              alt="AR BISWANATH BEHERA APK Icon"
              className="w-10 h-10 rounded-xl border-2 border-[#D4AF77] shadow-[0_0_15px_rgba(212,175,119,0.4)] object-cover shrink-0"
            />
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs sm:text-sm font-extrabold text-white tracking-tight truncate">
                  Install RoutineHub APK
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-emerald-500/20 border border-emerald-400/40 text-emerald-300">
                  {isInstallable
                    ? 'Native Install Ready'
                    : swReady && manifestReady
                    ? 'SW & Manifest Ready'
                    : 'APK Ready'}
                </span>
              </div>
              <p className="text-[11px] text-[#D4AF77] font-mono font-semibold truncate">
                {statusMessage || 'AR BISWANATH BEHERA · Official Play Store Icon & Offline App'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setDismissed(true)}
            className="sm:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Dismiss install banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Right: Primary Install + Icon Download CTA & Direct Top-Level Prompt Link */}
        <div className="flex items-center flex-wrap gap-2 justify-end">
          <button
            onClick={handleInstallAndDownloadIcon}
            disabled={isBusy}
            className="flex-1 sm:flex-initial px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#D4AF77] via-amber-400 to-yellow-500 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-[0_0_18px_rgba(212,175,119,0.38)] hover:brightness-110 transition-all cursor-pointer whitespace-nowrap"
          >
            <Smartphone className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>
              {isBusy
                ? 'Installing & Saving Icon...'
                : isInstallable
                ? 'Install App & Download Icon'
                : 'Install APK & Download Icon'}
            </span>
          </button>

          <a
            href="/api/download-apk-package"
            download="RoutineHub-AR-BISWANATH-BEHERA-Android-APK-Package.zip"
            className="px-3 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/45 text-emerald-200 font-bold text-xs flex items-center gap-1.5 transition-colors whitespace-nowrap"
            title="Direct Download Android APK Package (.ZIP)"
          >
            <Package className="w-3.5 h-3.5 text-emerald-300" />
            <span className="hidden md:inline">APK Kit (.ZIP)</span>
            <span className="md:hidden">.ZIP</span>
          </a>

          {isInIframe && !isInstallable && (
            <a
              href={topLevelInstallUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/45 text-cyan-200 font-bold text-xs flex items-center gap-1.5 transition-colors whitespace-nowrap"
              title="Open outside preview frame to trigger Chrome native PWA install dialog"
            >
              <ExternalLink className="w-3.5 h-3.5 text-cyan-300" />
              <span>Open Native Prompt</span>
            </a>
          )}

          <button
            onClick={onOpenApkModal}
            className="px-2.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer whitespace-nowrap"
          >
            <ImageIcon className="w-3.5 h-3.5 text-[#D4AF77]" />
            <span className="hidden lg:inline">All Options</span>
          </button>

          <button
            onClick={() => setDismissed(true)}
            className="hidden sm:flex p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Dismiss install banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
