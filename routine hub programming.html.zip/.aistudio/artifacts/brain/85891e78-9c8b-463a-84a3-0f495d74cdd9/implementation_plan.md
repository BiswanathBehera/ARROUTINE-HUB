# Password Reset & One-Tap Google Login Implementation Plan

A streamlined authentication and account recovery system for RoutineHub, introducing an interactive in-app password reset workflow with security verification codes, alongside a frictionless One-Tap Google Login flow with instant account switching and avatar personalization.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following product choices were confirmed during the interactive interview:
> - **Password Reset Flow**: In-app reset verification code and instant password update with instant autofill and validation.
> - **Google Login Experience**: One-tap Google profile sign-in and interactive account picker with authentic Google styling.
> - **Reset Trigger Locations**: Accessible both from the email login screen ("Forgot password?") and from the active user profile settings.

- **Confirmed Decision 1**: Reset codes will be generated in-app with a copyable/autofill token, avoiding external email delivery dependencies while maintaining real state validation.
- **Confirmed Decision 2**: Google authentication provides an instant 1-tap sign-in with default user profile (`bbiswanath025@gmail.com` / Biswanath) and an "Add / Switch Account" option.
- **Confirmed Decision 3**: Passwords are securely stored and verified in local profile state, ensuring offline PWA functionality is fully preserved.

---

## 1. Overview & Core Concept

- **What It Does**: Enhances RoutineHub's authentication session modal (`AUTH_SESSION.PY`) with two essential capabilities:
  1. **One-Tap Google Authentication**: Instant sign-in with visual Google account picker, avatar generator, and pre-configured profiles.
  2. **In-App Password Reset Flow**: Multi-step account recovery that verifies registered emails, issues an in-app verification code, and allows setting a new password with instant state updates.
- **Target Audience / Persona**: Students, developers, and creators managing college lectures, trading sessions, coding sprints, and sleep schedules who need reliable, fast access to their synced routine snapshots across devices.
- **Key Value**: Eliminates lockouts due to forgotten credentials, makes Google login instantaneous with zero tedious form-filling, and preserves all offline PWA capabilities.

---

## 2. User Experience & Visual Design

### Key User Flows

```
[ Initialize Login Screen ]
        │
        ├──► [ One-Tap Google Sign-In ]
        │       ├── Instant 1-tap: Continue as Biswanath (bbiswanath025@gmail.com)
        │       └── Account Picker: Select saved Google account or enter custom email
        │
        ├──► [ Email & Password Sign-In ]
        │       ├── Normal login (Email + Password)
        │       └── "Forgot password? Reset" ──► [ Password Reset Modal Mode ]
        │
        └──► [ Active Profile View (When Logged In) ]
                ├── Quick Switch / Add Account
                ├── "Change / Reset Password" ──► [ Password Reset Modal Mode ]
                └── Sign Out / Sync Status
```

### Visual Identity & Theme
- **Aesthetic Direction**: Sleek Mobile Aurora & Terminal Hybrid (`AUTH_SESSION.PY`), matching the existing deep slate navy canvas (`#040711`), glowing aurora orbs (amber, cyan, emerald), and crisp typography.
- **Google One-Tap Tile**: Polished Google white/slate surface with authentic 4-color Google 'G' icon, user avatar badge, and clear email disclosure.
- **Password Reset Card**:
  - Step 1: Email entry with instant validation against registered accounts.
  - Step 2: High-contrast security code badge (`RH-XXXXXX`) with "Copy Code" & "One-Tap Autofill" affordances.
  - Step 3: New password and confirm password inputs with visibility toggles, strength indicator, and haptic feedback.
  - Step 4: Success confirmation toast with automatic sign-in.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: In-App Code vs. External SMTP/Email Service**
  - *Chosen Approach*: In-app generated verification security code with interactive copy & paste verification.
  - *Why*: RoutineHub is an offline-capable Progressive Web App (PWA). Relying on third-party transactional email APIs (SendGrid, Resend) requires server API keys, fails when offline, and introduces external latency. The in-app security code simulates real-world 2FA/recovery without network failure points.
  - *Alternatives Considered*: Simulated mock delay without code (too simplistic) or external email delivery (breaks offline PWA promise).

- **Decision 2: One-Tap Google Login Experience**
  - *Chosen Approach*: Prominent 1-tap primary tile for the user's primary Google profile, plus an expandable account selector listing any other previously used Google accounts.
  - *Why*: Eliminates the friction of re-entering emails on mobile touch screens while maintaining the authentic Google identity feel.
  - *Alternatives Considered*: Standard text inputs only (felt like an email form rather than real Google sign-in).

- **Decision 3: Password Reset from Profile Settings**
  - *Chosen Approach*: Allow logged-in users to initiate a password change/reset directly from the active profile badge in the auth modal and header.
  - *Why*: Users often want to update or recover forgotten passwords before signing out.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌──────────────────────────────────────────────────────────────┐
│                      RoutineHub App                          │
│                                                              │
│  ┌───────────────────────┐        ┌───────────────────────┐  │
│  │      Header.tsx       │        │ MobileHomeDashboard   │  │
│  │ (Profile / Login CTA) │        │   (Profile Action)    │  │
│  └───────────┬───────────┘        └───────────┬───────────┘  │
│              │                                │              │
│              ▼                                ▼              │
│  ┌────────────────────────────────────────────────────────┐  │
│  │               AuthSessionModal.tsx                     │  │
│  │                                                        │  │
│  │  Modes:                                                │  │
│  │  • 'main'     : Main login launchpad with Google tile  │  │
│  │  • 'google'   : One-tap account picker & Google auth   │  │
│  │  • 'login'    : Email sign-in + "Forgot password?"     │  │
│  │  • 'register' : New profile creation                   │  │
│  │  • 'reset'    : In-app password reset & verification   │  │
│  └───────────────────────────┬────────────────────────────┘  │
│                              │                               │
│                              ▼                               │
│  ┌────────────────────────────────────────────────────────┐  │
│  │               Storage & Routine State                  │  │
│  │                                                        │  │
│  │  • loadUserAccounts() / saveUserAccounts()             │  │
│  │  • loadActiveUser() / saveActiveUser()                 │  │
│  │  • updateUserPassword(email, newPassword)              │  │
│  │  • UserRoutineSnapshot per userId                      │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

### Component State & Handler Mapping

1. **`AuthSessionModal.tsx` Updates**:
   - Add `'reset'` to `AuthModalMode` type (`'main' | 'google' | 'login' | 'register' | 'reset'`).
   - Add state variables: `resetEmail`, `resetStep` ('request' | 'verify'), `generatedCode`, `inputCode`, `newPassword`, `confirmPassword`, `resetSuccess`.
   - Implement `handleRequestResetCode()`:
     - Validates email exists in `accounts`.
     - Generates 6-digit cryptographic security code (`RH-` + 4 digits).
     - Advances to verification step.
   - Implement `handleConfirmResetPassword()`:
     - Verifies `inputCode === generatedCode`.
     - Checks password length $\ge 4$ and matching confirmation.
     - Updates account password via `onResetPassword(email, newPassword)`.
     - Plays success haptic & audio cue, logs the user in, and dismisses modal.
   - Enhance `'google'` mode and `'main'` mode:
     - Instant 1-tap "Continue as Biswanath" button.
     - Account picker showing existing Google profiles with avatar colors and creation dates.
     - Smooth input fallback to add any new Google account.

2. **`App.tsx` & `storage.ts` Updates**:
   - Add `updateUserPassword(email: string, newPassword: string): boolean` helper in `storage.ts`.
   - In `App.tsx`, pass `onResetPassword` handler to `AuthSessionModal` to persist updated credentials and update active user state if the current user resets their password.
   - Provide direct trigger for password reset from both the login view and the active account view.

---

## 5. Verification & Testing Steps

1. **Google Login Verification**:
   - Open auth modal -> verify Google 1-Tap tile is prominent with authentic Google icon and prompt.
   - Click "Continue as Biswanath" -> verify instant sign-in, routine snapshot loading, and active user badge update.
   - Open modal again -> verify profile is active, switch to another account or guest mode seamlessly.
2. **Password Reset Verification**:
   - Go to Email Login -> click "Forgot password? Reset here".
   - Test invalid/non-existent email -> verify error message.
   - Enter existing email -> verify security code is generated and displayed.
   - Click "Autofill Code" -> verify input updates automatically.
   - Test password mismatch or too short -> verify validation error.
   - Enter matching valid password -> verify success message, account password update, and successful authentication.
   - Test logging in with the newly updated password -> verify login succeeds.
3. **In-Profile Password Reset**:
   - While signed in, open auth modal -> click "Change Password" -> verify it pre-fills active user email and allows updating credentials without re-entering old password.
