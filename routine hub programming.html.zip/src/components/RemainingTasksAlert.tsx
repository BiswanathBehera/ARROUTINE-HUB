import React from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Flame,
  Volume2,
  CalendarCheck,
  ChevronRight,
  GraduationCap,
  Sparkles,
  Zap,
  Target,
  Bell,
} from 'lucide-react';
import { CollegeConfig, Task } from '../types/routine';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTime12h,
  timeToMinutes,
} from '../utils/dateUtils';
import { sounds } from '../utils/audio';
import { showBrowserNotification } from '../utils/notifications';

interface RemainingTasksAlertProps {
  tasks: Task[];
  collegeConfig: CollegeConfig;
  selectedDate: string;
  isToday: boolean;
  onSelectTask?: (task: Task) => void;
  onOpenCollegeSchedule: () => void;
  onOpenFocusMode?: () => void;
  onTestAlarm?: () => void;
}

export const RemainingTasksAlert: React.FC<RemainingTasksAlertProps> = ({
  tasks,
  collegeConfig,
  isToday,
  onOpenCollegeSchedule,
  onOpenFocusMode,
  onTestAlarm,
}) => {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter((t) => t.completed);
  const remainingTasks = tasks.filter((t) => !t.completed);
  const remainingCount = remainingTasks.length;
  const completedCount = completedTasks.length;

  const completionPercent =
    totalTasks === 0 ? 0 : Math.round((completedCount / totalTasks) * 100);

  // Calculate remaining duration in minutes
  const remainingMinutes = remainingTasks.reduce((sum, task) => {
    return sum + calculateDurationMinutes(task.startTime, task.endTime);
  }, 0);

  const highPriorityLeft = remainingTasks.filter((t) => t.priority === 'high').length;
  const medPriorityLeft = remainingTasks.filter((t) => t.priority === 'medium').length;

  // Real-time analysis: Current time vs routine
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  const collegeStartMin = timeToMinutes(collegeConfig.startTime);
  const collegeEndMin = timeToMinutes(collegeConfig.endTime);

  // Check if today is a college day
  const currentDayOfWeek = now.getDay();
  const isCollegeToday =
    collegeConfig.enabled && collegeConfig.activeDays.includes(currentDayOfWeek);

  const isInCollegeHours =
    isToday && isCollegeToday && currentMinutes >= collegeStartMin && currentMinutes < collegeEndMin;

  // Find next upcoming remaining task
  const upcomingRemainingTasks = remainingTasks
    .filter((t) => timeToMinutes(t.startTime) >= currentMinutes)
    .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));

  const nextTask = upcomingRemainingTasks[0];

  // Overdue remaining tasks
  const overdueTasks = remainingTasks.filter(
    (t) => isToday && timeToMinutes(t.endTime) < currentMinutes
  );

  const triggerTestNotification = () => {
    sounds.playNotificationPing();
    const body =
      remainingCount === 0
        ? 'Great work! You have finished all routine tasks for today.'
        : `You have ${remainingCount} task${remainingCount > 1 ? 's' : ''} left today (${formatDuration(
            remainingMinutes
          )} total). ${nextTask ? `Next: "${nextTask.title}"` : 'Keep pushing forward!'}`;

    showBrowserNotification('Daily Routine Tracker', body);
  };

  return (
    <div className="relative overflow-hidden rounded-2xl bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 p-5 md:p-6 shadow-2xl transition-all">
      {/* Subtle ambient background glow */}
      <div className="absolute -top-20 -right-20 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
        
        {/* Left Side: Big notification metric */}
        <div className="space-y-2.5">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 font-medium">
            <span className="flex items-center gap-1.5 text-indigo-300 font-semibold">
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              Daily Routine Status
            </span>

            {isToday && isInCollegeHours && (
              <>
                <span className="text-slate-600">·</span>
                <span className="flex items-center gap-1 text-sky-300 font-medium">
                  <GraduationCap className="w-3.5 h-3.5" />
                  College Hours ({formatTime12h(collegeConfig.startTime)} – {formatTime12h(collegeConfig.endTime)})
                </span>
              </>
            )}

            {overdueTasks.length > 0 && (
              <>
                <span className="text-slate-600">·</span>
                <span className="flex items-center gap-1 text-rose-400 font-medium">
                  <AlertCircle className="w-3.5 h-3.5" />
                  {overdueTasks.length} Overdue
                </span>
              </>
            )}
          </div>

          <div>
            <div className="flex items-baseline gap-3">
              <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
                {remainingCount === 0 ? (
                  <span className="text-emerald-400 flex items-center gap-2">
                    <CheckCircle2 className="w-7 h-7 inline text-emerald-400" />
                    All Tasks Done for Today!
                  </span>
                ) : (
                  <span>
                    <span className="text-amber-400 font-mono text-3xl md:text-4xl">
                      {remainingCount}
                    </span>{' '}
                    Task{remainingCount > 1 ? 's' : ''} Left for Today
                  </span>
                )}
              </h2>
            </div>

            <p className="text-sm text-slate-300 mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
              {remainingCount > 0 ? (
                <>
                  <span className="flex items-center gap-1 text-slate-300 font-medium">
                    <Clock className="w-4 h-4 text-indigo-400" />
                    <strong className="text-white font-semibold">
                      {formatDuration(remainingMinutes)}
                    </strong>{' '}
                    remaining duration
                  </span>
                  <span className="text-slate-500">•</span>
                  <span className="text-slate-400">
                    {completedCount} completed of {totalTasks} planned
                  </span>
                  {highPriorityLeft > 0 && (
                    <>
                      <span className="text-slate-500">•</span>
                      <span className="text-rose-400 font-medium">
                        {highPriorityLeft} high priority
                      </span>
                    </>
                  )}
                </>
              ) : (
                <span className="text-emerald-300 flex items-center gap-1.5 font-medium">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  You have cleared 100% of your scheduled routine. Great discipline!
                </span>
              )}
            </p>
          </div>

          {/* Quick Active/Next Task Insight */}
          {remainingCount > 0 && (
            <div className="flex flex-wrap items-center gap-2 pt-1">
              {isInCollegeHours ? (
                <button
                  onClick={onOpenCollegeSchedule}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-900/40 hover:bg-blue-900/60 border border-blue-500/40 text-xs text-blue-200 transition-colors text-left"
                >
                  <GraduationCap className="w-4 h-4 text-blue-400 shrink-0" />
                  <span>
                    <strong>College in progress:</strong> Fixed classes until{' '}
                    {formatTime12h(collegeConfig.endTime)}. Click to view class breakdown
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 text-blue-400" />
                </button>
              ) : nextTask ? (
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700/80 text-xs text-slate-200">
                  <Zap className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>
                    Up Next at <strong>{formatTime12h(nextTask.startTime)}</strong>:{' '}
                    <span className="text-indigo-300 font-medium">{nextTask.title}</span> (
                    {calculateDurationMinutes(nextTask.startTime, nextTask.endTime)}m)
                  </span>
                </div>
              ) : overdueTasks.length > 0 ? (
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-rose-950/40 border border-rose-800/50 text-xs text-rose-200">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                  <span>
                    You have unfinished tasks from earlier today. Check them off when ready!
                  </span>
                </div>
              ) : null}
            </div>
          )}
        </div>

        {/* Right Side: Progress Bar & Alert Trigger */}
        <div className="lg:w-80 shrink-0 bg-slate-800/60 p-4 rounded-xl border border-slate-700/60 space-y-3">
          <div className="flex items-center justify-between text-xs font-medium">
            <span className="text-slate-300 flex items-center gap-1.5">
              <CalendarCheck className="w-4 h-4 text-emerald-400" />
              Today's Routine Progress
            </span>
            <span className="font-bold text-white font-mono">{completionPercent}%</span>
          </div>

          {/* Progress Track */}
          <div className="w-full bg-slate-700/70 h-3 rounded-full overflow-hidden p-0.5 shadow-inner">
            <div
              className={`h-full rounded-full transition-all duration-700 ease-out ${
                completionPercent === 100
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                  : 'bg-gradient-to-r from-indigo-500 via-blue-500 to-cyan-400'
              }`}
              style={{ width: `${Math.min(100, completionPercent)}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-0.5">
            <span>
              {completedCount} Done / {remainingCount} Left
            </span>
            <div className="flex items-center gap-2.5">
              {onTestAlarm && (
                <button
                  onClick={onTestAlarm}
                  className="text-xs text-rose-300 hover:text-rose-200 flex items-center gap-1 font-semibold transition-colors hover:underline"
                  title="Test alarm sound and popup modal"
                >
                  <Bell className="w-3 h-3 text-rose-400 animate-bounce" />
                  Test Alarm
                </button>
              )}
              {onOpenFocusMode && (
                <button
                  onClick={onOpenFocusMode}
                  className="text-xs text-indigo-300 hover:text-indigo-200 flex items-center gap-1 font-semibold transition-colors hover:underline"
                  title="Minimize to current active task"
                >
                  <Target className="w-3 h-3 text-indigo-400" />
                  Focus Mode
                </button>
              )}
              <button
                onClick={triggerTestNotification}
                className="text-xs text-slate-300 hover:text-white flex items-center gap-1 font-medium transition-colors hover:underline"
                title="Test chime & notification alert"
              >
                <Volume2 className="w-3 h-3 text-slate-400" />
                Ping
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
