import React, { useEffect, useState, useMemo } from 'react';
import { motion } from 'motion/react';
import {
  Calendar,
  Plus,
  RefreshCw,
  Copy,
  Trash2,
  BellRing,
  HelpCircle,
  ExternalLink,
  Download,
  CheckSquare,
  GraduationCap,
  Briefcase,
  BarChart3,
  Sparkles,
  Clock,
  Home,
  Zap,
} from 'lucide-react';
import {
  CollegeClassSlot,
  CollegeConfig,
  NotificationSettings,
  SleepConfig,
  SleepLogsMap,
  Task,
  TaskCategory,
  UserAccount,
  WeeklyGoal,
} from './types/routine';
import {
  loadCollegeConfig,
  loadNotificationSettings,
  loadSleepConfig,
  loadSleepLogs,
  loadTasksFromStorage,
  loadWeeklyGoals,
  saveCollegeConfig,
  saveNotificationSettings,
  saveSleepConfig,
  saveSleepLogs,
  saveTasksToStorage,
  saveWeeklyGoals,
  getInitialTasks,
  getDefaultSleepLogs,
  defaultCollegeConfig,
  defaultSleepConfig,
  loadUserAccounts,
  saveUserAccounts,
  loadActiveUser,
  saveActiveUser,
  hasSeenAuthGate,
  markAuthGateSeen,
  saveUserRoutineSnapshot,
  loadUserRoutineSnapshot,
} from './utils/storage';
import {
  calculateDurationMinutes,
  calculateFreeTimeSlots,
  formatDuration,
  formatTime12h,
  getTodayDateString,
  minutesToTime,
  timeToMinutes,
} from './utils/dateUtils';
import { Header } from './components/Header';
import { RemainingTasksAlert } from './components/RemainingTasksAlert';
import { VisualTimeline } from './components/VisualTimeline';
import { TaskList } from './components/TaskList';
import { TaskModal } from './components/TaskModal';
import { FixedCollegeModal } from './components/FixedCollegeModal';
import { StatsOverview } from './components/StatsOverview';
import { FocusMode } from './components/FocusMode';
import { DailyLearningJournal } from './components/DailyLearningJournal';
import { TaskAlarmModal } from './components/TaskAlarmModal';
import { ClassAlarmModal, ClassAlarmPayload } from './components/ClassAlarmModal';
import { ExportModal } from './components/ExportModal';
import { CollegeTimetablePlanner } from './components/CollegeTimetablePlanner';
import { WeeklyGoals } from './components/WeeklyGoals';
import { WeeklyHeatMapTracker } from './components/WeeklyHeatMapTracker';
import { WeeklyGoalModal } from './components/WeeklyGoalModal';
import { TimetableUploadModal } from './components/TimetableUploadModal';
import { SleepScheduleModal } from './components/SleepScheduleModal';
import { SleepProductivityChart } from './components/SleepProductivityChart';
import { RemainingTimePlanner } from './components/RemainingTimePlanner';
import { MobileHomeDashboard } from './components/MobileHomeDashboard';
import { LuxuryLandingHero, WorkspaceTab } from './components/LuxuryLandingHero';
import { ApkInstallModal } from './components/ApkInstallModal';
import { PwaAutoInstallBanner } from './components/PwaAutoInstallBanner';
import { OfflineIndicator } from './components/OfflineIndicator';
import { AuthSessionModal } from './components/AuthSessionModal';
import { showBrowserNotification } from './utils/notifications';
import { sounds } from './utils/audio';


export default function App() {
  const [tasks, setTasks] = useState<Task[]>(() => loadTasksFromStorage());
  const [collegeConfig, setCollegeConfig] = useState<CollegeConfig>(() => loadCollegeConfig());
  const [sleepConfig, setSleepConfig] = useState<SleepConfig>(() => loadSleepConfig());
  const [sleepLogs, setSleepLogs] = useState<SleepLogsMap>(() => loadSleepLogs());
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>(() =>
    loadNotificationSettings()
  );

  const [selectedDate, setSelectedDate] = useState<string>(() => getTodayDateString());
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('home');
  const [showLandingHero, setShowLandingHero] = useState<boolean>(false);
  const [weeklyGoals, setWeeklyGoals] = useState<WeeklyGoal[]>(() => loadWeeklyGoals());
  const [isWeeklyGoalModalOpen, setIsWeeklyGoalModalOpen] = useState(false);
  const [goalToEdit, setGoalToEdit] = useState<WeeklyGoal | null>(null);

  // User Authentication & Account Session State
  const [userAccounts, setUserAccounts] = useState<UserAccount[]>(() => loadUserAccounts());
  const [activeUser, setActiveUser] = useState<UserAccount | null>(() => loadActiveUser());
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(() => {
    const existingUser = loadActiveUser();
    const seenGate = hasSeenAuthGate();
    return !existingUser && !seenGate;
  });

  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);
  const [isCollegeModalOpen, setIsCollegeModalOpen] = useState(false);
  const [isSleepModalOpen, setIsSleepModalOpen] = useState(false);
  const [isTimetableUploadOpen, setIsTimetableUploadOpen] = useState(false);
  const [isFocusModeOpen, setIsFocusModeOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      return params.get('install') === '1';
    }
    return false;
  });
  const [alarmTask, setAlarmTask] = useState<Task | null>(null);
  const [alertedTaskIds, setAlertedTaskIds] = useState<Set<string>>(() => new Set());
  const [classAlarm, setClassAlarm] = useState<ClassAlarmPayload | null>(null);
  const [alertedClassKeys, setAlertedClassKeys] = useState<Set<string>>(() => new Set());
  const [alertedBedtimeDate, setAlertedBedtimeDate] = useState<string>('');


  // Global hotkey: press 'f' to toggle Focus Mode when not in text input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeTag = document.activeElement?.tagName.toLowerCase();
      if (activeTag === 'input' || activeTag === 'textarea' || activeTag === 'select') {
        return;
      }
      if (e.key === 'f' || e.key === 'F') {
        setIsFocusModeOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Sync tasks to local storage
  useEffect(() => {
    saveTasksToStorage(tasks);
  }, [tasks]);

  // Sync college configuration to storage
  useEffect(() => {
    saveCollegeConfig(collegeConfig);
  }, [collegeConfig]);

  // Sync sleep configuration to storage
  useEffect(() => {
    saveSleepConfig(sleepConfig);
  }, [sleepConfig]);

  // Sync daily sleep logs to storage
  useEffect(() => {
    saveSleepLogs(sleepLogs);
  }, [sleepLogs]);

  // Sync notification settings to storage
  useEffect(() => {
    saveNotificationSettings(notificationSettings);
  }, [notificationSettings]);

  // Sync weekly goals to storage
  useEffect(() => {
    saveWeeklyGoals(weeklyGoals);
  }, [weeklyGoals]);

  // Sync active user's routine snapshot when signed in
  useEffect(() => {
    if (activeUser && activeUser.syncEnabled !== false) {
      saveUserRoutineSnapshot(activeUser.id, {
        tasks,
        collegeConfig,
        sleepConfig,
        sleepLogs,
        weeklyGoals,
      });
    }
  }, [activeUser, tasks, collegeConfig, sleepConfig, sleepLogs, weeklyGoals]);

  const handleUserAuthenticated = (user: UserAccount, isNewAccount = false) => {
    setUserAccounts((prev) => {
      const exists = prev.some((a) => a.id === user.id || a.email.toLowerCase() === user.email.toLowerCase());
      const updated = exists
        ? prev.map((a) =>
            a.id === user.id || a.email.toLowerCase() === user.email.toLowerCase() ? user : a
          )
        : [user, ...prev];
      saveUserAccounts(updated);
      return updated;
    });

    // If signing into an existing account that has a saved snapshot, restore it
    if (!isNewAccount) {
      const snapshot = loadUserRoutineSnapshot(user.id);
      if (snapshot) {
        setTasks(snapshot.tasks);
        setCollegeConfig(snapshot.collegeConfig);
        setSleepConfig(snapshot.sleepConfig);
        setSleepLogs(snapshot.sleepLogs);
        setWeeklyGoals(snapshot.weeklyGoals);
      }
    } else {
      // Save current routine as initial snapshot for the newly created account
      saveUserRoutineSnapshot(user.id, {
        tasks,
        collegeConfig,
        sleepConfig,
        sleepLogs,
        weeklyGoals,
      });
    }

    setActiveUser(user);
    saveActiveUser(user);
    markAuthGateSeen(true);
    setIsAuthModalOpen(false);
  };

  const handleResetPassword = (email: string, newPassword: string): UserAccount | null => {
    const normalizedEmail = email.trim().toLowerCase();
    const existing = userAccounts.find((a) => a.email.toLowerCase() === normalizedEmail);
    if (!existing) {
      return null;
    }

    const updatedTarget: UserAccount = {
      ...existing,
      password: newPassword,
    };

    const updatedList = userAccounts.map((a) =>
      a.email.toLowerCase() === normalizedEmail ? updatedTarget : a
    );
    setUserAccounts(updatedList);
    saveUserAccounts(updatedList);

    if (activeUser?.email.toLowerCase() === normalizedEmail) {
      setActiveUser(updatedTarget);
      saveActiveUser(updatedTarget);
    }

    return updatedTarget;
  };

  const handleUserSignOut = () => {
    setActiveUser(null);
    saveActiveUser(null);
  };

  const handleContinueAsGuest = () => {
    markAuthGateSeen(true);
    setIsAuthModalOpen(false);
  };


  // Filter tasks for selected date
  const currentDayTasks = useMemo(() => {
    return tasks.filter((t) => t.date === selectedDate);
  }, [tasks, selectedDate]);

  const todayStr = getTodayDateString();
  const isSelectedToday = selectedDate === todayStr;

  // Remaining tasks calculations for selected day
  const remainingTasks = currentDayTasks.filter((t) => !t.completed);
  const remainingCount = remainingTasks.length;

  // Live remaining free time calculation for selected day
  const dayOccupancy = useMemo(
    () => calculateFreeTimeSlots(currentDayTasks, collegeConfig, selectedDate, sleepConfig),
    [currentDayTasks, collegeConfig, selectedDate, sleepConfig]
  );

  // Real-Time Task & After-Every-Class Alarm Loop (checks every 10 seconds)
  useEffect(() => {
    const checkAlarm = () => {
      const now = new Date();
      const currentMin = now.getHours() * 60 + now.getMinutes();

      // 1. Check today's tasks
      const todayTasks = tasks.filter((t) => t.date === todayStr && !t.completed);

      todayTasks.forEach((task) => {
        const startMin = timeToMinutes(task.startTime);

        // When a new task starts (diff === 0)
        if (startMin === currentMin && !alertedTaskIds.has(task.id)) {
          setAlertedTaskIds((prev) => new Set(prev).add(task.id));
          setAlarmTask(task);

          if (notificationSettings.soundEnabled) {
            sounds.startTaskAlarm(10);
          }

          if (notificationSettings.browserNotifications) {
            showBrowserNotification(
              `⏰ TASK START ALARM: ${task.title}`,
              `Starting now (${formatTime12h(task.startTime)})! Focus on: ${task.topic || task.category}`
            );
          }
        }
      });

      // 2. Check today's College Timetable Classes (After-Every-Class End Alert & Start Reminder)
      const dayOfWeek = now.getDay();
      if (collegeConfig.enabled && collegeConfig.activeDays.includes(dayOfWeek)) {
        const todaySlots = (
          collegeConfig.weeklyTimetable?.[dayOfWeek] ||
          collegeConfig.slots ||
          []
        )
          .slice()
          .sort((a, b) => a.startTime.localeCompare(b.startTime));

        todaySlots.forEach((slot, idx) => {
          if (slot.alarmEnabled === false) return;

          const startMin = timeToMinutes(slot.startTime);
          const endMin = timeToMinutes(slot.endTime);
          const nextSlot = todaySlots[idx + 1] || null;

          // After-Every-Class End Alarm (triggers right when class finishes)
          const endKey = `${todayStr}-end-${slot.id}-${slot.endTime}`;
          if (
            notificationSettings.classEndAlarmEnabled !== false &&
            currentMin === endMin &&
            !alertedClassKeys.has(endKey)
          ) {
            setAlertedClassKeys((prev) => new Set(prev).add(endKey));
            setClassAlarm({ slot, mode: 'end', nextSlot });

            if (notificationSettings.soundEnabled) {
              sounds.startTaskAlarm(12);
            }

            if (notificationSettings.browserNotifications) {
              showBrowserNotification(
                `🎓 CLASS FINISHED: ${slot.name}`,
                nextSlot
                  ? `Log what you learned! Next up: ${nextSlot.name} at ${formatTime12h(nextSlot.startTime)}`
                  : `Class complete! Log your key takeaways from ${slot.name}.`
              );
            }
          }

          // Class Start Reminder
          const startKey = `${todayStr}-start-${slot.id}-${slot.startTime}`;
          if (
            notificationSettings.classStartAlarmEnabled !== false &&
            currentMin === startMin &&
            !alertedClassKeys.has(startKey)
          ) {
            setAlertedClassKeys((prev) => new Set(prev).add(startKey));
            setClassAlarm({ slot, mode: 'start', nextSlot });

            if (notificationSettings.soundEnabled) {
              sounds.startTaskAlarm(10);
            }

            if (notificationSettings.browserNotifications) {
              showBrowserNotification(
                `🔔 CLASS STARTING NOW: ${slot.name}`,
                `${formatTime12h(slot.startTime)} – ${formatTime12h(slot.endTime)}${
                  slot.room ? ` • Room: ${slot.room}` : ''
                }`
              );
            }
          }
        });
      }
    };

    checkAlarm();
    const interval = setInterval(checkAlarm, 10000); // 10s check
    return () => clearInterval(interval);
  }, [tasks, alertedTaskIds, collegeConfig, alertedClassKeys, notificationSettings, todayStr]);

  // Bedtime Wind-Down Reminder Loop (checks every 15 seconds)
  useEffect(() => {
    const checkBedtimeWindDown = () => {
      if (!sleepConfig.enabled || !sleepConfig.windDownEnabled) return;
      const now = new Date();
      const currentMin = now.getHours() * 60 + now.getMinutes();

      const bedMin = timeToMinutes(sleepConfig.bedTime || '22:30');
      let reminderMin = bedMin - (sleepConfig.windDownReminderMinutes || 30);
      if (reminderMin < 0) reminderMin += 1440;

      if (currentMin === reminderMin && alertedBedtimeDate !== todayStr) {
        setAlertedBedtimeDate(todayStr);

        if (notificationSettings.soundEnabled) {
          sounds.playSleepWindDown();
        }

        if (notificationSettings.browserNotifications) {
          showBrowserNotification(
            '🌙 Restorative Sleep Wind-Down Alert',
            `Sleep starts in ${sleepConfig.windDownReminderMinutes || 30} minutes (${formatTime12h(
              sleepConfig.bedTime
            )})! Wrap up your tasks for 7 hours of restorative recovery.`
          );
        }
      }
    };

    checkBedtimeWindDown();
    const interval = setInterval(checkBedtimeWindDown, 15000);
    return () => clearInterval(interval);
  }, [sleepConfig, alertedBedtimeDate, notificationSettings, todayStr]);

  // Task Operations
  const handleSaveTask = (taskData: Omit<Task, 'id'>, existingId?: string) => {
    if (existingId) {
      setTasks((prev) =>
        prev.map((t) => (t.id === existingId ? { ...t, ...taskData } : t))
      );
    } else {
      const newTask: Task = {
        ...taskData,
        id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      };
      setTasks((prev) => [...prev, newTask]);
    }
    setTaskToEdit(null);
  };

  const handleToggleComplete = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, completed: !t.completed } : t))
    );
  };

  const handleToggleSubtask = (taskId: string, subtaskId: string) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        return {
          ...t,
          subtasks: t.subtasks.map((s) =>
            s.id === subtaskId ? { ...s, completed: !s.completed } : s
          ),
        };
      })
    );
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
  };

  const handleEditTask = (task: Task) => {
    setTaskToEdit(task);
    setIsTaskModalOpen(true);
  };

  const handleQuickAddPreset = (
    category: TaskCategory,
    durationMin: number,
    title: string
  ) => {
    // Find next available slot after college or last task
    const collegeEndMin = timeToMinutes(collegeConfig.endTime);
    let startMin = collegeEndMin + 30; // default 30 mins after college

    if (currentDayTasks.length > 0) {
      const maxEndMin = Math.max(
        ...currentDayTasks.map((t) => timeToMinutes(t.endTime))
      );
      if (maxEndMin > collegeEndMin) {
        startMin = maxEndMin + 15;
      }
    }

    if (startMin + durationMin > 1435) {
      startMin = 18 * 60; // fall back to 6:00 PM
    }

    const newTask: Task = {
      id: `task-${Date.now()}`,
      title,
      category,
      startTime: minutesToTime(startMin),
      endTime: minutesToTime(startMin + durationMin),
      priority: 'high',
      completed: false,
      notes: `Scheduled ${title} routine session`,
      subtasks: [],
      date: selectedDate,
    };

    setTasks((prev) => [...prev, newTask]);
    if (notificationSettings.soundEnabled) {
      sounds.playNotificationPing();
    }
  };

  const handleDuplicateToTomorrow = () => {
    const [y, m, d] = selectedDate.split('-').map(Number);
    const tomorrow = new Date(y, m - 1, d + 1);
    const tomorrowStr = `${tomorrow.getFullYear()}-${String(
      tomorrow.getMonth() + 1
    ).padStart(2, '0')}-${String(tomorrow.getDate()).padStart(2, '0')}`;

    const copiedTasks: Task[] = currentDayTasks.map((t) => ({
      ...t,
      id: `task-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      date: tomorrowStr,
      completed: false, // Reset completed state for the fresh day
      subtasks: t.subtasks.map((s) => ({ ...s, completed: false })),
    }));

    setTasks((prev) => [...prev, ...copiedTasks]);
    setSelectedDate(tomorrowStr);
    if (notificationSettings.soundEnabled) {
      sounds.playComplete();
    }
  };

  const handleResetToDefaultRoutine = () => {
    if (
      window.confirm(
        'Reset today’s schedule to default college routine (with Study Hours, Trading, Video Editing, Programming & Exercise)?'
      )
    ) {
      const initial = getInitialTasks().map((t) => ({ ...t, date: selectedDate }));
      setTasks((prev) => [
        ...prev.filter((t) => t.date !== selectedDate),
        ...initial,
      ]);
      setCollegeConfig(defaultCollegeConfig);
      setSleepConfig(defaultSleepConfig);
      setSleepLogs(getDefaultSleepLogs());
      if (notificationSettings.soundEnabled) {
        sounds.playComplete();
      }
    }
  };

  const handleUpdateSleepLog = (dateStr: string, hours: number) => {
    setSleepLogs((prev) => ({
      ...prev,
      [dateStr]: hours,
    }));
  };

  const handleUpdateLearned = (taskId: string, topic?: string, learned?: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, topic, learned } : t))
    );
  };

  const handleTestAlarm = () => {
    const sampleTask = currentDayTasks[0] || tasks[0] || {
      id: 'sample-task',
      title: 'Programming & Full-Stack Development',
      category: 'programming',
      startTime: '18:00',
      endTime: '19:45',
      priority: 'high',
      completed: false,
      topic: 'Dynamic Programming (0/1 Knapsack & Memoization)',
      notes: 'Solve 2 DSA LeetCode problems + Build feature module on Web App',
      subtasks: [],
      date: selectedDate,
    };
    setAlarmTask(sampleTask as Task);
    sounds.startTaskAlarm(10);
  };

  const handleTriggerClassAlarm = (
    customSlot?: CollegeClassSlot,
    mode: 'end' | 'start' = 'end'
  ) => {
    const [y, m, d] = selectedDate.split('-').map(Number);
    const dayOfWeek = new Date(y, m - 1, d).getDay();
    const activeDay = dayOfWeek >= 1 && dayOfWeek <= 6 ? dayOfWeek : 1;
    const daySlots = (
      collegeConfig.weeklyTimetable?.[activeDay] ||
      collegeConfig.slots ||
      []
    )
      .slice()
      .sort((a, b) => a.startTime.localeCompare(b.startTime));

    const targetSlot: CollegeClassSlot = customSlot ||
      daySlots[0] || {
        id: 'slot-1',
        name: 'Theory Lecture (Data Structures & Algorithms)',
        room: 'Hall 302',
        startTime: '09:00',
        endTime: '10:30',
        type: 'lecture',
      };

    const currentIdx = daySlots.findIndex((s) => s.id === targetSlot.id);
    const nextSlot =
      currentIdx >= 0 && currentIdx + 1 < daySlots.length
        ? daySlots[currentIdx + 1]
        : daySlots[1] || null;

    setClassAlarm({
      slot: targetSlot,
      mode,
      nextSlot,
    });
    sounds.startTaskAlarm(12);
  };

  const handleSaveClassNotes = (slotId: string, topic: string, learned: string) => {
    setCollegeConfig((prev) => {
      const updatedSlots = prev.slots.map((s) =>
        s.id === slotId ? { ...s, topic, learned } : s
      );
      const updatedWeekly: Record<number, CollegeClassSlot[]> = {};
      if (prev.weeklyTimetable) {
        Object.entries(prev.weeklyTimetable).forEach(([dayKey, list]) => {
          updatedWeekly[Number(dayKey)] = list.map((s) =>
            s.id === slotId ? { ...s, topic, learned } : s
          );
        });
      }
      return {
        ...prev,
        slots: updatedSlots,
        weeklyTimetable: prev.weeklyTimetable ? updatedWeekly : undefined,
      };
    });
    if (notificationSettings.soundEnabled) {
      sounds.playComplete();
    }
  };

  const handleClearDayRoutine = () => {
    if (window.confirm('Are you sure you want to clear all tasks for this day?')) {
      setTasks((prev) => prev.filter((t) => t.date !== selectedDate));
    }
  };

  const handleAssignFreeSlot = (startTime: string, endTime: string) => {
    setTaskToEdit({
      id: '',
      title: '',
      category: 'study',
      startTime,
      endTime,
      priority: 'medium',
      completed: false,
      subtasks: [],
      date: selectedDate,
    });
    setIsTaskModalOpen(true);
  };

  const handleSaveWeeklyGoal = (goalData: Omit<WeeklyGoal, 'id'>, existingId?: string) => {
    if (existingId) {
      setWeeklyGoals((prev) =>
        prev.map((g) => (g.id === existingId ? { ...g, ...goalData } : g))
      );
    } else {
      const newGoal: WeeklyGoal = {
        ...goalData,
        id: `wg-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      };
      setWeeklyGoals((prev) => [newGoal, ...prev]);
    }
    setGoalToEdit(null);
    if (notificationSettings.soundEnabled) {
      sounds.playComplete();
    }
  };

  const handleApplyTimetable = (updatedConfig: CollegeConfig) => {
    setCollegeConfig(updatedConfig);
    saveCollegeConfig(updatedConfig);

    if (notificationSettings.soundEnabled) {
      sounds.playComplete();
    }
  };

  const sleepHoursToday = sleepLogs[selectedDate] ?? sleepConfig.targetHours ?? 7.5;

  if (showLandingHero) {
    return (
      <>
        <PwaAutoInstallBanner onOpenApkModal={() => setIsApkModalOpen(true)} />
        <LuxuryLandingHero
          tasks={tasks}
          currentDayTasks={currentDayTasks}
          selectedDate={selectedDate}
          onSelectDate={setSelectedDate}
          collegeConfig={collegeConfig}
          sleepConfig={sleepConfig}
          sleepHoursToday={sleepHoursToday}
          dayOccupancy={dayOccupancy}
          onEnterWorkspace={(targetTab) => {
            if (targetTab) {
              setActiveTab(targetTab);
            }
            setShowLandingHero(false);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onToggleComplete={handleToggleComplete}
          onOpenFocusMode={() => setIsFocusModeOpen(true)}
          onOpenAddTask={() => {
            setTaskToEdit(null);
            setIsTaskModalOpen(true);
          }}
          onAssignFreeSlot={(startTime, endTime) => {
            handleAssignFreeSlot(startTime, endTime);
          }}
          onOpenApkModal={() => setIsApkModalOpen(true)}
        />

        <ApkInstallModal
          isOpen={isApkModalOpen}
          onClose={() => setIsApkModalOpen(false)}
        />

        {/* Allow TaskModal and FocusMode directly from the Interactive Visual Frames on the Landing Hero */}
        <TaskModal
          isOpen={isTaskModalOpen}
          onClose={() => {
            setIsTaskModalOpen(false);
            setTaskToEdit(null);
          }}
          onSave={handleSaveTask}
          taskToEdit={taskToEdit}
          collegeConfig={collegeConfig}
          sleepConfig={sleepConfig}
          selectedDate={selectedDate}
        />

        {isFocusModeOpen && (
          <FocusMode
            tasks={currentDayTasks}
            collegeConfig={collegeConfig}
            onExit={() => setIsFocusModeOpen(false)}
            onToggleComplete={handleToggleComplete}
            onToggleSubtask={handleToggleSubtask}
            soundEnabled={notificationSettings.soundEnabled}
          />
        )}

        {alarmTask && (
          <TaskAlarmModal
            task={alarmTask}
            onDismiss={() => {
              sounds.stopAlarm();
              setAlarmTask(null);
            }}
            onOpenFocusMode={() => {
              sounds.stopAlarm();
              setAlarmTask(null);
              setIsFocusModeOpen(true);
            }}
            onSnooze={() => {
              sounds.stopAlarm();
              setAlarmTask(null);
            }}
          />
        )}

        {classAlarm && (
          <ClassAlarmModal
            alarm={classAlarm}
            onDismiss={() => {
              sounds.stopAlarm();
              setClassAlarm(null);
            }}
            onSnooze={() => {
              sounds.stopAlarm();
              setClassAlarm(null);
            }}
            onSaveClassNotes={handleSaveClassNotes}
          />
        )}
      </>
    );
  }

  return (
    <div className="min-h-screen app-root bg-[#0F172A] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-white transition-colors duration-300">
      <OfflineIndicator />
      <PwaAutoInstallBanner onOpenApkModal={() => setIsApkModalOpen(true)} />
      {/* Header */}
      <Header
        tasks={tasks}
        selectedDate={selectedDate}
        onDateChange={setSelectedDate}
        collegeConfig={collegeConfig}
        onOpenCollegeSettings={() => setIsCollegeModalOpen(true)}
        sleepConfig={sleepConfig}
        onOpenSleepSchedule={() => setIsSleepModalOpen(true)}
        onOpenAddTask={() => {
          setTaskToEdit(null);
          setIsTaskModalOpen(true);
        }}
        onOpenFocusMode={() => setIsFocusModeOpen(true)}
        onOpenExport={() => setIsExportModalOpen(true)}
        onOpenTimetableUpload={() => setIsTimetableUploadOpen(true)}
        onOpenLandingHero={() => {
          setShowLandingHero(true);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        notificationSettings={notificationSettings}
        onUpdateNotifications={setNotificationSettings}
        remainingCount={remainingCount}
        onTestClassAlarm={() => handleTriggerClassAlarm(undefined, 'end')}
        onOpenApkModal={() => setIsApkModalOpen(true)}
        activeUser={activeUser}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Ambient Aurora Mesh Background Glows (Soft, Subtle Layered Depth) */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0 opacity-45">
        <div className="absolute -top-44 left-1/5 w-[540px] h-[540px] rounded-full bg-cyan-500/10 blur-[140px]" />
        <div className="absolute top-1/4 right-1/6 w-[560px] h-[560px] rounded-full bg-violet-500/10 blur-[150px]" />
        <div className="absolute bottom-0 left-1/3 w-[600px] h-[600px] rounded-full bg-emerald-500/8 blur-[160px]" />
      </div>

      {/* Main Container with Generous Whitespace */}
      <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 pb-32 space-y-8">
        
        {/* 12px Glassmorphic Workspace Navigation Strip (Desktop & Tablet Switcher) */}
        <div className="hidden md:flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-3 border-b border-white/[0.08] animate-first-open stagger-delay-1">
          
          {/* Segmented Workspace Tabs with Animated Glowing Active State Indicator */}
          <div className="flex items-center gap-1.5 p-1.5 glass-layer-12 rounded-2xl overflow-x-auto border border-cyan-500/20">
            {(
              [
                { id: 'home', label: 'Home Bento', icon: Home },
                { id: 'schedule', label: 'Daily Schedule', icon: CheckSquare, badge: remainingCount > 0 ? String(remainingCount) : undefined },
                {
                  id: 'college',
                  label: collegeConfig.commitmentType === 'job' ? 'Work Schedule' : 'College Timetable',
                  icon: collegeConfig.commitmentType === 'job' ? Briefcase : GraduationCap,
                },
                { id: 'analytics', label: 'Analytics & Goals', icon: BarChart3 },
                { id: 'remaining', label: 'Free Time & Assign', icon: Clock, badge: formatDuration(dayOccupancy.freeMinutes) },
              ] as const
            ).map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all duration-200 whitespace-nowrap cursor-pointer active:scale-95 ${
                    isActive ? 'text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="desktopWorkspaceTab"
                      className="absolute inset-0 rounded-xl bg-gradient-to-br from-cyan-500/25 via-violet-500/20 to-emerald-500/15 border border-cyan-400/35 shadow-[0_0_18px_rgba(34,211,238,0.22)]"
                      transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                    />
                  )}
                  {isActive && (
                    <span className="absolute top-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]" />
                  )}
                  <Icon
                    className={`relative z-10 w-3.5 h-3.5 transition-transform ${
                      isActive
                        ? 'text-cyan-300 scale-110 drop-shadow-[0_0_8px_rgba(34,211,238,0.55)]'
                        : 'text-slate-400'
                    }`}
                  />
                  <span className={`relative z-10 tracking-wide ${isActive ? 'font-bold text-cyan-100' : ''}`}>
                    {tab.label}
                  </span>
                  {'badge' in tab && tab.badge && (
                    <span
                      className={`relative z-10 text-[10px] px-1.5 py-0.5 rounded-md font-mono tabular-nums ${
                        isActive
                          ? 'bg-cyan-400/20 text-cyan-200 border border-cyan-400/40 font-bold'
                          : 'bg-white/[0.05] text-slate-400'
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Right Utility Strip */}
          <div className="flex items-center gap-2.5 self-end lg:self-auto">
            <button
              onClick={handleTestAlarm}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-500/12 border border-rose-400/30 hover:border-rose-400 text-xs text-rose-200 hover:text-white font-semibold transition-all active:scale-95 cursor-pointer"
              title="Preview Task Alarm Interface"
            >
              <Zap className="w-3.5 h-3.5 text-rose-400" />
              <span>Test Alarm</span>
            </button>

            <button
              onClick={() => setIsExportModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500/12 border border-amber-400/30 hover:border-amber-400 text-xs text-amber-200 hover:text-white font-semibold transition-all active:scale-95 cursor-pointer"
              title="Export schedule as PDF or JSON"
            >
              <Download className="w-3.5 h-3.5 text-amber-300" />
              <span className="hidden sm:inline">Export PDF</span>
            </button>

            {activeTab !== 'home' && (
              <button
                onClick={() => {
                  setTaskToEdit(null);
                  setIsTaskModalOpen(true);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-500 to-indigo-600 text-slate-950 text-xs font-bold tracking-wide shadow-[0_0_16px_rgba(34,211,238,0.3)] hover:shadow-[0_0_22px_rgba(34,211,238,0.45)] transition-all active:scale-95 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>+ Add Task</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Quick Action & Date Bar when viewing secondary tabs */}
        {activeTab !== 'home' && (
          <div className="flex md:hidden items-center justify-between px-3.5 py-2.5 rounded-2xl obsidian-glass border border-cyan-500/20 animate-first-open stagger-delay-1">
            <button
              onClick={() => setActiveTab('home')}
              className="flex items-center gap-2 text-xs font-semibold text-cyan-300"
            >
              <Home className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span>&larr; Home</span>
            </button>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setIsExportModalOpen(true)}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/15 border border-amber-400/30 text-[11px] font-semibold text-amber-200 flex items-center gap-1"
              >
                <Download className="w-3 h-3 text-amber-400" />
                <span>PDF</span>
              </button>
              <button
                onClick={() => setIsFocusModeOpen(true)}
                className="px-2.5 py-1.5 rounded-xl bg-violet-500/15 border border-violet-400/30 text-[11px] font-semibold text-violet-200 flex items-center gap-1"
              >
                <Zap className="w-3 h-3 text-violet-400" />
                <span>Focus</span>
              </button>
              <button
                onClick={() => {
                  setTaskToEdit(null);
                  setIsTaskModalOpen(true);
                }}
                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-500 to-indigo-600 text-slate-950 text-[11px] font-bold flex items-center gap-1 shadow-sm"
              >
                <Plus className="w-3 h-3 stroke-[2.5]" />
                <span>Add Task</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 0: Sleek Mobile Home Dashboard (Aurora Hero + Modular Bento Grid) */}
        {activeTab === 'home' && (
          <MobileHomeDashboard
            tasks={tasks}
            currentDayTasks={currentDayTasks}
            selectedDate={selectedDate}
            onSelectDate={setSelectedDate}
            collegeConfig={collegeConfig}
            sleepConfig={sleepConfig}
            sleepLogs={sleepLogs}
            onUpdateSleepLog={handleUpdateSleepLog}
            dayOccupancy={dayOccupancy}
            weeklyGoals={weeklyGoals}
            onToggleComplete={handleToggleComplete}
            onEditTask={handleEditTask}
            onOpenAddTask={() => {
              setTaskToEdit(null);
              setIsTaskModalOpen(true);
            }}
            onAssignFreeSlot={handleAssignFreeSlot}
            onOpenFocusMode={() => setIsFocusModeOpen(true)}
            onOpenTimetableUpload={() => setIsTimetableUploadOpen(true)}
            onOpenSleepSettings={() => setIsSleepModalOpen(true)}
            onOpenExport={() => setIsExportModalOpen(true)}
            onTestAlarm={handleTestAlarm}
            onOpenApkModal={() => setIsApkModalOpen(true)}
            activeUser={activeUser}
            onOpenAuthModal={() => setIsAuthModalOpen(true)}
            onNavigateTab={setActiveTab}
          />
        )}

        {/* Tab 1: Daily Schedule */}
        {activeTab === 'schedule' && (
          <div className="space-y-8 animate-first-open stagger-delay-2">
            {/* Real-Time Remaining Tasks Hero Alert */}
            <RemainingTasksAlert
              tasks={currentDayTasks}
              collegeConfig={collegeConfig}
              selectedDate={selectedDate}
              isToday={isSelectedToday}
              onSelectTask={handleEditTask}
              onOpenCollegeSchedule={() => setActiveTab('college')}
              onOpenFocusMode={() => setIsFocusModeOpen(true)}
              onTestAlarm={handleTestAlarm}
            />

            {/* 24-Hour Visual Schedule Timeline */}
            <VisualTimeline
              tasks={currentDayTasks}
              collegeConfig={collegeConfig}
              sleepConfig={sleepConfig}
              isToday={isSelectedToday}
              onSelectTask={handleEditTask}
              onOpenCollegeSchedule={() => setActiveTab('college')}
              onOpenSleepSchedule={() => setIsSleepModalOpen(true)}
            />

            {/* 7-Day Completion Heat Map Tracker */}
            <WeeklyHeatMapTracker
              tasks={tasks}
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
            />

            {/* Dynamic Task List & Routine Management */}
            <div className="space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-serif text-xl font-semibold text-white tracking-wide">
                    Daily Self-Upgrade Routine
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Track personal growth and deep-work sessions around mandatory hours.
                  </p>
                </div>

                {/* Routine Utilities: Copy to Tomorrow, Reset, Clear */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={handleDuplicateToTomorrow}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl glass-layer-12 hover:bg-white/[0.06] text-xs text-slate-300 font-medium transition-colors"
                    title="Copy current routine to tomorrow"
                  >
                    <Copy className="w-3.5 h-3.5 text-cyan-300" />
                    <span>Copy to Tomorrow</span>
                  </button>

                  <button
                    onClick={handleResetToDefaultRoutine}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl glass-layer-12 hover:bg-white/[0.06] text-xs text-slate-300 font-medium transition-colors"
                    title="Restore sample routine with Study, Trading, Editing, Coding & Gym"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
                    <span>Reset Routine</span>
                  </button>

                  {currentDayTasks.length > 0 && (
                    <button
                      onClick={handleClearDayRoutine}
                      className="p-1.5 rounded-xl glass-layer-12 hover:bg-rose-950/60 hover:border-rose-800/60 text-slate-400 hover:text-rose-400 text-xs transition-colors"
                      title="Clear all tasks for this date"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <TaskList
                tasks={currentDayTasks}
                collegeConfig={collegeConfig}
                onToggleComplete={handleToggleComplete}
                onToggleSubtask={handleToggleSubtask}
                onEditTask={handleEditTask}
                onDeleteTask={handleDeleteTask}
                onQuickAddPreset={handleQuickAddPreset}
                onOpenCollegeSchedule={() => setActiveTab('college')}
                onOpenAddTask={() => {
                  setTaskToEdit(null);
                  setIsTaskModalOpen(true);
                }}
                soundEnabled={notificationSettings.soundEnabled}
              />
            </div>
          </div>
        )}

        {/* Tab 2: College Timetable & Capacity Radar */}
        {activeTab === 'college' && (
          <div className="space-y-8 animate-first-open stagger-delay-2">
            <CollegeTimetablePlanner
              collegeConfig={collegeConfig}
              onUpdateCollegeConfig={setCollegeConfig}
              tasks={currentDayTasks}
              selectedDate={selectedDate}
              onAssignFreeSlot={handleAssignFreeSlot}
              onOpenUploadModal={() => setIsTimetableUploadOpen(true)}
              sleepConfig={sleepConfig}
              notificationSettings={notificationSettings}
              onUpdateNotifications={setNotificationSettings}
              onTriggerClassAlarm={handleTriggerClassAlarm}
            />
          </div>
        )}

        {/* Tab 3: Analytics, Weekly Goals & Learning Journal */}
        {activeTab === 'analytics' && (
          <div className="space-y-8 animate-first-open stagger-delay-2">
            {/* Weekly & Monthly Progress Heat Map Tracker */}
            <WeeklyHeatMapTracker
              tasks={tasks}
              selectedDate={selectedDate}
              onSelectDate={setSelectedDate}
              defaultMode="monthly"
            />

            {/* Sleep Consistency vs. Daily Productivity Line Chart */}
            <SleepProductivityChart
              tasks={tasks}
              sleepConfig={sleepConfig}
              sleepLogs={sleepLogs}
              onUpdateSleepLog={handleUpdateSleepLog}
              onOpenSleepSettings={() => setIsSleepModalOpen(true)}
              selectedDate={selectedDate}
            />

            {/* Side-by-Side: Weekly Goals & Stats Overview */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
              <WeeklyGoals
                goals={weeklyGoals}
                onUpdateGoals={setWeeklyGoals}
                onOpenAddGoal={() => {
                  setGoalToEdit(null);
                  setIsWeeklyGoalModalOpen(true);
                }}
                onEditGoal={(goal) => {
                  setGoalToEdit(goal);
                  setIsWeeklyGoalModalOpen(true);
                }}
                selectedDate={selectedDate}
                soundEnabled={notificationSettings.soundEnabled}
              />

              <StatsOverview
                tasks={currentDayTasks}
                collegeConfig={collegeConfig}
                sleepConfig={sleepConfig}
              />
            </div>

            {/* Daily Learning Journal */}
            <DailyLearningJournal
              tasks={currentDayTasks}
              onUpdateLearned={handleUpdateLearned}
            />
          </div>
        )}

        {/* Tab 4: Remaining Time & Task Slot Assignment */}
        {activeTab === 'remaining' && (
          <div className="space-y-8 animate-first-open stagger-delay-2">
            <RemainingTimePlanner
              tasks={currentDayTasks}
              collegeConfig={collegeConfig}
              sleepConfig={sleepConfig}
              selectedDate={selectedDate}
              onSaveTask={handleSaveTask}
              onAssignFreeSlotModal={handleAssignFreeSlot}
              onEditTask={handleEditTask}
              onDeleteTask={handleDeleteTask}
              onToggleComplete={handleToggleComplete}
              onOpenCollegeTab={() => setActiveTab('college')}
              onOpenSleepModal={() => setIsSleepModalOpen(true)}
            />
          </div>
        )}
      </main>

      {/* Persistent Glassmorphic Bottom Navigation Bar with Vibrant Aurora Pill on Mobile */}
      <nav
        aria-label="Primary bottom navigation"
        className="no-print fixed bottom-3 left-1/2 -translate-x-1/2 z-40 w-[calc(100%-1.25rem)] max-w-lg glass-bottom-nav rounded-[26px] p-1.5"
      >
        <div className="grid grid-cols-5 items-center gap-1">
          {(
            [
              { id: 'home', label: 'Home', icon: Home },
              { id: 'schedule', label: 'Schedule', icon: CheckSquare, count: remainingCount },
              {
                id: 'college',
                label: collegeConfig.commitmentType === 'job' ? 'Shifts' : 'Timetable',
                icon: collegeConfig.commitmentType === 'job' ? Briefcase : GraduationCap,
              },
              { id: 'remaining', label: 'Free Time', icon: Clock },
              { id: 'analytics', label: 'Analytics', icon: BarChart3 },
            ] as const
          ).map((navItem) => {
            const Icon = navItem.icon;
            const isActive = activeTab === navItem.id;
            return (
              <button
                key={navItem.id}
                onClick={() => setActiveTab(navItem.id)}
                className={`min-h-[50px] rounded-2xl flex flex-col items-center justify-center gap-0.5 transition-all active:scale-95 relative cursor-pointer ${
                  isActive ? 'text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId="mobileBottomNavTab"
                    className="absolute inset-0 rounded-2xl bg-gradient-to-br from-cyan-500/25 via-violet-500/20 to-emerald-500/15 border border-cyan-400/35 shadow-[0_0_18px_rgba(34,211,238,0.22)]"
                    transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                  />
                )}
                {isActive && (
                  <span className="absolute top-1 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]" />
                )}
                <div className="relative z-10 mt-0.5">
                  <Icon
                    className={`w-4 h-4 transition-transform ${
                      isActive
                        ? 'text-cyan-300 scale-110 drop-shadow-[0_0_8px_rgba(34,211,238,0.55)]'
                        : ''
                    }`}
                  />
                  {'count' in navItem && navItem.count !== undefined && navItem.count > 0 && (
                    <span className="absolute -top-1.5 -right-2.5 min-w-[15px] h-[15px] px-1 rounded-full bg-gradient-to-r from-cyan-400 to-emerald-400 text-slate-950 text-[9px] font-extrabold font-mono tabular-nums flex items-center justify-center shadow-[0_0_8px_rgba(34,211,238,0.5)]">
                      {navItem.count}
                    </span>
                  )}
                </div>
                <span
                  className={`relative z-10 text-[10px] tracking-wide ${
                    isActive ? 'font-bold text-cyan-100' : 'font-semibold'
                  }`}
                >
                  {navItem.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Hyper-Minimalist Footer */}
      <footer className="border-t border-white/[0.06] bg-[#0F172A] py-6 pb-24 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex flex-col items-center sm:items-start gap-0.5">
            <span className="font-serif tracking-wider text-slate-300">
              RoutineHub — Daily Architecture & Timetable System
            </span>
            <span className="font-mono text-[10px] tracking-[0.18em] uppercase text-cyan-300/80 md:text-[#D4AF77]/85">
              AR BISWANATH BEHERA
            </span>
          </div>
          <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
            <span>Fixed Hours Locked</span>
            <span>·</span>
            <span>Dynamic Input Ready</span>
            <span>·</span>
            <span>Real-Time Alerts</span>
          </div>
        </div>
      </footer>

      {/* Task Creation / Edit Modal */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => {
          setIsTaskModalOpen(false);
          setTaskToEdit(null);
        }}
        onSave={handleSaveTask}
        taskToEdit={taskToEdit}
        collegeConfig={collegeConfig}
        sleepConfig={sleepConfig}
        selectedDate={selectedDate}
      />

      {/* Fixed College Hours Configuration Modal */}
      <FixedCollegeModal
        isOpen={isCollegeModalOpen}
        onClose={() => setIsCollegeModalOpen(false)}
        config={collegeConfig}
        onSave={setCollegeConfig}
        onOpenUploadModal={() => setIsTimetableUploadOpen(true)}
      />

      {/* Timetable PDF & Photo AI Upload Modal */}
      <TimetableUploadModal
        isOpen={isTimetableUploadOpen}
        onClose={() => setIsTimetableUploadOpen(false)}
        collegeConfig={collegeConfig}
        onApplyTimetable={handleApplyTimetable}
      />

      {/* Distraction-Free Focus Mode */}
      {isFocusModeOpen && (
        <FocusMode
          tasks={currentDayTasks}
          collegeConfig={collegeConfig}
          onExit={() => setIsFocusModeOpen(false)}
          onToggleComplete={handleToggleComplete}
          onToggleSubtask={handleToggleSubtask}
          soundEnabled={notificationSettings.soundEnabled}
        />
      )}

      {/* Real-time Task Start Alarm Modal */}
      {alarmTask && (
        <TaskAlarmModal
          task={alarmTask}
          onDismiss={() => {
            sounds.stopAlarm();
            setAlarmTask(null);
          }}
          onOpenFocusMode={(task) => {
            sounds.stopAlarm();
            setAlarmTask(null);
            setIsFocusModeOpen(true);
          }}
          onSnooze={() => {
            sounds.stopAlarm();
            setAlarmTask(null);
          }}
        />
      )}

      {/* Real-time After-Every-Class Alarm & Quick Learned-Notes Modal */}
      {classAlarm && (
        <ClassAlarmModal
          alarm={classAlarm}
          onDismiss={() => {
            sounds.stopAlarm();
            setClassAlarm(null);
          }}
          onSnooze={() => {
            sounds.stopAlarm();
            setClassAlarm(null);
          }}
          onSaveClassNotes={handleSaveClassNotes}
        />
      )}

      {/* Routine & Learning Export Modal (Printable PDF & JSON) */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        tasks={currentDayTasks}
        collegeConfig={collegeConfig}
        sleepConfig={sleepConfig}
        selectedDate={selectedDate}
        weeklyGoals={weeklyGoals}
      />

      {/* Weekly Goal Creation & Edit Modal */}
      <WeeklyGoalModal
        isOpen={isWeeklyGoalModalOpen}
        onClose={() => {
          setIsWeeklyGoalModalOpen(false);
          setGoalToEdit(null);
        }}
        onSave={handleSaveWeeklyGoal}
        goalToEdit={goalToEdit}
      />

      {/* Sleep Schedule & Wind-Down Reminder Modal */}
      <SleepScheduleModal
        isOpen={isSleepModalOpen}
        onClose={() => setIsSleepModalOpen(false)}
        config={sleepConfig}
        onSave={setSleepConfig}
        soundEnabled={notificationSettings.soundEnabled}
      />

      {/* Android APK & Mobile PWA Installer Modal */}
      <ApkInstallModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Initialize Login & Account Creation Session Modal */}
      <AuthSessionModal
        isOpen={isAuthModalOpen}
        activeUser={activeUser}
        accounts={userAccounts}
        onAuthenticated={handleUserAuthenticated}
        onResetPassword={handleResetPassword}
        onSignOut={handleUserSignOut}
        onContinueAsGuest={handleContinueAsGuest}
        soundEnabled={notificationSettings.soundEnabled}
      />
    </div>
  );
}

