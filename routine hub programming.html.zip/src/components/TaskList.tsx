import React, { useState, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  CheckCircle2,
  Circle,
  Clock,
  Edit3,
  Trash2,
  Plus,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Sparkles,
  CheckSquare,
  Square,
  ArrowUpDown,
  Flame,
  BookOpen,
  TrendingUp,
  Film,
  Code2,
  Dumbbell,
  Lightbulb,
  Tag,
  Lock,
  User,
  Briefcase,
} from 'lucide-react';
import { CollegeConfig, Priority, Task, TaskCategory } from '../types/routine';
import { CATEGORIES } from '../utils/categories';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTime12h,
  timeToMinutes,
} from '../utils/dateUtils';
import { sounds } from '../utils/audio';
import { UserAccount } from '../types/routine';

interface TaskListProps {
  tasks: Task[];
  collegeConfig: CollegeConfig;
  onToggleComplete: (taskId: string) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  onEditTask: (task: Task) => void;
  onDeleteTask: (taskId: string) => void;
  onQuickAddPreset: (category: TaskCategory, durationMin: number, title: string) => void;
  onOpenCollegeSchedule: () => void;
  onOpenAddTask: () => void;
  soundEnabled: boolean;
  activeUser?: UserAccount | null;
  onOpenAuthModal?: (reason?: string) => void;
}

export const TaskList: React.FC<TaskListProps> = ({
  tasks,
  collegeConfig,
  onToggleComplete,
  onToggleSubtask,
  onEditTask,
  onDeleteTask,
  onQuickAddPreset,
  onOpenCollegeSchedule,
  onOpenAddTask,
  soundEnabled,
  activeUser,
  onOpenAuthModal,
}) => {
  const [filter, setFilter] = useState<'all' | 'remaining' | 'completed' | TaskCategory>('all');
  const [expandedTaskIds, setExpandedTaskIds] = useState<Record<string, boolean>>({});
  const [sortBy, setSortBy] = useState<'time' | 'priority'>('time');

  const toggleExpand = (id: string) => {
    setExpandedTaskIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const remainingCount = tasks.filter((t) => !t.completed).length;
  const completedCount = tasks.filter((t) => t.completed).length;

  const handleTaskCheck = (task: Task) => {
    const willBeCompleted = !task.completed;
    onToggleComplete(task.id);

    if (willBeCompleted && soundEnabled) {
      sounds.playComplete();
      // If completing the last remaining task, trigger confetti celebration!
      if (remainingCount === 1) {
        try {
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
          });
        } catch {
          // Ignore
        }
      }
    }
  };

  // Filter tasks
  const filteredTasks = tasks.filter((task) => {
    if (filter === 'all') return true;
    if (filter === 'remaining') return !task.completed;
    if (filter === 'completed') return task.completed;
    return task.category === filter;
  });

  // Sort tasks: either chronologically by start time, or by Priority (High -> Medium -> Low) with tie-breaker by start time
  const sortedTasks = useMemo(() => {
    return [...filteredTasks].sort((a, b) => {
      if (sortBy === 'time') {
        return timeToMinutes(a.startTime) - timeToMinutes(b.startTime);
      }
      const priorityWeight: Record<Priority, number> = { high: 3, medium: 2, low: 1 };
      const diff = priorityWeight[b.priority] - priorityWeight[a.priority];
      if (diff !== 0) return diff;
      // Secondary tie-breaker: earliest start time first
      return timeToMinutes(a.startTime) - timeToMinutes(b.startTime);
    });
  }, [filteredTasks, sortBy]);

  const priorityBadge = (priority: Priority) => {
    switch (priority) {
      case 'high':
        return (
          <span className="text-[11px] font-bold text-rose-400">
            High Priority
          </span>
        );
      case 'medium':
        return (
          <span className="text-[11px] font-semibold text-amber-400">
            Medium
          </span>
        );
      case 'low':
        return (
          <span className="text-[11px] font-medium text-slate-400">
            Low
          </span>
        );
    }
  };

  return (
    <div className="space-y-4">
      {/* Quick Add Presets Bar (User categories: Study, Trading, Video Editing, Programming, Exercise) */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
          <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            Quick Add Routine Presets:
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenAddTask}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Assign Task</span>
            </button>
            {onOpenAuthModal && (
              <button
                type="button"
                onClick={() => onOpenAuthModal('Assign Task')}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] font-semibold transition-all cursor-pointer ${
                  activeUser
                    ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-300 hover:bg-emerald-500/25'
                    : 'bg-amber-400/15 border-amber-400/45 text-amber-200 hover:bg-amber-400/25'
                }`}
                title="Login / Sync Account"
              >
                <Lock className="w-3 h-3 text-amber-300" />
                <span>{activeUser ? activeUser.name : 'Login to Assign'}</span>
              </button>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => onQuickAddPreset('study', 60, 'Core Study Hours & Concept Revision')}
            className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-950/60 hover:bg-blue-900/60 border border-blue-500/30 text-blue-200 text-xs font-medium transition-colors cursor-pointer"
          >
            <BookOpen className="w-3.5 h-3.5 text-blue-400" />
            + Study Hours (1h)
          </button>

          <button
            onClick={() => onQuickAddPreset('personal', 90, 'Workplace Focus & Job Task Execution')}
            className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-500/30 text-cyan-200 text-xs font-medium transition-colors cursor-pointer"
          >
            <Briefcase className="w-3.5 h-3.5 text-cyan-400" />
            + Work &amp; Job Focus (1.5h)
          </button>

          <button
            onClick={() => onQuickAddPreset('trading', 60, 'Trading Session & Chart Analysis')}
            className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/30 text-emerald-200 text-xs font-medium transition-colors cursor-pointer"
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
            + Trading (1h)
          </button>

          <button
            onClick={() => onQuickAddPreset('video_editing', 75, 'Video Editing & Thumbnail Design')}
            className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-pink-950/60 hover:bg-pink-900/60 border border-pink-500/30 text-pink-200 text-xs font-medium transition-colors cursor-pointer"
          >
            <Film className="w-3.5 h-3.5 text-pink-400" />
            + Video Editing (1h 15m)
          </button>

          <button
            onClick={() => onQuickAddPreset('programming', 90, 'Programming & DSA Problem Solving')}
            className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-violet-950/60 hover:bg-violet-900/60 border border-violet-500/30 text-violet-200 text-xs font-medium transition-colors cursor-pointer"
          >
            <Code2 className="w-3.5 h-3.5 text-violet-400" />
            + Programming (1.5h)
          </button>

          <button
            onClick={() => onQuickAddPreset('exercise', 45, 'Gym Workout & Mobility Exercise')}
            className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-950/60 hover:bg-amber-900/60 border border-amber-500/30 text-amber-200 text-xs font-medium transition-colors cursor-pointer"
          >
            <Dumbbell className="w-3.5 h-3.5 text-amber-400" />
            + Exercise (45m)
          </button>
        </div>
      </div>

      {/* Mandatory Commitment Reference (College or Job hours managed in dedicated Timetable) */}
      {collegeConfig.enabled && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs text-slate-400">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-2 h-2 rounded-full bg-sky-400 shrink-0" />
            <span className="font-semibold text-slate-200">
              {collegeConfig.commitmentType === 'job' ? 'Work / Job Hours' : 'Mandatory College Hours'}:
            </span>
            <span className="font-mono text-sky-300">
              {formatTime12h(collegeConfig.startTime)} – {formatTime12h(collegeConfig.endTime)}
            </span>
            <span className="text-slate-600 hidden md:inline">·</span>
            <span className="text-slate-400 hidden md:inline truncate">
              {collegeConfig.collegeName} (Managed in Timetable tab)
            </span>
          </div>
          <button
            type="button"
            onClick={onOpenCollegeSchedule}
            className="text-xs font-semibold text-sky-400 hover:text-sky-300 transition-colors shrink-0 self-end sm:self-auto"
          >
            Open Timetable →
          </button>
        </div>
      )}

      {/* Filter and Sort Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 border border-slate-800 p-2.5 rounded-xl">
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
              filter === 'all'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            All Routine ({tasks.length})
          </button>

          <button
            onClick={() => setFilter('remaining')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 flex items-center gap-1.5 ${
              filter === 'remaining'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <span>Remaining Today</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                filter === 'remaining' ? 'bg-amber-800 text-white' : 'bg-amber-500/20 text-amber-300'
              }`}
            >
              {remainingCount}
            </span>
          </button>

          <button
            onClick={() => setFilter('completed')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 flex items-center gap-1 ${
              filter === 'completed'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Completed ({completedCount})
          </button>
        </div>

        {/* Segmented Sort Toggle */}
        <div className="flex items-center justify-between sm:justify-end gap-2 text-xs text-slate-400 shrink-0">
          <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
            <span>Sort:</span>
          </span>
          <div className="flex items-center p-0.5 rounded-xl bg-slate-950/80 border border-slate-800 shadow-inner">
            <button
              type="button"
              onClick={() => setSortBy('time')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all duration-150 ${
                sortBy === 'time'
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
              title="Sort chronologically by start time"
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Start Time</span>
            </button>
            <button
              type="button"
              onClick={() => setSortBy('priority')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold transition-all duration-150 ${
                sortBy === 'priority'
                  ? 'bg-gradient-to-r from-rose-600 to-amber-600 text-white shadow-sm shadow-rose-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
              title="Sort by priority (High → Medium → Low), then earliest start time"
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Priority</span>
            </button>
          </div>
        </div>
      </div>

      {/* Routine Tasks List */}
      <div className="space-y-3">
        {/* Dynamic Task Items */}
        {sortedTasks.map((task) => {
          const cat = CATEGORIES[task.category] || CATEGORIES.personal;
          const CatIcon = cat.icon;
          const isExpanded = !!expandedTaskIds[task.id];
          const durationMin = calculateDurationMinutes(task.startTime, task.endTime);

          return (
            <div
              key={task.id}
              className={`rounded-2xl border transition-all duration-200 ${
                task.completed
                  ? 'bg-slate-900/40 backdrop-blur-md border-slate-800/60 opacity-75'
                  : 'bg-slate-900/60 backdrop-blur-xl border-slate-800/80 hover:border-slate-700 shadow-lg'
              }`}
            >
              <div className="p-4 flex items-start justify-between gap-3">
                {/* Checkbox & Details */}
                <div className="flex items-start gap-3 min-w-0">
                  <button
                    onClick={() => handleTaskCheck(task)}
                    className="mt-0.5 text-slate-400 hover:text-emerald-400 transition-colors shrink-0"
                    title={task.completed ? 'Mark incomplete' : 'Mark task completed'}
                  >
                    {task.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-500/20" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-500 hover:text-emerald-400" />
                    )}
                  </button>

                  <div className="min-w-0 space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`text-sm md:text-base font-bold tracking-tight truncate ${
                          task.completed ? 'line-through text-slate-400' : 'text-white'
                        }`}
                      >
                        {task.title}
                      </span>

                      {/* Clean Category Label */}
                      <span
                        className={`inline-flex items-center gap-1 text-[11px] font-semibold ${cat.badgeText}`}
                      >
                        <CatIcon className="w-3 h-3" />
                        {cat.label}
                      </span>

                      {/* Clean Topic Label */}
                      {task.topic && (
                        <>
                          <span className="text-slate-600">·</span>
                          <span className="inline-flex items-center gap-1 text-[11px] text-slate-300 font-medium">
                            <Tag className="w-3 h-3 text-indigo-400" />
                            <span>{task.topic}</span>
                          </span>
                        </>
                      )}

                      <span className="text-slate-600">·</span>
                      {priorityBadge(task.priority)}
                    </div>

                    {/* Time & Duration Info */}
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                      <span className="flex items-center gap-1 font-mono font-medium text-slate-300">
                        <Clock className="w-3.5 h-3.5 text-indigo-400" />
                        {formatTime12h(task.startTime)} – {formatTime12h(task.endTime)}
                      </span>
                      <span className="text-slate-600">•</span>
                      <span className="font-medium text-slate-300">
                        {formatDuration(durationMin)}
                      </span>

                      {task.subtasks.length > 0 && (
                        <>
                          <span className="text-slate-600">•</span>
                          <span className="text-indigo-300 font-medium">
                            {task.subtasks.filter((s) => s.completed).length}/
                            {task.subtasks.length} subtasks
                          </span>
                        </>
                      )}
                    </div>

                    {/* Notes preview if not expanded */}
                    {!isExpanded && task.notes && (
                      <p className="text-xs text-slate-400 line-clamp-1 italic pt-0.5">
                        "{task.notes}"
                      </p>
                    )}
                  </div>
                </div>

                {/* Right Actions */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => toggleExpand(task.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                    title={isExpanded ? 'Collapse' : 'Expand notes & subtasks'}
                  >
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </button>

                  <button
                    onClick={() => onEditTask(task)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-300 hover:bg-slate-800 transition-colors"
                    title="Edit task"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onDeleteTask(task.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                    title="Delete task"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Expanded Subtasks & Detailed Notes */}
              {isExpanded && (
                <div className="px-4 pb-4 pt-1 border-t border-slate-800/80 space-y-3 bg-slate-950/40 rounded-b-2xl">
                  {/* What I Have Learned Section */}
                  {task.learned ? (
                    <div className="text-xs bg-amber-950/25 border border-amber-500/30 p-3 rounded-xl space-y-1.5 shadow-sm">
                      <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1.5 text-amber-300 font-bold text-[11px] uppercase tracking-wider">
                          <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                          What I Have Learned / Key Takeaways:
                        </span>
                        <button
                          onClick={() => onEditTask(task)}
                          className="text-[10px] text-amber-300 hover:text-white underline font-medium"
                        >
                          Edit
                        </button>
                      </div>
                      <p className="text-slate-200 leading-relaxed pl-5 font-normal">
                        {task.learned}
                      </p>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between p-2 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400">
                      <span className="flex items-center gap-1.5 text-[11px]">
                        <Lightbulb className="w-3.5 h-3.5 text-amber-400/70" />
                        No learnings recorded yet for this session.
                      </span>
                      <button
                        onClick={() => onEditTask(task)}
                        className="text-[11px] px-2.5 py-1 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 font-semibold border border-amber-500/30 transition-colors"
                      >
                        + Log What I Learned
                      </button>
                    </div>
                  )}

                  {task.notes && (
                    <div className="text-xs text-slate-300 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                      <strong className="text-slate-400 uppercase tracking-wider text-[10px] block mb-1">
                        Task Notes:
                      </strong>
                      {task.notes}
                    </div>
                  )}

                  {task.subtasks.length > 0 && (
                    <div className="space-y-1.5">
                      <strong className="text-slate-400 uppercase tracking-wider text-[10px] block">
                        Action Checklist:
                      </strong>
                      <div className="space-y-1">
                        {task.subtasks.map((sub) => (
                          <button
                            key={sub.id}
                            onClick={() => onToggleSubtask(task.id, sub.id)}
                            className="flex items-center gap-2 text-xs text-left w-full p-1.5 rounded-lg hover:bg-slate-800/70 transition-colors"
                          >
                            {sub.completed ? (
                              <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-500 shrink-0" />
                            )}
                            <span
                              className={`${
                                sub.completed ? 'line-through text-slate-500' : 'text-slate-200'
                              }`}
                            >
                              {sub.title}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {/* Empty State */}
        {sortedTasks.length === 0 && filter !== 'college' && (
          <div className="text-center py-12 px-4 rounded-2xl border border-dashed border-slate-800 bg-slate-900/40">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mx-auto mb-3">
              <Sparkles className="w-6 h-6" />
            </div>
            <h4 className="text-base font-semibold text-white">No tasks in this view</h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              {filter === 'remaining'
                ? 'All tasks for today are checked off! Great job staying on track.'
                : 'Click "Add Dynamic Task" or use the quick presets above to schedule your routine.'}
            </p>
            <div className="mt-4">
              <button
                onClick={onOpenAddTask}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-md transition-all"
              >
                <Plus className="w-4 h-4" />
                Add Your Routine Task
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
