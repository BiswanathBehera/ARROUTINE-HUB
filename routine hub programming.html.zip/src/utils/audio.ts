/**
 * Web Audio API High-Fidelity Acoustic Chime Synthesizer
 * Specifically calibrated for mobile phone & tablet speakers:
 * - Warm 2.1kHz low-pass acoustic filter eliminates harsh/piercing high frequencies
 * - Soft rounded note attacks (35ms) prevent speaker clicks or sudden loudness spikes
 * - Balanced master gain and gentle compressor keep volume comfortable and professional
 */

export type AlarmTuneId = 'aurora-melody' | 'royal-harp' | 'energetic-chime';
export type ChimeVolumeLevel = 'soft' | 'balanced' | 'clear';

interface ChimeNote {
  freq: number;
  harmonyFreq?: number;
  startOffset: number;
  duration: number;
  velocity: number;
}

const TUNE_STORAGE_KEY = 'daily_routine_chime_tune_v2';
const VOLUME_STORAGE_KEY = 'daily_routine_chime_volume_v2';

const VOLUME_GAIN_MAP: Record<ChimeVolumeLevel, number> = {
  soft: 0.28,     // Whisper-gentle chime for quiet rooms / library
  balanced: 0.46, // Optimal mobile speaker calibration (not too loud, warm & clear)
  clear: 0.65,    // Slightly fuller presence while still filtered & non-harsh
};

class SoundEffects {
  private ctx: AudioContext | null = null;
  private warmFilter: BiquadFilterNode | null = null;
  private masterGain: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private alarmInterval: number | null = null;
  private activeOscillators: OscillatorNode[] = [];
  private currentTune: AlarmTuneId = 'aurora-melody';
  private volumeLevel: ChimeVolumeLevel = 'balanced';

  constructor() {
    try {
      const savedTune = localStorage.getItem(TUNE_STORAGE_KEY) as AlarmTuneId | null;
      if (
        savedTune === 'aurora-melody' ||
        savedTune === 'royal-harp' ||
        savedTune === 'energetic-chime'
      ) {
        this.currentTune = savedTune;
      }
      const savedVol = localStorage.getItem(VOLUME_STORAGE_KEY) as ChimeVolumeLevel | null;
      if (savedVol === 'soft' || savedVol === 'balanced' || savedVol === 'clear') {
        this.volumeLevel = savedVol;
      }
    } catch {
      // Ignore storage errors
    }
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();

        // 1. Warm Acoustic Low-Pass Filter: rolls off harsh >2000Hz mobile speaker resonance
        this.warmFilter = this.ctx.createBiquadFilter();
        this.warmFilter.type = 'lowpass';
        this.warmFilter.frequency.setValueAtTime(2050, this.ctx.currentTime);
        this.warmFilter.Q.setValueAtTime(0.65, this.ctx.currentTime);

        // 2. Gentle Master Limiter / Compressor: prevents any sudden volume peaks
        this.compressor = this.ctx.createDynamicsCompressor();
        this.compressor.threshold.setValueAtTime(-20, this.ctx.currentTime);
        this.compressor.knee.setValueAtTime(24, this.ctx.currentTime);
        this.compressor.ratio.setValueAtTime(6, this.ctx.currentTime);
        this.compressor.attack.setValueAtTime(0.015, this.ctx.currentTime);
        this.compressor.release.setValueAtTime(0.28, this.ctx.currentTime);

        // 3. Mobile-Calibrated Master Gain
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(
          VOLUME_GAIN_MAP[this.volumeLevel],
          this.ctx.currentTime
        );

        this.warmFilter.connect(this.masterGain);
        this.masterGain.connect(this.compressor);
        this.compressor.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  private getOutputNode(): AudioNode | null {
    this.initCtx();
    if (!this.ctx) return null;
    return this.warmFilter || this.masterGain || this.ctx.destination;
  }

  setAlarmTune(tune: AlarmTuneId) {
    this.currentTune = tune;
    try {
      localStorage.setItem(TUNE_STORAGE_KEY, tune);
    } catch {
      // Ignore
    }
  }

  getAlarmTune(): AlarmTuneId {
    return this.currentTune;
  }

  setVolumeLevel(level: ChimeVolumeLevel) {
    this.volumeLevel = level;
    try {
      localStorage.setItem(VOLUME_STORAGE_KEY, level);
    } catch {
      // Ignore
    }
    if (this.ctx && this.masterGain) {
      this.masterGain.gain.setTargetAtTime(
        VOLUME_GAIN_MAP[level],
        this.ctx.currentTime,
        0.03
      );
    }
  }

  getVolumeLevel(): ChimeVolumeLevel {
    return this.volumeLevel;
  }

  /**
   * Synthesizes a high-fidelity, gentle acoustic vibraphone/bell chime note:
   * - Soft 35ms fade-in envelope so there is zero click or harshness on mobile speakers
   * - Pure sine fundamental in the warm mid-register (340Hz - 980Hz)
   * - Subtle sub-harmonic warmth + delicate fifth/harmonic overtone that decays naturally
   */
  private playAcousticChimeNote(
    freq: number,
    startTime: number,
    duration: number,
    velocity = 0.28,
    harmonyFreq?: number
  ) {
    if (!this.ctx) return;
    const out = this.getOutputNode();
    if (!out) return;

    const attackTime = 0.035; // Smooth, gentle Cushion Attack

    // 1. Pure Sine Fundamental (Warm core chime tone)
    const oscCore = this.ctx.createOscillator();
    const gainCore = this.ctx.createGain();
    oscCore.type = 'sine';
    oscCore.frequency.setValueAtTime(freq, startTime);

    gainCore.gain.setValueAtTime(0.0005, startTime);
    gainCore.gain.linearRampToValueAtTime(velocity, startTime + attackTime);
    gainCore.gain.exponentialRampToValueAtTime(velocity * 0.35, startTime + duration * 0.45);
    gainCore.gain.exponentialRampToValueAtTime(0.0005, startTime + duration);

    oscCore.connect(gainCore);
    gainCore.connect(out);
    oscCore.start(startTime);
    oscCore.stop(startTime + duration + 0.03);
    this.activeOscillators.push(oscCore);

    // 2. Soft Sub-Octave / Warm Wooden Body (adds depth on small phone speakers without loudness)
    const oscWarmth = this.ctx.createOscillator();
    const gainWarmth = this.ctx.createGain();
    oscWarmth.type = 'triangle';
    oscWarmth.frequency.setValueAtTime(freq * 0.5, startTime);

    gainWarmth.gain.setValueAtTime(0.0005, startTime);
    gainWarmth.gain.linearRampToValueAtTime(velocity * 0.22, startTime + attackTime);
    gainWarmth.gain.exponentialRampToValueAtTime(0.0005, startTime + duration * 0.7);

    oscWarmth.connect(gainWarmth);
    gainWarmth.connect(out);
    oscWarmth.start(startTime);
    oscWarmth.stop(startTime + duration * 0.75);
    this.activeOscillators.push(oscWarmth);

    // 3. Delicate Harmonic Shimmer (Soft 5th or gentle overtone, capped below 1600Hz)
    const rawHarmonic = harmonyFreq || freq * 1.498; // Musical perfect fifth by default
    const safeHarmonicFreq = rawHarmonic > 1580 ? freq * 1.25 : rawHarmonic;

    const oscShimmer = this.ctx.createOscillator();
    const gainShimmer = this.ctx.createGain();
    oscShimmer.type = 'sine';
    oscShimmer.frequency.setValueAtTime(safeHarmonicFreq, startTime);

    gainShimmer.gain.setValueAtTime(0.0005, startTime);
    gainShimmer.gain.linearRampToValueAtTime(velocity * 0.16, startTime + attackTime * 0.8);
    gainShimmer.gain.exponentialRampToValueAtTime(0.0005, startTime + duration * 0.55);

    oscShimmer.connect(gainShimmer);
    gainShimmer.connect(out);
    oscShimmer.start(startTime);
    oscShimmer.stop(startTime + duration * 0.6);
    this.activeOscillators.push(oscShimmer);
  }

  // Gentle ascending two-note harmonic chime when a task is completed
  playComplete() {
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      // Warm C5 -> E5 -> G5 soft acoustic chime
      this.playAcousticChimeNote(523.25, now, 0.36, 0.24, 783.99);
      this.playAcousticChimeNote(659.25, now + 0.11, 0.42, 0.26, 987.77);
      this.playAcousticChimeNote(783.99, now + 0.22, 0.65, 0.28, 1174.66);
    } catch {
      // Audio might fail if user has not interacted with DOM yet
    }
  }

  // Subtle, refined single crystal ping for notifications/toggles
  playNotificationPing() {
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      this.playAcousticChimeNote(587.33, now, 0.35, 0.22, 880.0); // D5
      this.playAcousticChimeNote(880.0, now + 0.14, 0.55, 0.25, 1318.5); // A5
    } catch {
      // Ignore audio error
    }
  }

  // Soft low-register woody chime for schedule conflicts
  playWarning() {
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      this.playAcousticChimeNote(392.0, now, 0.32, 0.24, 587.33); // G4
      this.playAcousticChimeNote(329.63, now + 0.16, 0.48, 0.24, 493.88); // E4
    } catch {
      // Ignore audio error
    }
  }

  /**
   * Studio-Grade Gentle Chime Phrases for Task & Class Schedule Alerts:
   * Designed specifically to sound calm, warm, and clear on mobile speakers
   * without ever sounding shrill or overly loud.
   */
  private playAlarmMelodyPhrase(tuneOverride?: AlarmTuneId) {
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const activeTune = tuneOverride || this.currentTune;

      let chimePhrase: ChimeNote[] = [];

      if (activeTune === 'aurora-melody') {
        // "Zen Aurora Chime" — Calm, warm C Major 9 acoustic vibraphone chime
        // Notes stay in the sweet spot (440Hz - 784Hz) for mobile speakers
        chimePhrase = [
          { freq: 523.25, harmonyFreq: 783.99, startOffset: 0.0, duration: 0.65, velocity: 0.28 },  // C5
          { freq: 659.25, harmonyFreq: 987.77, startOffset: 0.28, duration: 0.65, velocity: 0.29 }, // E5
          { freq: 783.99, harmonyFreq: 1174.66, startOffset: 0.56, duration: 0.75, velocity: 0.30 },// G5
          { freq: 659.25, harmonyFreq: 987.77, startOffset: 0.92, duration: 0.65, velocity: 0.26 }, // E5
          { freq: 587.33, harmonyFreq: 880.0, startOffset: 1.24, duration: 1.25, velocity: 0.31 },  // D5 (Warm resonant sustain)
          { freq: 392.0, harmonyFreq: 587.33, startOffset: 1.24, duration: 1.25, velocity: 0.18 },  // G4 warm root bloom
        ];
      } else if (activeTune === 'royal-harp') {
        // "Warm Sanctuary Harp" — Deep, mellow F Major 7 pentatonic chime
        // Lower frequency register (349Hz - 659Hz) for extra-gentle mobile comfort
        chimePhrase = [
          { freq: 349.23, harmonyFreq: 523.25, startOffset: 0.0, duration: 0.70, velocity: 0.28 },  // F4
          { freq: 440.0, harmonyFreq: 659.25, startOffset: 0.30, duration: 0.70, velocity: 0.29 },  // A4
          { freq: 523.25, harmonyFreq: 783.99, startOffset: 0.60, duration: 0.75, velocity: 0.30 }, // C5
          { freq: 659.25, harmonyFreq: 987.77, startOffset: 0.95, duration: 1.35, velocity: 0.31 }, // E5 (Gentle Fmaj7 resolution)
          { freq: 440.0, harmonyFreq: 659.25, startOffset: 0.95, duration: 1.30, velocity: 0.18 },  // A4 warm harmony
        ];
      } else {
        // "Soft Crystal Bell" — Clean, minimal 3-tone studio acoustic chime
        // Inspired by high-end mindfulness & calendar chime alerts
        chimePhrase = [
          { freq: 587.33, harmonyFreq: 880.0, startOffset: 0.0, duration: 0.60, velocity: 0.28 },   // D5
          { freq: 739.99, harmonyFreq: 1108.73, startOffset: 0.32, duration: 0.65, velocity: 0.29 },// F#5
          { freq: 880.0, harmonyFreq: 1318.51, startOffset: 0.66, duration: 1.40, velocity: 0.31 }, // A5 (Pure, calm bell decay)
          { freq: 440.0, harmonyFreq: 659.25, startOffset: 0.66, duration: 1.35, velocity: 0.18 },  // A4 warm fundamental
        ];
      }

      chimePhrase.forEach((note) => {
        this.playAcousticChimeNote(
          note.freq,
          now + note.startOffset,
          note.duration,
          note.velocity,
          note.harmonyFreq
        );
      });
    } catch {
      // Audio error
    }
  }

  // Play a single preview phrase of the gentle chime tune
  playAlarmPreview(tuneOverride?: AlarmTuneId) {
    this.stopAlarm();
    this.playAlarmMelodyPhrase(tuneOverride);
  }

  // Start gentle repeating chime alert (spaced every 3600ms for calm breathing room)
  startTaskAlarm(maxCycles = 8, tuneOverride?: AlarmTuneId) {
    this.stopAlarm();
    this.playAlarmMelodyPhrase(tuneOverride);

    let cycles = 1;
    this.alarmInterval = window.setInterval(() => {
      this.playAlarmMelodyPhrase(tuneOverride);
      cycles++;
      if (cycles >= maxCycles) {
        this.stopAlarm();
      }
    }, 3600);
  }

  // Stop active repeating alarm immediately
  stopAlarm() {
    if (this.alarmInterval !== null) {
      clearInterval(this.alarmInterval);
      this.alarmInterval = null;
    }
    if (this.activeOscillators.length > 0) {
      this.activeOscillators.forEach((osc) => {
        try {
          osc.stop();
          osc.disconnect();
        } catch {
          // already stopped
        }
      });
      this.activeOscillators = [];
    }
  }

  // Warm 4-note milestone celebration chime
  playStreakMilestoneChime() {
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const notes = [440.0, 554.37, 659.25, 880.0]; // A4, C#5, E5, A5 (Warm A Major)

      notes.forEach((freq, idx) => {
        this.playAcousticChimeNote(freq, now + idx * 0.15, 0.6, 0.27, freq * 1.5);
      });
    } catch {
      // Audio error
    }
  }

  // Gentle, soothing nocturnal lullaby chime for wind-down reminder
  playSleepWindDown() {
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      // Calm descending & resolving warm notes: E5 -> C5 -> A4 -> G4 -> F4 -> C5
      const notes = [659.25, 523.25, 440.0, 392.0, 349.23, 523.25];

      notes.forEach((freq, idx) => {
        this.playAcousticChimeNote(freq, now + idx * 0.3, 0.85, 0.24, freq * 1.5);
      });
    } catch {
      // Audio error
    }
  }
}

export const sounds = new SoundEffects();
