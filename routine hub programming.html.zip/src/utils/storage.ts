import {
  CollegeConfig,
  NotificationSettings,
  SleepConfig,
  SleepLogsMap,
  Task,
  UserAccount,
  WeeklyGoal,
} from '../types/routine';
import { getTodayDateString } from './dateUtils';

const TASKS_STORAGE_KEY = 'daily_routine_tasks_v1';
const COLLEGE_CONFIG_KEY = 'daily_routine_college_config_v1';
const SLEEP_CONFIG_KEY = 'daily_routine_sleep_config_v1';
const SLEEP_LOGS_STORAGE_KEY = 'daily_routine_sleep_logs_v1';
const NOTIFICATION_SETTINGS_KEY = 'daily_routine_notifications_v1';
const WEEKLY_GOALS_STORAGE_KEY = 'daily_routine_weekly_goals_v1';
const USER_ACCOUNTS_STORAGE_KEY = 'daily_routine_user_accounts_v1';
const ACTIVE_USER_STORAGE_KEY = 'daily_routine_active_user_v1';
const AUTH_GATE_SEEN_KEY = 'daily_routine_auth_gate_seen_v1';

export const defaultSleepConfig: SleepConfig = {
  enabled: true,
  bedTime: '22:30', // 10:30 PM
  wakeTime: '05:30', // 5:30 AM
  targetHours: 7, // 7 hours restorative sleep
  windDownReminderMinutes: 30, // 10:00 PM wind-down reminder
  windDownEnabled: true,
};


export const defaultCollegeConfig: CollegeConfig = {
  enabled: true,
  commitmentType: 'college',
  collegeName: 'Engineering & Tech Campus',
  startTime: '09:00',
  endTime: '16:00',
  activeDays: [1, 2, 3, 4, 5], // Monday - Friday
  slots: [
    {
      id: 'slot-1',
      name: 'Theory Lecture (Data Structures & Algorithms)',
      room: 'Hall 302',
      startTime: '09:00',
      endTime: '10:30',
      type: 'lecture',
    },
    {
      id: 'slot-2',
      name: 'Computer Networks & OS',
      room: 'Hall 204',
      startTime: '10:45',
      endTime: '12:15',
      type: 'lecture',
    },
    {
      id: 'slot-lunch',
      name: 'Campus Lunch & Refreshment Break',
      room: 'Cafeteria',
      startTime: '12:15',
      endTime: '13:15',
      type: 'break',
    },
    {
      id: 'slot-3',
      name: 'Database & Systems Practical Lab',
      room: 'Lab 4B',
      startTime: '13:15',
      endTime: '15:15',
      type: 'lab',
    },
    {
      id: 'slot-4',
      name: 'Tutorial & Doubts Clearing Session',
      room: 'Room 105',
      startTime: '15:15',
      endTime: '16:00',
      type: 'tutorial',
    },
  ],
};

export const defaultNotificationSettings: NotificationSettings = {
  soundEnabled: true,
  browserNotifications: false,
  reminderAdvanceMinutes: 15,
  hourlyRemainingAlert: true,
  classEndAlarmEnabled: true,
  classStartAlarmEnabled: true,
};

export function getInitialTasks(): Task[] {
  const today = getTodayDateString();

  return [
    {
      id: 'task-1',
      title: 'Morning Gym Workout & Cardio',
      topic: 'Progressive Overload & Bench Press Form',
      learned: 'Retracting the scapula and maintaining a 45-degree elbow tuck protected the rotator cuff and gave stronger pressing drive.',
      category: 'exercise',
      startTime: '06:30',
      endTime: '07:30',
      priority: 'medium',
      completed: true,
      notes: 'Chest & Triceps workout + 15 min treadmill run + protein shake',
      subtasks: [
        { id: 'sub-11', title: 'Dynamic warm-up & stretching', completed: true },
        { id: 'sub-12', title: 'Chest press & cable pushdowns', completed: true },
        { id: 'sub-13', title: '15 min incline walk / run', completed: true },
      ],
      date: today,
    },
    {
      id: 'task-2',
      title: 'Academic Study Hours: Data Structures & Core Concepts',
      topic: 'Binary Search Trees & AVL Balancing',
      learned: 'Learned the 4 rotation cases in AVL trees (LL, RR, LR, RL) to rebalance heights within O(1) time after insertions.',
      category: 'study',
      startTime: '07:45',
      endTime: '08:35',
      priority: 'high',
      completed: true,
      notes: 'Pre-college prep: Binary Trees, Traversal methods, and lecture notes',
      subtasks: [
        { id: 'sub-21', title: 'Revise AVL & Red-Black tree properties', completed: true },
        { id: 'sub-22', title: 'Check university tutorial problem set', completed: true },
      ],
      date: today,
    },
    {
      id: 'task-3',
      title: 'Market Analysis & Trading Session',
      topic: 'Liquidity Zones & Fair Value Gaps (FVG)',
      learned: 'Waited for Asian session high to be swept before entering short trade. Maintained 1:2.5 risk-to-reward ratio with disciplined stop loss.',
      category: 'trading',
      startTime: '16:30',
      endTime: '17:30',
      priority: 'high',
      completed: false,
      notes: 'Post-college market review: Support/Resistance levels, candlestick patterns, and trade journal updates',
      subtasks: [
        { id: 'sub-31', title: 'Screen daily watchlist & trend confirmations', completed: false },
        { id: 'sub-32', title: 'Calculate risk-reward ratios (minimum 1:2)', completed: false },
        { id: 'sub-33', title: 'Log trade notes in trading journal', completed: false },
      ],
      date: today,
    },
    {
      id: 'task-4',
      title: 'Programming & Full-Stack Development',
      topic: 'Dynamic Programming (0/1 Knapsack & Memoization)',
      learned: 'Space optimization trick: We only need the previous row values, so rolling array or iterating right-to-left reduces space from O(N*W) to O(W).',
      category: 'programming',
      startTime: '18:00',
      endTime: '19:45',
      priority: 'high',
      completed: false,
      notes: 'Solve 2 DSA LeetCode problems + Build feature module on Web App',
      subtasks: [
        { id: 'sub-41', title: 'LeetCode Problem: Dynamic Programming Knapsack', completed: false },
        { id: 'sub-42', title: 'Code user authentication state in frontend project', completed: false },
      ],
      date: today,
    },
    {
      id: 'task-5',
      title: 'Video Editing & Thumbnail Design',
      topic: 'Audio Ducking & Color Grading LUTs',
      learned: 'Normalized dialogue to -14 LUFS standard and used 3.5dB sidechain ducking on the background synth music when speaking.',
      category: 'video_editing',
      startTime: '20:15',
      endTime: '21:30',
      priority: 'medium',
      completed: false,
      notes: 'Edit tech tutorial / vlog in Premiere / DaVinci: cuts, B-rolls, audio cleanup, subtitles',
      subtasks: [
        { id: 'sub-51', title: 'Trim timeline & align jump-cuts', completed: false },
        { id: 'sub-52', title: 'Apply sound effects & background audio ducking', completed: false },
        { id: 'sub-53', title: 'Export 4K render and export thumbnail mockup', completed: false },
      ],
      date: today,
    },
    {
      id: 'task-6',
      title: 'Night Study Hours & Wind-Down Prep',
      topic: 'Operating Systems Virtual Memory & Paging',
      learned: 'Understood page tables, Translation Lookaside Buffers (TLB) hits vs misses, and FIFO vs LRU page replacement trade-offs.',
      category: 'study',
      startTime: '21:45',
      endTime: '22:30',
      priority: 'medium',
      completed: false,
      notes: 'Review tomorrow class syllabus, pack bag, read technical book before 10:30 PM sleep',
      subtasks: [
        { id: 'sub-61', title: 'Check university announcements portal', completed: false },
        { id: 'sub-62', title: 'Review tomorrow lab requirements', completed: false },
      ],
      date: today,
    },
  ];
}

export function loadTasksFromStorage(): Task[] {
  try {
    const raw = localStorage.getItem(TASKS_STORAGE_KEY);
    if (!raw) {
      const initial = getInitialTasks();
      saveTasksToStorage(initial);
      return initial;
    }
    return JSON.parse(raw);
  } catch {
    return getInitialTasks();
  }
}

export function saveTasksToStorage(tasks: Task[]): void {
  try {
    localStorage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks));
  } catch (e) {
    console.error('Failed to save tasks', e);
  }
}

export function loadCollegeConfig(): CollegeConfig {
  try {
    const raw = localStorage.getItem(COLLEGE_CONFIG_KEY);
    if (!raw) {
      saveCollegeConfig(defaultCollegeConfig);
      return defaultCollegeConfig;
    }
    const parsed = JSON.parse(raw);
    return {
      commitmentType: 'college',
      ...parsed,
    };
  } catch {
    return defaultCollegeConfig;
  }
}

export function saveCollegeConfig(config: CollegeConfig): void {
  try {
    localStorage.setItem(COLLEGE_CONFIG_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save college config', e);
  }
}

export function loadSleepConfig(): SleepConfig {
  try {
    const raw = localStorage.getItem(SLEEP_CONFIG_KEY);
    if (!raw) {
      saveSleepConfig(defaultSleepConfig);
      return defaultSleepConfig;
    }
    const parsed = JSON.parse(raw);
    return {
      ...defaultSleepConfig,
      ...parsed,
    };
  } catch {
    return defaultSleepConfig;
  }
}

export function saveSleepConfig(config: SleepConfig): void {
  try {
    localStorage.setItem(SLEEP_CONFIG_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save sleep config', e);
  }
}

export function loadNotificationSettings(): NotificationSettings {
  try {
    const raw = localStorage.getItem(NOTIFICATION_SETTINGS_KEY);
    if (!raw) {
      saveNotificationSettings(defaultNotificationSettings);
      return defaultNotificationSettings;
    }
    const parsed = JSON.parse(raw);
    return {
      ...defaultNotificationSettings,
      ...parsed,
    };
  } catch {
    return defaultNotificationSettings;
  }
}

export function saveNotificationSettings(settings: NotificationSettings): void {
  try {
    localStorage.setItem(NOTIFICATION_SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save notification settings', e);
  }
}

export function getDefaultWeeklyGoals(): WeeklyGoal[] {
  return [
    {
      id: 'wg-1',
      title: 'Dynamic Programming & LeetCode Practice',
      category: 'programming',
      targetValue: 12,
      currentValue: 8,
      unit: 'problems',
      completed: false,
      priority: 'high',
      notes: 'Focus on 0/1 Knapsack, Coin Change, and Longest Common Subsequence',
      milestones: [
        { id: 'm-1', title: '0/1 Knapsack & Subset Sum', completed: true },
        { id: 'm-2', title: 'Coin Change I & II', completed: true },
        { id: 'm-3', title: 'Longest Increasing Subsequence (O(NlogN))', completed: true },
        { id: 'm-4', title: 'Edit Distance & Wildcard Matching', completed: false },
      ],
    },
    {
      id: 'wg-2',
      title: 'Risk-Managed Market Trading & Journaling',
      category: 'trading',
      targetValue: 5,
      currentValue: 3,
      unit: 'sessions',
      completed: false,
      priority: 'high',
      notes: 'Strict 1:2 R:R ratio, no revenge trading, review liquidity sweeps post-college',
      milestones: [
        { id: 'm-21', title: 'Monday NY Open Session Analysis', completed: true },
        { id: 'm-22', title: 'Tuesday Fair Value Gap & Fibo entries', completed: true },
        { id: 'm-23', title: 'Mid-week risk check & journal review', completed: true },
        { id: 'm-24', title: 'Friday weekly performance recap', completed: false },
      ],
    },
    {
      id: 'wg-3',
      title: 'YouTube Tech Tutorial & Video Editing',
      category: 'video_editing',
      targetValue: 2,
      currentValue: 1,
      unit: 'videos',
      completed: false,
      priority: 'medium',
      notes: 'Complete script, voiceover cleanup, 4K timeline cuts & attractive thumbnail',
      milestones: [
        { id: 'm-31', title: 'Script & B-Roll recording', completed: true },
        { id: 'm-32', title: 'Rough cuts & voiceover alignment', completed: true },
        { id: 'm-33', title: 'Sound design, audio ducking & color grade', completed: false },
        { id: 'm-34', title: 'Render 4K & Photoshop 3D thumbnail', completed: false },
      ],
    },
    {
      id: 'wg-4',
      title: 'Academic Study & College OS / Networks Mastery',
      category: 'study',
      targetValue: 15,
      currentValue: 11,
      unit: 'hours',
      completed: false,
      priority: 'high',
      notes: 'Virtual Memory, Subnetting, TCP/IP Handshakes, and College Practical Lab prep',
      milestones: [
        { id: 'm-41', title: 'Virtual memory & Page Replacement algorithms', completed: true },
        { id: 'm-42', title: 'Computer Networks IP addressing & CIDR notation', completed: true },
        { id: 'm-43', title: 'Complete Friday lab experiment file writeup', completed: false },
      ],
    },
    {
      id: 'wg-5',
      title: 'Strength Training & Cardio Conditioning',
      category: 'exercise',
      targetValue: 5,
      currentValue: 4,
      unit: 'workouts',
      completed: false,
      priority: 'medium',
      notes: 'Push-Pull-Legs split with 15 min high incline cardio walk each workout',
      milestones: [
        { id: 'm-51', title: 'Chest, Shoulders & Triceps (Push)', completed: true },
        { id: 'm-52', title: 'Back, Rear Delts & Biceps (Pull)', completed: true },
        { id: 'm-53', title: 'Squats, Hamstrings & Calves (Legs)', completed: true },
        { id: 'm-54', title: 'Upper Body hypertrophy + 20m run', completed: true },
        { id: 'm-55', title: 'Full body core & mobility conditioning', completed: false },
      ],
    },
  ];
}

export function loadWeeklyGoals(): WeeklyGoal[] {
  try {
    const raw = localStorage.getItem(WEEKLY_GOALS_STORAGE_KEY);
    if (!raw) {
      const initial = getDefaultWeeklyGoals();
      saveWeeklyGoals(initial);
      return initial;
    }
    return JSON.parse(raw);
  } catch {
    return getDefaultWeeklyGoals();
  }
}

export function saveWeeklyGoals(goals: WeeklyGoal[]): void {
  try {
    localStorage.setItem(WEEKLY_GOALS_STORAGE_KEY, JSON.stringify(goals));
  } catch (e) {
    console.error('Failed to save weekly goals', e);
  }
}

export function getDefaultSleepLogs(): SleepLogsMap {
  const logs: SleepLogsMap = {};
  const todayStr = getTodayDateString();
  const [y, m, d] = todayStr.split('-').map(Number);
  const baseDate = new Date(y, m - 1, d);

  // Realistic 30-day sleep pattern showing 7-8h optimal windows mixed with occasional late study nights
  const pattern = [
    7.5, 7.5, 6.0, 7.0, 8.0, 6.5, 7.5,
    7.0, 5.5, 7.5, 8.0, 7.5, 6.0, 7.0,
    7.5, 8.0, 7.0, 6.5, 7.5, 7.5, 5.5,
    7.0, 8.0, 7.5, 6.0, 7.5, 7.0, 8.0,
    7.5, 7.0,
  ];

  for (let i = 0; i < 30; i++) {
    const dt = new Date(baseDate);
    dt.setDate(baseDate.getDate() - i);
    const yyyy = dt.getFullYear();
    const mm = String(dt.getMonth() + 1).padStart(2, '0');
    const dd = String(dt.getDate()).padStart(2, '0');
    const key = `${yyyy}-${mm}-${dd}`;
    logs[key] = pattern[i % pattern.length];
  }

  return logs;
}

export function loadSleepLogs(): SleepLogsMap {
  try {
    const raw = localStorage.getItem(SLEEP_LOGS_STORAGE_KEY);
    if (!raw) {
      const initial = getDefaultSleepLogs();
      saveSleepLogs(initial);
      return initial;
    }
    return JSON.parse(raw);
  } catch {
    return getDefaultSleepLogs();
  }
}

export function saveSleepLogs(logs: SleepLogsMap): void {
  try {
    localStorage.setItem(SLEEP_LOGS_STORAGE_KEY, JSON.stringify(logs));
  } catch (e) {
    console.error('Failed to save sleep logs', e);
  }
}

export function loadUserAccounts(): UserAccount[] {
  try {
    const raw = localStorage.getItem(USER_ACCOUNTS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveUserAccounts(accounts: UserAccount[]): void {
  try {
    localStorage.setItem(USER_ACCOUNTS_STORAGE_KEY, JSON.stringify(accounts));
  } catch (e) {
    console.error('Failed to save user accounts', e);
  }
}

export function loadActiveUser(): UserAccount | null {
  try {
    const raw = localStorage.getItem(ACTIVE_USER_STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as UserAccount;
  } catch {
    return null;
  }
}

export function saveActiveUser(user: UserAccount | null): void {
  try {
    if (!user) {
      localStorage.removeItem(ACTIVE_USER_STORAGE_KEY);
    } else {
      localStorage.setItem(ACTIVE_USER_STORAGE_KEY, JSON.stringify(user));
    }
  } catch (e) {
    console.error('Failed to save active user', e);
  }
}

export function hasSeenAuthGate(): boolean {
  try {
    return localStorage.getItem(AUTH_GATE_SEEN_KEY) === 'true';
  } catch {
    return false;
  }
}

export function markAuthGateSeen(seen = true): void {
  try {
    if (seen) {
      localStorage.setItem(AUTH_GATE_SEEN_KEY, 'true');
    } else {
      localStorage.removeItem(AUTH_GATE_SEEN_KEY);
    }
  } catch {
    // ignore storage errors
  }
}

export interface UserRoutineSnapshot {
  tasks: Task[];
  collegeConfig: CollegeConfig;
  sleepConfig: SleepConfig;
  sleepLogs: SleepLogsMap;
  weeklyGoals: WeeklyGoal[];
  updatedAt: string;
}

export function saveUserRoutineSnapshot(
  userId: string,
  snapshot: Omit<UserRoutineSnapshot, 'updatedAt'>
): void {
  if (!userId) return;
  try {
    const payload: UserRoutineSnapshot = {
      ...snapshot,
      updatedAt: new Date().toISOString(),
    };
    localStorage.setItem(
      `daily_routine_user_snapshot_${userId}`,
      JSON.stringify(payload)
    );
  } catch (e) {
    console.error('Failed to save user routine snapshot', e);
  }
}

export function loadUserRoutineSnapshot(
  userId: string
): UserRoutineSnapshot | null {
  if (!userId) return null;
  try {
    const raw = localStorage.getItem(`daily_routine_user_snapshot_${userId}`);
    if (!raw) return null;
    return JSON.parse(raw) as UserRoutineSnapshot;
  } catch {
    return null;
  }
}



