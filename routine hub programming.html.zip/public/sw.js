const CACHE_NAME = 'routinehub-pwa-v5';
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/pwa-maskable-512x512.png',
  '/apple-touch-icon.png',
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      await Promise.allSettled(
        PRECACHE_ASSETS.map(async (assetUrl) => {
          try {
            const response = await fetch(assetUrl, { cache: 'reload' });
            if (response && response.ok) {
              await cache.put(assetUrl, response.clone());
            }
          } catch {
            // Ignore individual precache failure so SW installation always succeeds
          }
        })
      );
    })
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.map((key) => {
            if (key !== CACHE_NAME) {
              return caches.delete(key);
            }
            return Promise.resolve();
          })
        )
      )
      .then(() => self.clients.claim())
      .then(async () => {
        const allClients = await self.clients.matchAll({ includeUncontrolled: true });
        for (const client of allClients) {
          client.postMessage({ type: 'SW_READY', cache: CACHE_NAME });
        }
      })
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

async function handleNavigationRequest(request) {
  try {
    const networkResponse = await fetch(request);
    if (networkResponse && networkResponse.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put('/index.html', networkResponse.clone());
      cache.put('/', networkResponse.clone());
      return networkResponse;
    }
    // If server returned 404 or non-OK for a client-side route, fallback to /index.html
    const fallbackResponse = await fetch('/index.html');
    if (fallbackResponse && fallbackResponse.ok) {
      const cache = await caches.open(CACHE_NAME);
      cache.put('/index.html', fallbackResponse.clone());
      return fallbackResponse;
    }
  } catch {
    // Offline or network error — fall through to cache
  }

  const cachedIndex = (await caches.match('/index.html')) || (await caches.match('/'));
  if (cachedIndex) {
    return cachedIndex;
  }
  return Response.error();
}

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  const requestUrl = new URL(event.request.url);
  if (requestUrl.origin !== self.location.origin) return;
  if (
    requestUrl.pathname.startsWith('/api/') ||
    requestUrl.pathname.startsWith('/@vite/') ||
    requestUrl.pathname.startsWith('/@react-refresh') ||
    requestUrl.pathname.startsWith('/@fs/') ||
    requestUrl.pathname.startsWith('/@id/') ||
    requestUrl.pathname.startsWith('/node_modules/')
  ) {
    return;
  }

  // 1. SPA Navigation Fallback: route all navigation requests back to index.html if needed
  if (event.request.mode === 'navigate') {
    event.respondWith(handleNavigationRequest(event.request));
    return;
  }

  // 2. Serve manifest.webmanifest and PWA icons reliably with network-first + cache fallback
  const isManifestOrIcon =
    requestUrl.pathname === '/manifest.webmanifest' ||
    requestUrl.pathname.endsWith('.png') ||
    requestUrl.pathname.endsWith('.webmanifest');

  if (isManifestOrIcon) {
    event.respondWith(
      fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const clone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return networkResponse;
        })
        .catch(async () => {
          const cached = await caches.match(event.request);
          return cached || Response.error();
        })
    );
    return;
  }

  // 3. Standard assets: network-first with cache fallback
  event.respondWith(
    fetch(event.request)
      .then((networkResponse) => {
        if (networkResponse && networkResponse.status === 200) {
          const responseClone = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseClone);
          });
        }
        return networkResponse;
      })
      .catch(async () => {
        const cached = await caches.match(event.request);
        if (cached) return cached;
        return Response.error();
      })
  );
});

