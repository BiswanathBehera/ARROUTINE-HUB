import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import { jsPDF } from 'jspdf';
import {
  X,
  ArrowLeft,
  Download,
  Printer,
  Copy,
  Check,
  FileText,
  FileCode,
  GraduationCap,
  Calendar,
  Clock,
  Sparkles,
  Lightbulb,
  Target,
  Moon,
  FileDown,
} from 'lucide-react';

import { CollegeConfig, SleepConfig, Task, WeeklyGoal } from '../types/routine';
import { CATEGORIES } from '../utils/categories';
import {
  calculateDurationMinutes,
  formatDateLabel,
  formatDuration,
  formatTime12h,
} from '../utils/dateUtils';
import { sounds } from '../utils/audio';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  tasks: Task[];
  collegeConfig: CollegeConfig;
  sleepConfig?: SleepConfig;
  selectedDate: string;
  weeklyGoals?: WeeklyGoal[];
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  tasks,
  collegeConfig,
  sleepConfig,
  selectedDate,
  weeklyGoals = [],
}) => {
  const [activeTab, setActiveTab] = useState<'pdf' | 'json'>('pdf');
  const [isCopied, setIsCopied] = useState(false);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  if (!isOpen) return null;

  const triggerSavedBanner = (msg: string) => {
    setSavedNotice(msg);
    sounds.playComplete();
    setTimeout(() => {
      setSavedNotice(null);
    }, 3000);
  };

  const totalTasks = tasks.length;
  const completedCount = tasks.filter((t) => t.completed).length;
  const remainingCount = tasks.filter((t) => !t.completed).length;
  const completionPercent =
    totalTasks === 0 ? 0 : Math.round((completedCount / totalTasks) * 100);

  // Category durations
  const categoryMinutes: Record<string, number> = {
    study: 0,
    trading: 0,
    video_editing: 0,
    programming: 0,
    exercise: 0,
    college: collegeConfig.enabled
      ? calculateDurationMinutes(collegeConfig.startTime, collegeConfig.endTime)
      : 0,
  };

  tasks.forEach((t) => {
    const dur = calculateDurationMinutes(t.startTime, t.endTime);
    if (categoryMinutes[t.category] !== undefined) {
      categoryMinutes[t.category] += dur;
    }
  });

  const totalRoutineMinutes = Object.values(categoryMinutes).reduce(
    (a, b) => a + b,
    0
  );

  // Generate structured export data object
  const exportData = {
    reportTitle: 'RoutineHub Daily Schedule & Learning Journal',
    generatedAt: new Date().toISOString(),
    date: selectedDate,
    stats: {
      totalTasks,
      completedCount,
      remainingCount,
      completionRate: `${completionPercent}%`,
      totalRoutineDuration: formatDuration(totalRoutineMinutes),
      breakdown: {
        studyHours: formatDuration(categoryMinutes.study),
        trading: formatDuration(categoryMinutes.trading),
        programming: formatDuration(categoryMinutes.programming),
        videoEditing: formatDuration(categoryMinutes.video_editing),
        exercise: formatDuration(categoryMinutes.exercise),
        fixedCollege: formatDuration(categoryMinutes.college),
        restorativeSleep: formatDuration(
          (sleepConfig?.enabled ?? true)
            ? calculateDurationMinutes(
                sleepConfig?.bedTime || '22:30',
                sleepConfig?.wakeTime || '05:30'
              )
            : 0
        ),
      },
    },
    restorativeSleepSchedule: {
      enabled: sleepConfig?.enabled ?? true,
      window: `${formatTime12h(sleepConfig?.bedTime || '22:30')} - ${formatTime12h(
        sleepConfig?.wakeTime || '05:30'
      )}`,
      durationHours: sleepConfig?.targetHours || 7,
      windDownReminder: `${
        sleepConfig?.windDownReminderMinutes || 30
      } mins before sleep (Wind-down alert)`,
    },
    fixedCollegeHours: {
      enabled: collegeConfig.enabled,
      collegeName: collegeConfig.collegeName,
      hours: `${formatTime12h(collegeConfig.startTime)} - ${formatTime12h(
        collegeConfig.endTime
      )}`,
      classSlots: collegeConfig.slots.map((s) => ({
        subject: s.name,
        room: s.room || 'N/A',
        time: `${formatTime12h(s.startTime)} - ${formatTime12h(s.endTime)}`,
        type: s.type,
      })),
    },
    tasks: tasks.map((t) => ({
      id: t.id,
      title: t.title,
      topic: t.topic || 'General',
      category: CATEGORIES[t.category]?.label || t.category,
      time: `${formatTime12h(t.startTime)} - ${formatTime12h(t.endTime)}`,
      durationMinutes: calculateDurationMinutes(t.startTime, t.endTime),
      priority: t.priority.toUpperCase(),
      completed: t.completed,
      whatIHaveLearned: t.learned || null,
      notes: t.notes || null,
      subtasks: t.subtasks.map((s) => ({
        title: s.title,
        completed: s.completed,
      })),
    })),
    learningJournalSummary: tasks
      .filter((t) => t.topic || t.learned)
      .map((t) => ({
        task: t.title,
        category: CATEGORIES[t.category]?.label || t.category,
        topic: t.topic || 'General',
        whatIHaveLearned: t.learned || 'No learning notes logged',
      })),
    weeklyObjectives: weeklyGoals.map((g) => ({
      title: g.title,
      category: CATEGORIES[g.category]?.label || g.category,
      progress: `${g.currentValue} / ${g.targetValue} ${g.unit}`,
      percentage: `${Math.min(
        100,
        Math.round((g.currentValue / Math.max(1, g.targetValue)) * 100)
      )}%`,
      completed: g.completed || g.currentValue >= g.targetValue,
      priority: g.priority?.toUpperCase(),
      notes: g.notes || null,
      milestones:
        g.milestones?.map((m) => ({ title: m.title, completed: m.completed })) ||
        [],
    })),
  };

  const jsonString = JSON.stringify(exportData, null, 2);

  // Helper to reliably download any Blob in desktop browsers, sandboxed iframes & Android WebViews
  const downloadBlobFile = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 300);
  };

  // 1. Direct JSON File Save
  const handleDownloadJSON = () => {
    const blob = new Blob([jsonString], {
      type: 'application/json;charset=utf-8',
    });
    const filename = `RoutineHub-Schedule-${selectedDate}.json`;
    downloadBlobFile(blob, filename);
    triggerSavedBanner(`Saved ${filename}`);
  };

  // 2. Direct Readable Text / Markdown File Save
  const handleDownloadTextFile = () => {
    const lines: string[] = [
      `====================================================================`,
      `ROUTINEHUB DAILY SCHEDULE & LEARNING JOURNAL`,
      `Date: ${formatDateLabel(selectedDate)} (${selectedDate})`,
      `Generated: ${new Date().toLocaleString()}`,
      `====================================================================`,
      ``,
      `SUMMARY METRICS:`,
      `- Completion Rate: ${completionPercent}% (${completedCount}/${totalTasks} tasks done, ${remainingCount} left)`,
      `- Total Scheduled Duration: ${formatDuration(totalRoutineMinutes)}`,
      `- Protected Sleep Window: ${formatTime12h(
        sleepConfig?.bedTime || '22:30'
      )} - ${formatTime12h(sleepConfig?.wakeTime || '05:30')}`,
    ];

    if (collegeConfig.enabled) {
      lines.push(
        `- Fixed ${
          collegeConfig.commitmentType === 'job' ? 'Work' : 'College'
        } Hours (${collegeConfig.collegeName}): ${formatTime12h(
          collegeConfig.startTime
        )} - ${formatTime12h(collegeConfig.endTime)}`
      );
      lines.push(``);
      lines.push(
        `FIXED ${
          collegeConfig.commitmentType === 'job' ? 'WORK SHIFTS' : 'COLLEGE CLASSES'
        }:`
      );
      collegeConfig.slots.forEach((s) => {
        lines.push(
          `  • [${formatTime12h(s.startTime)} - ${formatTime12h(s.endTime)}] ${
            s.name
          } (${s.type}${s.room ? `, Room: ${s.room}` : ''})`
        );
      });
    }

    lines.push(``);
    lines.push(`DAILY ROUTINE TASKS:`);
    if (tasks.length === 0) {
      lines.push(`  No routine tasks scheduled for this date.`);
    } else {
      tasks.forEach((t, idx) => {
        const status = t.completed ? '[DONE]' : '[TODO]';
        const cat = CATEGORIES[t.category]?.label || t.category;
        lines.push(
          `  ${idx + 1}. ${status} ${formatTime12h(t.startTime)} - ${formatTime12h(
            t.endTime
          )} | ${t.title} (${cat}, Priority: ${t.priority.toUpperCase()})`
        );
        if (t.topic) lines.push(`     Topic: ${t.topic}`);
        if (t.learned) lines.push(`     Learned: ${t.learned}`);
        if (t.notes) lines.push(`     Notes: ${t.notes}`);
      });
    }

    if (weeklyGoals.length > 0) {
      lines.push(``);
      lines.push(`WEEKLY GOALS & OBJECTIVES:`);
      weeklyGoals.forEach((g) => {
        lines.push(
          `  • ${g.title}: ${g.currentValue}/${g.targetValue} ${g.unit} (${
            g.completed ? 'Completed' : 'In Progress'
          })`
        );
      });
    }

    const blob = new Blob([lines.join('\n')], {
      type: 'text/plain;charset=utf-8',
    });
    const filename = `RoutineHub-Report-${selectedDate}.txt`;
    downloadBlobFile(blob, filename);
    triggerSavedBanner(`Saved ${filename}`);
  };

  // 3. Direct Real PDF File Generator (using jsPDF — works inside iframes & mobile without popup blockers)
  const handleDownloadPDF = () => {
    try {
      setIsGeneratingPdf(true);
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 14;
      const contentWidth = pageWidth - margin * 2;
      let y = 16;

      const checkPageBreak = (neededHeight: number) => {
        if (y + neededHeight > pageHeight - 16) {
          doc.addPage();
          y = 16;
        }
      };

      // Top Header Banner
      doc.setFillColor(15, 23, 42); // Slate-900
      doc.roundedRect(margin, y, contentWidth, 26, 3, 3, 'F');

      doc.setTextColor(212, 175, 119); // Champagne accent
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.text('ROUTINEHUB DAILY ARCHITECTURE & LEARNING REPORT', margin + 6, y + 7);

      doc.setTextColor(255, 255, 255);
      doc.setFontSize(15);
      doc.text('Daily Schedule & Learning Journal', margin + 6, y + 15);

      doc.setTextColor(203, 213, 225);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.text(
        `Date: ${formatDateLabel(selectedDate)} (${selectedDate})   •   Generated: ${new Date().toLocaleDateString()}`,
        margin + 6,
        y + 21.5
      );

      y += 32;

      // 4 KPI Summary Boxes
      const boxWidth = (contentWidth - 9) / 4;
      const kpis = [
        { label: 'COMPLETION RATE', value: `${completionPercent}%`, color: [79, 70, 229] as [number, number, number] },
        { label: 'TASKS COMPLETED', value: `${completedCount} / ${totalTasks}`, color: [5, 150, 105] as [number, number, number] },
        { label: 'TASKS REMAINING', value: `${remainingCount}`, color: [217, 119, 6] as [number, number, number] },
        { label: 'TOTAL ROUTINE', value: formatDuration(totalRoutineMinutes), color: [15, 23, 42] as [number, number, number] },
      ];

      kpis.forEach((kpi, idx) => {
        const bx = margin + idx * (boxWidth + 3);
        doc.setFillColor(248, 250, 252);
        doc.setDrawColor(226, 232, 240);
        doc.roundedRect(bx, y, boxWidth, 16, 2, 2, 'FD');

        doc.setTextColor(100, 116, 139);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(6.5);
        doc.text(kpi.label, bx + boxWidth / 2, y + 5.5, { align: 'center' });

        doc.setTextColor(kpi.color[0], kpi.color[1], kpi.color[2]);
        doc.setFontSize(11.5);
        doc.text(kpi.value, bx + boxWidth / 2, y + 12.5, { align: 'center' });
      });

      y += 22;

      // Protected College / Work & Sleep Strip
      doc.setFillColor(241, 245, 249);
      doc.setDrawColor(203, 213, 225);
      doc.roundedRect(margin, y, contentWidth, 11, 2, 2, 'FD');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(30, 41, 59);

      const collegeSummary = collegeConfig.enabled
        ? `${collegeConfig.commitmentType === 'job' ? 'Workplace' : 'College'}: ${collegeConfig.collegeName} (${formatTime12h(collegeConfig.startTime)} - ${formatTime12h(collegeConfig.endTime)})`
        : 'Fixed Hours: Disabled';
      const sleepSummary = `Protected Sleep: ${formatTime12h(sleepConfig?.bedTime || '22:30')} - ${formatTime12h(sleepConfig?.wakeTime || '05:30')} (${sleepConfig?.targetHours || 7}h)`;

      doc.text(`${collegeSummary}    |    ${sleepSummary}`, margin + 4, y + 7);
      y += 16;

      // Fixed College / Work Schedule Section
      if (collegeConfig.enabled && collegeConfig.slots.length > 0) {
        checkPageBreak(24);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.setTextColor(15, 23, 42);
        doc.text(
          `FIXED ${collegeConfig.commitmentType === 'job' ? 'WORKPLACE SHIFTS' : 'COLLEGE TIMETABLE'} (${formatTime12h(collegeConfig.startTime)} - ${formatTime12h(collegeConfig.endTime)})`,
          margin,
          y
        );
        y += 2;
        doc.setDrawColor(203, 213, 225);
        doc.line(margin, y, margin + contentWidth, y);
        y += 5;

        collegeConfig.slots.forEach((slot) => {
          checkPageBreak(8);
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(8.5);
          doc.setTextColor(15, 23, 42);
          doc.text(`• ${slot.name}`, margin + 2, y);

          doc.setFont('helvetica', 'normal');
          doc.setTextColor(71, 85, 105);
          const meta = `${formatTime12h(slot.startTime)} - ${formatTime12h(slot.endTime)}  |  ${slot.type.toUpperCase()}${slot.room ? `  |  Room: ${slot.room}` : ''}`;
          doc.text(meta, margin + contentWidth - 2, y, { align: 'right' });
          y += 5.5;
        });

        y += 4;
      }

      // Daily Routine Tasks Table
      checkPageBreak(26);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(15, 23, 42);
      doc.text('DAILY SELF-UPGRADE ROUTINE & SCHEDULE', margin, y);
      y += 2;
      doc.setDrawColor(203, 213, 225);
      doc.line(margin, y, margin + contentWidth, y);
      y += 4;

      // Table Header
      doc.setFillColor(241, 245, 249);
      doc.rect(margin, y, contentWidth, 7, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(71, 85, 105);
      doc.text('STATUS', margin + 2, y + 4.8);
      doc.text('TIME SLOT', margin + 20, y + 4.8);
      doc.text('CATEGORY', margin + 56, y + 4.8);
      doc.text('TASK TITLE & TOPIC', margin + 88, y + 4.8);
      doc.text('PRIORITY', margin + contentWidth - 2, y + 4.8, { align: 'right' });
      y += 9;

      if (tasks.length === 0) {
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(8.5);
        doc.setTextColor(100, 116, 139);
        doc.text('No routine tasks scheduled for this date.', margin + 2, y + 2);
        y += 8;
      } else {
        tasks.forEach((t) => {
          checkPageBreak(10);
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(8);
          if (t.completed) {
            doc.setTextColor(5, 150, 105);
            doc.text('DONE', margin + 2, y + 3);
          } else {
            doc.setTextColor(217, 119, 6);
            doc.text('LEFT', margin + 2, y + 3);
          }

          doc.setFont('helvetica', 'normal');
          doc.setTextColor(51, 65, 85);
          doc.text(
            `${formatTime12h(t.startTime)} - ${formatTime12h(t.endTime)}`,
            margin + 20,
            y + 3
          );

          const catLabel = CATEGORIES[t.category]?.label || t.category;
          doc.text(catLabel.slice(0, 16), margin + 56, y + 3);

          doc.setFont('helvetica', 'bold');
          doc.setTextColor(15, 23, 42);
          const titleWithTopic = t.topic ? `${t.title} (${t.topic})` : t.title;
          const truncatedTitle =
            titleWithTopic.length > 42
              ? titleWithTopic.slice(0, 39) + '...'
              : titleWithTopic;
          doc.text(truncatedTitle, margin + 88, y + 3);

          doc.setFont('helvetica', 'bold');
          doc.setFontSize(7.5);
          doc.setTextColor(71, 85, 105);
          doc.text(t.priority.toUpperCase(), margin + contentWidth - 2, y + 3, {
            align: 'right',
          });

          doc.setDrawColor(241, 245, 249);
          doc.line(margin, y + 5.5, margin + contentWidth, y + 5.5);
          y += 7.5;
        });
      }

      y += 4;

      // Weekly Goals Section
      if (weeklyGoals.length > 0) {
        checkPageBreak(22);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(10);
        doc.setTextColor(15, 23, 42);
        doc.text('CURRENT WEEK OBJECTIVES & GOALS', margin, y);
        y += 2;
        doc.setDrawColor(203, 213, 225);
        doc.line(margin, y, margin + contentWidth, y);
        y += 5;

        weeklyGoals.forEach((g) => {
          checkPageBreak(8);
          const pct = Math.min(
            100,
            Math.round((g.currentValue / Math.max(1, g.targetValue)) * 100)
          );
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(8.5);
          doc.setTextColor(15, 23, 42);
          doc.text(`• ${g.title}`, margin + 2, y);

          doc.setFont('helvetica', 'normal');
          doc.setTextColor(71, 85, 105);
          doc.text(
            `${g.currentValue} / ${g.targetValue} ${g.unit} (${pct}%)`,
            margin + contentWidth - 2,
            y,
            { align: 'right' }
          );
          y += 5.5;
        });

        y += 4;
      }

      // What I Have Learned Today Section
      const learnedTasks = tasks.filter((t) => t.topic || t.learned);
      checkPageBreak(24);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(15, 23, 42);
      doc.text('WHAT I HAVE LEARNED TODAY (LEARNING JOURNAL)', margin, y);
      y += 2;
      doc.setDrawColor(203, 213, 225);
      doc.line(margin, y, margin + contentWidth, y);
      y += 5;

      if (learnedTasks.length === 0) {
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(8.5);
        doc.setTextColor(100, 116, 139);
        doc.text('No learning takeaways recorded for today.', margin + 2, y);
        y += 8;
      } else {
        learnedTasks.forEach((t) => {
          checkPageBreak(14);
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(8.5);
          doc.setTextColor(15, 23, 42);
          doc.text(
            `• ${t.title}${t.topic ? ` — Topic: ${t.topic}` : ''}`,
            margin + 2,
            y
          );
          y += 4.5;

          if (t.learned) {
            doc.setFont('helvetica', 'normal');
            doc.setFontSize(8);
            doc.setTextColor(51, 65, 85);
            const wrapped = doc.splitTextToSize(t.learned, contentWidth - 8);
            checkPageBreak(wrapped.length * 4 + 3);
            doc.text(wrapped, margin + 5, y);
            y += wrapped.length * 4 + 2;
          } else {
            y += 2;
          }
        });
      }

      // Footer Signature
      checkPageBreak(16);
      y = Math.max(y + 6, pageHeight - 16);
      doc.setDrawColor(203, 213, 225);
      doc.line(margin, y, margin + contentWidth, y);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      doc.text(
        'RoutineHub Offline Study Record • Daily Discipline Tracker',
        margin,
        y + 5
      );
      doc.text(
        'Student Sign / Review: ________________________',
        margin + contentWidth,
        y + 5,
        { align: 'right' }
      );

      const pdfFilename = `RoutineHub-Schedule-${selectedDate}.pdf`;
      // Use Blob download so it works reliably inside sandboxed iframes & mobile webviews
      const pdfBlob = doc.output('blob');
      downloadBlobFile(pdfBlob, pdfFilename);
      triggerSavedBanner(`Downloaded ${pdfFilename}`);
    } catch (err) {
      console.error('PDF generation failed:', err);
      // Fallback to browser print if needed
      window.print();
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleCopyJSON = () => {
    navigator.clipboard.writeText(jsonString).then(() => {
      setIsCopied(true);
      sounds.playComplete();
      setTimeout(() => setIsCopied(false), 2000);
    });
  };

  const handlePrintPDF = () => {
    window.print();
  };

  const modalContent = (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn print-modal-wrapper"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh] print-modal-box"
      >
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-4 border-b border-slate-800 bg-slate-900/95 no-print shrink-0 gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-cyan-300 hover:text-white transition-colors shrink-0 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Return</span>
            </button>

            <div className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 hidden sm:flex items-center justify-center border border-indigo-500/30 shrink-0">
              <Download className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-bold text-white tracking-tight truncate">
                Export PDF &amp; Save Schedule File
              </h3>
              <p className="text-[11px] sm:text-xs text-slate-400 truncate">
                Download real PDF document, save JSON/TXT backup file, or print report.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Saved Feedback Banner */}
        {savedNotice && (
          <div className="px-6 py-2.5 bg-emerald-950/90 border-b border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-between no-print animate-fadeIn">
            <span className="flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400" />
              {savedNotice}
            </span>
            <span className="text-[11px] text-emerald-400/80 font-mono">
              Check your browser / device downloads
            </span>
          </div>
        )}

        {/* Tab Switcher & Always-Visible Export PDF + Save File Toolbar */}
        <div className="px-4 sm:px-6 py-3 border-b border-slate-800/80 bg-slate-950 flex flex-wrap items-center justify-between gap-3 no-print shrink-0">
          <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveTab('pdf')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'pdf'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>PDF Report Preview</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('json')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'json'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileCode className="w-4 h-4" />
              <span>JSON Backup Data</span>
            </button>
          </div>

          {/* Primary Direct Download & Save Actions (Always Visible on Both Tabs) */}
          <div className="flex flex-wrap items-center gap-2">
            {/* 1. Direct PDF Download */}
            <button
              type="button"
              onClick={handleDownloadPDF}
              disabled={isGeneratingPdf}
              className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-bold rounded-xl shadow-md transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            >
              <FileDown className="w-4 h-4" />
              <span>{isGeneratingPdf ? 'Generating PDF...' : 'Export PDF (.pdf)'}</span>
            </button>

            {/* 2. Direct Save File (.JSON) */}
            <button
              type="button"
              onClick={handleDownloadJSON}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold rounded-xl shadow-md transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Save File (.json)</span>
            </button>

            {/* 3. Direct Save Text Report (.TXT) */}
            <button
              type="button"
              onClick={handleDownloadTextFile}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors cursor-pointer"
              title="Download human-readable text summary file"
            >
              <FileText className="w-3.5 h-3.5 text-cyan-400" />
              <span>Save .TXT</span>
            </button>

            {/* 4. Copy or Print */}
            {activeTab === 'json' ? (
              <button
                type="button"
                onClick={handleCopyJSON}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors cursor-pointer"
              >
                {isCopied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-300">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-indigo-400" />
                    <span>Copy JSON</span>
                  </>
                )}
              </button>
            ) : (
              <button
                type="button"
                onClick={handlePrintPDF}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors cursor-pointer"
                title="Open system print dialog"
              >
                <Printer className="w-3.5 h-3.5 text-indigo-400" />
                <span className="hidden sm:inline">Print</span>
              </button>
            )}
          </div>
        </div>

        {/* Modal Body / Preview Stage */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-950/60 print-modal-body">
          {activeTab === 'pdf' ? (
            /* PRINTABLE DOCUMENT VIEW (Styled for paper rendering) */
            <div
              id="printable-report"
              className="print-only bg-white text-slate-900 p-6 sm:p-10 rounded-2xl shadow-xl max-w-3xl mx-auto space-y-6 border border-slate-200"
            >
              {/* Document Header */}
              <div className="border-b-2 border-slate-900 pb-5 flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-indigo-700 text-xs font-bold uppercase tracking-widest mb-1">
                    <Sparkles className="w-4 h-4" />
                    RoutineHub Productivity Daily Report
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900">
                    Daily Schedule &amp; Learning Journal
                  </h1>
                  <p className="text-xs text-slate-500 mt-1 flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                    <span>
                      Date: <strong>{formatDateLabel(selectedDate)}</strong>
                    </span>
                    <span>•</span>
                    <span>Generated: {new Date().toLocaleDateString()}</span>
                  </p>
                </div>

                {/* College & Sleep Badges */}
                <div className="flex flex-col items-start sm:items-end gap-2">
                  {collegeConfig.enabled && (
                    <div className="text-left sm:text-right border-l-2 sm:border-l-0 sm:pl-0 pl-3 border-sky-200">
                      <div className="inline-flex items-center gap-1 text-xs font-bold text-sky-800 bg-sky-50 px-2.5 py-1 rounded-lg border border-sky-200">
                        <GraduationCap className="w-4 h-4 text-sky-600" />
                        <span>{collegeConfig.collegeName}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                        Fixed Hours: {formatTime12h(collegeConfig.startTime)} -{' '}
                        {formatTime12h(collegeConfig.endTime)}
                      </div>
                    </div>
                  )}

                  {(sleepConfig?.enabled ?? true) && (
                    <div className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-900 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200">
                      <Moon className="w-3.5 h-3.5 text-indigo-700" />
                      <span>
                        Restorative Sleep: {formatTime12h(sleepConfig?.bedTime || '22:30')} –{' '}
                        {formatTime12h(sleepConfig?.wakeTime || '05:30')} (7h Protected)
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Productivity KPI Summary Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-center">
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
                    Completion Rate
                  </span>
                  <span className="text-xl font-black text-indigo-600 font-mono">
                    {completionPercent}%
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-center">
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
                    Tasks Completed
                  </span>
                  <span className="text-xl font-black text-emerald-600 font-mono">
                    {completedCount} / {totalTasks}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-center">
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
                    Tasks Left
                  </span>
                  <span className="text-xl font-black text-amber-600 font-mono">
                    {remainingCount}
                  </span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-center">
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">
                    Total Routine
                  </span>
                  <span className="text-xl font-black text-slate-900 font-mono">
                    {formatDuration(totalRoutineMinutes)}
                  </span>
                </div>
              </div>

              {/* Current Week Objectives Summary */}
              {weeklyGoals.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 border-b border-slate-200 pb-1">
                    <Target className="w-4 h-4 text-indigo-600" />
                    Current Week Objectives &amp; Long-Term Goals
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {weeklyGoals.map((g) => {
                      const isDone = g.completed || g.currentValue >= g.targetValue;
                      const pct = Math.min(
                        100,
                        Math.round((g.currentValue / Math.max(1, g.targetValue)) * 100)
                      );
                      return (
                        <div
                          key={g.id}
                          className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 flex flex-col justify-between"
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-slate-900 truncate pr-2">
                              {g.title}
                            </span>
                            <span
                              className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${
                                isDone
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-indigo-100 text-indigo-800'
                              }`}
                            >
                              {isDone ? '✓ Completed' : `${pct}%`}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                            <span>{CATEGORIES[g.category]?.label || g.category}</span>
                            <span>
                              {g.currentValue} / {g.targetValue} {g.unit}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Fixed College Schedule Section */}
              {collegeConfig.enabled && (
                <div className="space-y-2">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 border-b border-slate-200 pb-1">
                    <GraduationCap className="w-4 h-4 text-sky-600" />
                    Fixed {collegeConfig.commitmentType === 'job' ? 'Work' : 'College'} Hours (
                    {formatTime12h(collegeConfig.startTime)} -{' '}
                    {formatTime12h(collegeConfig.endTime)})
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {collegeConfig.slots.map((s) => (
                      <div
                        key={s.id}
                        className="p-2 bg-sky-50/70 rounded-lg border border-sky-100 flex items-center justify-between"
                      >
                        <div>
                          <div className="font-bold text-slate-900">{s.name}</div>
                          <div className="text-[10px] text-slate-500">
                            {s.room ? `Room ${s.room} • ` : ''}
                            <span className="capitalize">{s.type}</span>
                          </div>
                        </div>
                        <span className="font-mono text-[11px] text-sky-800 font-semibold shrink-0 ml-2">
                          {formatTime12h(s.startTime)} - {formatTime12h(s.endTime)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Daily Schedule Table */}
              <div className="space-y-2 overflow-x-auto">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 border-b border-slate-200 pb-1">
                  <Clock className="w-4 h-4 text-indigo-600" />
                  Daily Routine Tasks &amp; Topics Schedule
                </h3>

                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 text-[10px] uppercase font-bold">
                      <th className="py-2 pr-2">Status</th>
                      <th className="py-2 pr-2">Time</th>
                      <th className="py-2 pr-2">Category</th>
                      <th className="py-2 pr-2">Task Title</th>
                      <th className="py-2 pr-2">Topic Focus</th>
                      <th className="py-2 text-right">Priority</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {tasks.map((t) => (
                      <tr key={t.id} className="hover:bg-slate-50/50">
                        <td className="py-2 pr-2">
                          {t.completed ? (
                            <span className="text-emerald-600 font-bold flex items-center gap-1">
                              ✓ Done
                            </span>
                          ) : (
                            <span className="text-amber-600 font-medium">○ Left</span>
                          )}
                        </td>
                        <td className="py-2 pr-2 font-mono whitespace-nowrap text-slate-700">
                          {formatTime12h(t.startTime)} - {formatTime12h(t.endTime)}
                        </td>
                        <td className="py-2 pr-2 font-semibold capitalize text-slate-800">
                          {CATEGORIES[t.category]?.label || t.category}
                        </td>
                        <td className="py-2 pr-2 font-bold text-slate-900">{t.title}</td>
                        <td className="py-2 pr-2 text-slate-600">
                          {t.topic ? (
                            <span className="font-medium text-indigo-700">{t.topic}</span>
                          ) : (
                            <span className="text-slate-400 italic">—</span>
                          )}
                        </td>
                        <td className="py-2 text-right">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                              t.priority === 'high'
                                ? 'bg-rose-100 text-rose-800'
                                : t.priority === 'medium'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {t.priority}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* What I Have Learned Today / Journal Section */}
              <div className="space-y-3 pt-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5 border-b border-slate-200 pb-1">
                  <Lightbulb className="w-4 h-4 text-amber-500" />
                  What I Have Learned Today (Learning Journal Takeaways)
                </h3>

                <div className="space-y-2.5">
                  {tasks.filter((t) => t.topic || t.learned).length > 0 ? (
                    tasks
                      .filter((t) => t.topic || t.learned)
                      .map((t) => (
                        <div
                          key={t.id}
                          className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-900 flex items-center gap-1.5">
                              <span className="w-2 h-2 rounded-full bg-indigo-600" />
                              {t.title} ({CATEGORIES[t.category]?.label || t.category})
                            </span>
                            {t.topic && (
                              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
                                Topic: {t.topic}
                              </span>
                            )}
                          </div>
                          {t.learned ? (
                            <p className="text-slate-700 leading-relaxed pl-3 border-l-2 border-amber-400 mt-1">
                              {t.learned}
                            </p>
                          ) : (
                            <p className="text-slate-400 italic text-[11px] pl-3">
                              Session completed without notes.
                            </p>
                          )}
                        </div>
                      ))
                  ) : (
                    <p className="text-xs text-slate-400 italic">
                      No learning takeaways recorded for today.
                    </p>
                  )}
                </div>
              </div>

              {/* Signature / Review Footer on Printed Sheet */}
              <div className="pt-6 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
                <div>
                  <span>RoutineHub Offline Study Record • </span>
                  <span>Daily Discipline Tracker</span>
                </div>
                <div className="text-right">
                  <span>Student Sign / Review: ____________________</span>
                </div>
              </div>
            </div>
          ) : (
            /* JSON CODE PREVIEW */
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>
                  Formatted JSON representation with all tasks, topics, times, and learning logs:
                </span>
                <span className="font-mono text-indigo-400 font-semibold">
                  {(new TextEncoder().encode(jsonString).length / 1024).toFixed(1)} KB
                </span>
              </div>

              <div className="relative">
                <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-emerald-400 font-mono text-xs overflow-x-auto max-h-[55vh] selection:bg-emerald-800 selection:text-white leading-relaxed">
                  <code>{jsonString}</code>
                </pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined'
    ? createPortal(modalContent, document.body)
    : modalContent;
};
