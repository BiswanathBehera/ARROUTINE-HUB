import React, { useMemo, useState } from 'react';
import { Task } from '../types/routine';
import { Flame, CheckCircle2, CalendarDays, ChevronLeft, ChevronRight, Award, BarChart2 } from 'lucide-react';

interface WeeklyHeatMapTrackerProps {
  tasks: Task[];
  selectedDate: string;
  onSelectDate: (date: string) => void;
  defaultMode?: 'weekly' | 'monthly';
}

interface DayHeatCell {
  date: string;
  dayShortName: string;
  dayNumber: number;
  monthShortName: string;
  totalTasks: number;
  completedTasks: number;
  completionRate: number;
  intensity: 0 | 1 | 2 | 3 | 4;
  isToday: boolean;
  isSelected: boolean;
  isCurrentMonth: boolean;
}

const WEEKDAY_HEADERS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export const WeeklyHeatMapTracker: React.FC<WeeklyHeatMapTrackerProps> = ({
  tasks,
  selectedDate,
  onSelectDate,
  defaultMode = 'weekly',
}) => {
  const [viewMode, setViewMode] = useState<'weekly' | 'monthly'>(defaultMode);

  const formatLocalDate = (d: Date) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const todayStr = useMemo(() => formatLocalDate(new Date()), []);

  // Build lookup map of daily non-college tasks by date for fast O(1) per-day calculation
  const tasksByDate = useMemo(() => {
    const map = new Map<string, { total: number; completed: number }>();
    for (const t of tasks) {
      if (t.isCollegeFixed || t.category === 'college') continue;
      const entry = map.get(t.date) || { total: 0, completed: 0 };
      entry.total += 1;
      if (t.completed) {
        entry.completed += 1;
      }
      map.set(t.date, entry);
    }
    return map;
  }, [tasks]);

  const buildDayCell = (d: Date, isCurrentMonth = true): DayHeatCell => {
    const dateStr = formatLocalDate(d);
    const counts = tasksByDate.get(dateStr) || { total: 0, completed: 0 };
    const totalTasks = counts.total;
    const completedTasks = counts.completed;
    const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

    let intensity: 0 | 1 | 2 | 3 | 4 = 0;
    if (totalTasks > 0 && completedTasks > 0) {
      if (completionRate === 100) intensity = 4;
      else if (completionRate >= 75) intensity = 3;
      else if (completionRate >= 50) intensity = 2;
      else intensity = 1;
    }

    return {
      date: dateStr,
      dayShortName: d.toLocaleDateString('en-US', { weekday: 'short' }),
      dayNumber: d.getDate(),
      monthShortName: d.toLocaleDateString('en-US', { month: 'short' }),
      totalTasks,
      completedTasks,
      completionRate,
      intensity,
      isToday: dateStr === todayStr,
      isSelected: dateStr === selectedDate,
      isCurrentMonth,
    };
  };

  // Compute Monday-to-Sunday week containing selectedDate
  const weekDays = useMemo(() => {
    const [year, month, day] = selectedDate.split('-').map(Number);
    const current = new Date(year, month - 1, day);
    const dayOfWeek = current.getDay();
    const diffToMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;

    const monday = new Date(current);
    monday.setDate(current.getDate() + diffToMonday);

    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      return buildDayCell(d, true);
    });
  }, [selectedDate, tasksByDate, todayStr]);

  // Compute full Monday-to-Sunday aligned calendar grid for the month of selectedDate
  const { monthGrid, monthLabel, currentMonthDays } = useMemo(() => {
    const [year, month] = selectedDate.split('-').map(Number);
    const firstDayOfMonth = new Date(year, month - 1, 1);
    const lastDayOfMonth = new Date(year, month, 0);
    const daysInMonth = lastDayOfMonth.getDate();

    const monthName = firstDayOfMonth.toLocaleDateString('en-US', {
      month: 'long',
      year: 'numeric',
    });

    // Monday = 0 ... Sunday = 6
    const firstWeekday = firstDayOfMonth.getDay();
    const leadingPadding = firstWeekday === 0 ? 6 : firstWeekday - 1;

    const cells: DayHeatCell[] = [];
    const activeMonthCells: DayHeatCell[] = [];

    // Leading days from previous month
    for (let i = leadingPadding; i > 0; i--) {
      const d = new Date(year, month - 1, 1 - i);
      cells.push(buildDayCell(d, false));
    }

    // Current month days
    for (let dayNum = 1; dayNum <= daysInMonth; dayNum++) {
      const d = new Date(year, month - 1, dayNum);
      const cell = buildDayCell(d, true);
      cells.push(cell);
      activeMonthCells.push(cell);
    }

    // Trailing days from next month to complete the final 7-day row
    const remainder = cells.length % 7;
    const trailingPadding = remainder === 0 ? 0 : 7 - remainder;
    for (let i = 1; i <= trailingPadding; i++) {
      const d = new Date(year, month, i);
      cells.push(buildDayCell(d, false));
    }

    return {
      monthGrid: cells,
      monthLabel: monthName,
      currentMonthDays: activeMonthCells,
    };
  }, [selectedDate, tasksByDate, todayStr]);

  // Aggregate progress summary for active view mode (Weekly or Monthly)
  const summary = useMemo(() => {
    const targetDays = viewMode === 'weekly' ? weekDays : currentMonthDays;
    const totalTasks = targetDays.reduce((acc, d) => acc + d.totalTasks, 0);
    const completedTasks = targetDays.reduce((acc, d) => acc + d.completedTasks, 0);
    const overallCompletionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    const perfectDaysCount = targetDays.filter(d => d.totalTasks > 0 && d.completedTasks === d.totalTasks).length;
    const activeDaysCount = targetDays.filter(d => d.completedTasks > 0).length;

    // Calculate consecutive completion streak across the active period up to today/selectedDate
    let streak = 0;
    for (const day of targetDays) {
      if (day.date > todayStr && day.completedTasks === 0) continue;
      if (day.totalTasks > 0 && day.completedTasks > 0) {
        streak++;
      } else if (day.date <= todayStr && day.totalTasks > 0 && day.completedTasks === 0) {
        streak = 0;
      }
    }

    return {
      totalTasks,
      completedTasks,
      overallCompletionRate,
      perfectDaysCount,
      activeDaysCount,
      totalDaysInPeriod: targetDays.length,
      streak,
    };
  }, [viewMode, weekDays, currentMonthDays, todayStr]);

  const handleNavigate = (direction: -1 | 1) => {
    const [year, month, day] = selectedDate.split('-').map(Number);
    if (viewMode === 'weekly') {
      const current = new Date(year, month - 1, day);
      current.setDate(current.getDate() + direction * 7);
      onSelectDate(formatLocalDate(current));
    } else {
      const targetMonthDate = new Date(year, month - 1 + direction, 1);
      const maxDayInTargetMonth = new Date(
        targetMonthDate.getFullYear(),
        targetMonthDate.getMonth() + 1,
        0
      ).getDate();
      targetMonthDate.setDate(Math.min(day, maxDayInTargetMonth));
      onSelectDate(formatLocalDate(targetMonthDate));
    }
  };

  const getIntensityStyles = (intensity: 0 | 1 | 2 | 3 | 4, isCurrentMonth = true) => {
    if (!isCurrentMonth) {
      switch (intensity) {
        case 4:
          return 'bg-emerald-500/40 text-white border-emerald-500/40 opacity-60';
        case 3:
          return 'bg-emerald-400/35 text-emerald-950 dark:text-emerald-100 border-emerald-400/40 opacity-60';
        case 2:
          return 'bg-emerald-300/35 text-emerald-950 dark:text-emerald-100 border-emerald-300/40 opacity-60';
        case 1:
          return 'bg-emerald-100/50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-300 border-emerald-200/50 dark:border-emerald-800/40 opacity-60';
        default:
          return 'bg-slate-50/50 dark:bg-slate-900/30 text-slate-400 dark:text-slate-600 border-slate-200/50 dark:border-slate-800/50 opacity-55';
      }
    }

    switch (intensity) {
      case 4:
        return 'bg-emerald-600 dark:bg-emerald-500 text-white border-emerald-700 dark:border-emerald-400 shadow-sm shadow-emerald-500/20';
      case 3:
        return 'bg-emerald-500/85 dark:bg-emerald-600/80 text-white border-emerald-600 dark:border-emerald-500';
      case 2:
        return 'bg-emerald-300 dark:bg-emerald-800/80 text-emerald-950 dark:text-emerald-100 border-emerald-400 dark:border-emerald-700';
      case 1:
        return 'bg-emerald-100 dark:bg-emerald-950/70 text-emerald-900 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/80';
      default:
        return 'bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400 border-slate-200/80 dark:border-slate-700/70';
    }
  };

  const weekRangeLabel = `${weekDays[0].monthShortName} ${weekDays[0].dayNumber} – ${weekDays[6].monthShortName} ${weekDays[6].dayNumber}`;
  const periodLabel = viewMode === 'weekly' ? 'Weekly' : 'Monthly';

  return (
    <div className="bg-white dark:bg-slate-900 p-5 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 transition-colors">
      {/* Header Row with View Switcher & Date Navigation */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-5">
        <div>
          <div className="flex flex-wrap items-center gap-2.5">
            <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Flame className="w-5 h-5 text-emerald-500 shrink-0" />
              <span>{periodLabel} Task Completion Heat Map</span>
            </h3>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
              · {summary.activeDaysCount}/{summary.totalDaysInPeriod} active days
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Tracks daily personal task completion intensity across your {viewMode === 'weekly' ? 'Monday–Sunday week' : 'calendar month'}. Click any day to inspect or update tasks.
          </p>
        </div>

        {/* Controls: Weekly/Monthly Switch + Date Navigator */}
        <div className="flex flex-wrap items-center gap-2.5 self-start lg:self-auto">
          {/* Segmented Weekly / Monthly Switch Button */}
          <div
            role="group"
            aria-label="Heat map period switch"
            className="inline-flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200/80 dark:border-slate-700/70"
          >
            <button
              type="button"
              onClick={() => setViewMode('weekly')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                viewMode === 'weekly'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Weekly
            </button>
            <button
              type="button"
              onClick={() => setViewMode('monthly')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                viewMode === 'monthly'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Monthly
            </button>
          </div>

          {/* Date Range / Month Navigator */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200/80 dark:border-slate-700/70">
            <button
              type="button"
              onClick={() => handleNavigate(-1)}
              className="p-1.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
              title={viewMode === 'weekly' ? 'Previous Week' : 'Previous Month'}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 px-2.5 font-mono tabular-nums whitespace-nowrap shrink-0">
              {viewMode === 'weekly' ? weekRangeLabel : monthLabel}
            </span>
            <button
              type="button"
              onClick={() => handleNavigate(1)}
              className="p-1.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
              title={viewMode === 'weekly' ? 'Next Week' : 'Next Month'}
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {selectedDate !== todayStr && (
            <button
              type="button"
              onClick={() => onSelectDate(todayStr)}
              className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/80 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Today
            </button>
          )}
        </div>
      </div>

      {/* Period Progress Bar */}
      <div className="mb-5 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-800">
        <div className="flex items-center justify-between gap-4 mb-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
            <BarChart2 className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>{periodLabel} Completion Progress</span>
            <span className="text-slate-400 dark:text-slate-500">·</span>
            <span className="font-mono tabular-nums text-slate-600 dark:text-slate-400">
              {summary.completedTasks} of {summary.totalTasks} daily tasks finished
            </span>
          </div>
          <span className="text-sm font-bold font-mono tabular-nums text-emerald-600 dark:text-emerald-400">
            {summary.overallCompletionRate}%
          </span>
        </div>
        <div className="w-full h-2 bg-slate-200 dark:bg-slate-700/80 rounded-full overflow-hidden">
          <div
            className="h-full bg-emerald-500 dark:bg-emerald-400 rounded-full transition-all duration-300"
            style={{ width: `${summary.overallCompletionRate}%` }}
          />
        </div>
      </div>

      {/* HEAT MAP VIEW: WEEKLY vs MONTHLY */}
      {viewMode === 'weekly' ? (
        /* 7-Day Weekly Heat Map Grid */
        <div className="grid grid-cols-7 gap-2 sm:gap-3 mb-5">
          {weekDays.map((day) => {
            const cellStyle = getIntensityStyles(day.intensity, true);
            return (
              <button
                key={day.date}
                type="button"
                onClick={() => onSelectDate(day.date)}
                title={`${day.dayShortName}, ${day.monthShortName} ${day.dayNumber}: ${day.completedTasks}/${day.totalTasks} tasks completed (${day.completionRate}%)`}
                className={`group relative flex flex-col items-center justify-between p-2.5 sm:p-3.5 rounded-xl border transition-all cursor-pointer text-left ${cellStyle} ${
                  day.isSelected
                    ? 'ring-2 ring-indigo-600 dark:ring-indigo-400 ring-offset-2 dark:ring-offset-slate-900 scale-[1.02]'
                    : 'hover:scale-[1.02]'
                }`}
              >
                <div className="w-full flex items-center justify-between text-[10px] sm:text-xs font-semibold uppercase tracking-wider opacity-85">
                  <span>{day.dayShortName}</span>
                  {day.isToday && (
                    <span className="text-[9px] font-bold px-1 rounded bg-black/15 dark:bg-white/15">
                      TODAY
                    </span>
                  )}
                </div>

                <div className="my-2 sm:my-3 flex flex-col items-center">
                  <span className="text-base sm:text-xl font-bold font-mono tabular-nums leading-none">
                    {day.dayNumber}
                  </span>
                  <span className="text-[10px] sm:text-xs font-mono tabular-nums mt-1 font-semibold opacity-95">
                    {day.totalTasks > 0 ? `${day.completionRate}%` : '0%'}
                  </span>
                </div>

                <div className="w-full flex items-center justify-center gap-1 pt-1.5 border-t border-current/10 text-[10px] font-mono tabular-nums opacity-90">
                  {day.completionRate === 100 && day.totalTasks > 0 ? (
                    <CheckCircle2 className="w-3 h-3 shrink-0" />
                  ) : null}
                  <span className="truncate">
                    {day.completedTasks}/{day.totalTasks}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      ) : (
        /* Calendar Month Heat Map Grid Aligned Monday to Sunday */
        <div className="mb-5">
          {/* Weekday Column Headers */}
          <div className="grid grid-cols-7 gap-1.5 sm:gap-2 mb-2">
            {WEEKDAY_HEADERS.map((weekday) => (
              <div
                key={weekday}
                className="text-center text-[11px] font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 py-1"
              >
                {weekday}
              </div>
            ))}
          </div>

          {/* Calendar Month Cells */}
          <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
            {monthGrid.map((day) => {
              const cellStyle = getIntensityStyles(day.intensity, day.isCurrentMonth);
              return (
                <button
                  key={day.date}
                  type="button"
                  onClick={() => onSelectDate(day.date)}
                  title={`${day.dayShortName}, ${day.monthShortName} ${day.dayNumber}: ${day.completedTasks}/${day.totalTasks} tasks completed (${day.completionRate}%)`}
                  className={`group relative flex flex-col justify-between p-2 sm:p-2.5 min-h-[72px] sm:min-h-[84px] rounded-xl border transition-all cursor-pointer text-left ${cellStyle} ${
                    day.isSelected
                      ? 'ring-2 ring-indigo-600 dark:ring-indigo-400 ring-offset-1 dark:ring-offset-slate-900 scale-[1.01]'
                      : 'hover:scale-[1.01]'
                  }`}
                >
                  {/* Top Row: Date Number + Today / Complete Indicator */}
                  <div className="w-full flex items-center justify-between gap-1">
                    <span className="text-xs sm:text-sm font-bold font-mono tabular-nums leading-none">
                      {day.dayNumber}
                    </span>
                    {day.isToday ? (
                      <span className="text-[9px] font-bold uppercase px-1 py-0.5 rounded bg-black/15 dark:bg-white/15 leading-none">
                        Today
                      </span>
                    ) : day.completionRate === 100 && day.totalTasks > 0 ? (
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0 opacity-90" />
                    ) : null}
                  </div>

                  {/* Middle Row: Completion Percentage */}
                  <div className="my-1 flex items-baseline justify-between gap-1">
                    <span className="text-xs sm:text-sm font-bold font-mono tabular-nums leading-none">
                      {day.totalTasks > 0 ? `${day.completionRate}%` : '0%'}
                    </span>
                  </div>

                  {/* Bottom Row: Completed / Total Task Count */}
                  <div className="w-full flex items-center justify-between pt-1 border-t border-current/10 text-[10px] font-mono tabular-nums opacity-90">
                    <span className="truncate">
                      {day.completedTasks}/{day.totalTasks} tasks
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Summary Footer & Heat Map Legend */}
      <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="grid grid-cols-3 gap-3 sm:gap-6">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                {periodLabel} Progress
              </p>
              <p className="text-sm sm:text-base font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                {summary.overallCompletionRate}%
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 flex items-center justify-center text-indigo-600 dark:text-indigo-400 shrink-0">
              <CalendarDays className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                Finished Tasks
              </p>
              <p className="text-sm sm:text-base font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                {summary.completedTasks}
                <span className="text-xs font-normal text-slate-400">/{summary.totalTasks}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/60 flex items-center justify-center text-amber-600 dark:text-amber-400 shrink-0">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                100% Days
              </p>
              <p className="text-sm sm:text-base font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                {summary.perfectDaysCount}{' '}
                <span className="text-xs font-normal text-slate-400">
                  / {summary.totalDaysInPeriod}d
                </span>
              </p>
            </div>
          </div>
        </div>

        {/* Heat Map Intensity Scale Legend */}
        <div className="flex items-center gap-2 self-end sm:self-auto text-xs text-slate-500 dark:text-slate-400">
          <span>0%</span>
          <div className="flex items-center gap-1">
            <span
              className="w-3.5 h-3.5 rounded-xs bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700"
              title="0% completed"
            />
            <span
              className="w-3.5 h-3.5 rounded-xs bg-emerald-100 dark:bg-emerald-950/70 border border-emerald-200 dark:border-emerald-800"
              title="1–49% completed"
            />
            <span
              className="w-3.5 h-3.5 rounded-xs bg-emerald-300 dark:bg-emerald-800/80 border border-emerald-400 dark:border-emerald-700"
              title="50–74% completed"
            />
            <span
              className="w-3.5 h-3.5 rounded-xs bg-emerald-500/85 dark:bg-emerald-600/80 border border-emerald-600 dark:border-emerald-500"
              title="75–99% completed"
            />
            <span
              className="w-3.5 h-3.5 rounded-xs bg-emerald-600 dark:bg-emerald-500 border border-emerald-700 dark:border-emerald-400"
              title="100% completed"
            />
          </div>
          <span>100%</span>
        </div>
      </div>
    </div>
  );
};
