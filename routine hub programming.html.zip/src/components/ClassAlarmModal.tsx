import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  AlarmClock,
  BookOpen,
  CheckCircle2,
  Clock,
  GraduationCap,
  MapPin,
  Music,
  Sparkles,
  User,
  Volume2,
  VolumeX,
  X,
  ArrowRight,
} from 'lucide-react';
import { CollegeClassSlot } from '../types/routine';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTime12h,
} from '../utils/dateUtils';
import { sounds, AlarmTuneId, ChimeVolumeLevel } from '../utils/audio';

export interface ClassAlarmPayload {
  slot: CollegeClassSlot;
  mode: 'end' | 'start';
  nextSlot?: CollegeClassSlot | null;
}

interface ClassAlarmModalProps {
  alarm: ClassAlarmPayload | null;
  onDismiss: () => void;
  onSnooze: (alarm: ClassAlarmPayload) => void;
  onSaveClassNotes: (slotId: string, topic: string, learned: string) => void;
}

const ALARM_TUNES: { id: AlarmTuneId; label: string }[] = [
  { id: 'aurora-melody', label: 'Zen Chime' },
  { id: 'royal-harp', label: 'Warm Harp' },
  { id: 'energetic-chime', label: 'Soft Bell' },
];

const VOLUME_LEVELS: { id: ChimeVolumeLevel; label: string }[] = [
  { id: 'soft', label: 'Soft' },
  { id: 'balanced', label: 'Mobile Balanced' },
  { id: 'clear', label: 'Clear' },
];

export const ClassAlarmModal: React.FC<ClassAlarmModalProps> = ({
  alarm,
  onDismiss,
  onSnooze,
  onSaveClassNotes,
}) => {
  const [selectedTune, setSelectedTune] = useState<AlarmTuneId>(() =>
    sounds.getAlarmTune()
  );
  const [volumeLevel, setVolumeLevel] = useState<ChimeVolumeLevel>(() =>
    sounds.getVolumeLevel()
  );
  const [topicInput, setTopicInput] = useState('');
  const [learnedInput, setLearnedInput] = useState('');
  const [isMuted, setIsMuted] = useState(false);

  useEffect(() => {
    if (alarm) {
      setTopicInput(alarm.slot.topic || '');
      setLearnedInput(alarm.slot.learned || '');
      setIsMuted(false);
      sounds.startTaskAlarm(8, selectedTune);
    }
    return () => {
      sounds.stopAlarm();
    };
  }, [alarm]);

  if (!alarm) return null;

  const { slot, mode, nextSlot } = alarm;
  const isEndAlert = mode === 'end';
  const durationMin = calculateDurationMinutes(slot.startTime, slot.endTime);

  const handleSelectTune = (tuneId: AlarmTuneId) => {
    setSelectedTune(tuneId);
    sounds.setAlarmTune(tuneId);
    setIsMuted(false);
    sounds.startTaskAlarm(6, tuneId);
  };

  const handleSelectVolume = (level: ChimeVolumeLevel) => {
    setVolumeLevel(level);
    sounds.setVolumeLevel(level);
    setIsMuted(false);
    sounds.playAlarmPreview(selectedTune);
  };

  const handleMuteSound = () => {
    sounds.stopAlarm();
    setIsMuted(true);
  };

  const handleDismissOnly = () => {
    sounds.stopAlarm();
    onDismiss();
  };

  const handleSaveAndDismiss = (e: React.FormEvent) => {
    e.preventDefault();
    sounds.stopAlarm();
    if (topicInput.trim() || learnedInput.trim()) {
      onSaveClassNotes(slot.id, topicInput.trim(), learnedInput.trim());
    }
    onDismiss();
  };

  const handleSnoozeClick = () => {
    sounds.stopAlarm();
    onSnooze(alarm);
  };

  const modalContent = (
    <div
      onClick={handleDismissOnly}
      className="fixed inset-0 z-[110] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn"
    >
      {/* Subtle ambient glow */}
      <div
        className={`fixed w-64 h-64 rounded-full blur-3xl animate-pulse pointer-events-none ${
          isEndAlert ? 'bg-cyan-500/15' : 'bg-amber-500/15'
        }`}
      />

      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-[90vw] sm:w-[400px] sm:max-w-[400px] max-h-[85dvh] overflow-y-auto box-border bg-slate-900/95 border border-cyan-400/50 rounded-2xl p-4 sm:p-5 shadow-2xl shadow-cyan-950/70 space-y-2.5"
      >
        {/* Consolidated Header: Icon + Status + Title + Mute/Close */}
        <div className="flex items-start justify-between gap-2.5">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="relative shrink-0 w-10 h-10">
              <div className="absolute inset-0 rounded-xl bg-cyan-400/30 animate-ping opacity-75" />
              <div className="relative w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/30">
                <AlarmClock className="w-5 h-5 animate-bounce" />
              </div>
            </div>

            <div className="min-w-0">
              <span
                className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider border ${
                  isEndAlert
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40'
                    : 'bg-amber-500/20 text-amber-300 border-amber-400/40'
                }`}
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full animate-ping ${
                    isEndAlert ? 'bg-emerald-400' : 'bg-amber-400'
                  }`}
                />
                {isEndAlert ? 'Class Finished' : 'Class Starting'}
              </span>

              <h2 className="text-sm sm:text-base font-extrabold text-white tracking-tight truncate mt-0.5">
                {slot.name}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            {!isMuted ? (
              <button
                type="button"
                onClick={handleMuteSound}
                className="inline-flex items-center gap-1 px-2 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-[11px] font-bold text-rose-200 transition-colors cursor-pointer"
              >
                <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                <span>Mute</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setIsMuted(false);
                  sounds.startTaskAlarm(6, selectedTune);
                }}
                className="inline-flex items-center gap-1 px-2 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-[11px] font-bold text-cyan-200 transition-colors cursor-pointer"
              >
                <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>Unmute</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleDismissOnly}
              aria-label="Close Class Alarm"
              className="p-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Class Session Summary Strip */}
        <div className="p-2.5 rounded-xl bg-slate-950/90 border border-slate-800 flex flex-wrap items-center justify-between gap-1.5 text-[11px]">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-sky-500/20 border border-sky-500/30 text-sky-300 font-bold capitalize">
              <GraduationCap className="w-3 h-3" />
              {slot.type}
            </span>
            {slot.room && (
              <span className="inline-flex items-center gap-1 text-slate-300 font-medium">
                <MapPin className="w-3 h-3 text-cyan-400" />
                {slot.room}
              </span>
            )}
            {slot.professor && (
              <span className="inline-flex items-center gap-1 text-slate-400">
                <User className="w-3 h-3 text-violet-400" />
                {slot.professor}
              </span>
            )}
          </div>

          <span className="font-mono font-bold text-cyan-300 flex items-center gap-1">
            <Clock className="w-3 h-3 text-cyan-400" />
            {formatTime12h(slot.startTime)} – {formatTime12h(slot.endTime)} ({formatDuration(durationMin)})
          </span>
        </div>

        {/* Compact Chime Tune & Volume Selector */}
        <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/90 space-y-1.5">
          <div className="flex items-center justify-between text-[11px]">
            <span className="flex items-center gap-1 font-semibold text-amber-300">
              <Music className="w-3 h-3 text-amber-400" />
              Class Chime Tune
            </span>
            <button
              type="button"
              onClick={() => {
                setIsMuted(false);
                sounds.playAlarmPreview(selectedTune);
              }}
              className="inline-flex items-center gap-1 text-cyan-300 hover:text-cyan-200 font-semibold cursor-pointer"
            >
              <Volume2 className="w-3 h-3" />
              <span>Preview</span>
            </button>
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            {ALARM_TUNES.map((tune) => {
              const isSelected = selectedTune === tune.id;
              return (
                <button
                  key={tune.id}
                  type="button"
                  onClick={() => handleSelectTune(tune.id)}
                  className={`px-2 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-gradient-to-r from-cyan-500/30 to-indigo-500/30 border border-cyan-400/60 text-white'
                      : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {tune.label}
                </button>
              );
            })}
          </div>
          <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 gap-1.5">
            <span className="text-[10px] font-semibold text-slate-400">
              Volume:
            </span>
            <div className="flex items-center gap-1">
              {VOLUME_LEVELS.map((vol) => {
                const active = volumeLevel === vol.id;
                return (
                  <button
                    key={vol.id}
                    type="button"
                    onClick={() => handleSelectVolume(vol.id)}
                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-colors cursor-pointer ${
                      active
                        ? 'bg-cyan-500/25 border border-cyan-400/60 text-cyan-200'
                        : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {vol.id === 'balanced' ? 'Balanced' : vol.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Quick Class Learned Notes Logger */}
        <form onSubmit={handleSaveAndDismiss} className="space-y-2 text-left">
          <div className="p-2.5 rounded-xl bg-slate-950/90 border border-cyan-500/30 space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-bold text-cyan-300 flex items-center gap-1">
                <BookOpen className="w-3 h-3 text-cyan-400" />
                {isEndAlert ? 'What Was Taught in Class?' : 'Planned Class Topic / Notes'}
              </label>
              <span className="text-[10px] text-slate-400 font-medium">
                Saved to PDF
              </span>
            </div>

            <input
              type="text"
              value={topicInput}
              onChange={(e) => setTopicInput(e.target.value)}
              placeholder="Topic covered today (e.g., B-Trees, Lab Exp 4)..."
              className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
            />

            <input
              type="text"
              value={learnedInput}
              onChange={(e) => setLearnedInput(e.target.value)}
              placeholder="Key takeaways, formulas, or homework..."
              className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
            />
          </div>

          {/* Up Next Class Preview */}
          <div className="px-2.5 py-2 rounded-xl bg-indigo-950/40 border border-indigo-500/30 flex items-center justify-between gap-2">
            {nextSlot ? (
              <>
                <div className="min-w-0">
                  <div className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-300 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-indigo-400" />
                    Up Next: {nextSlot.name}
                  </div>
                  <div className="text-[11px] text-slate-300 font-mono truncate">
                    {formatTime12h(nextSlot.startTime)} – {formatTime12h(nextSlot.endTime)}
                    {nextSlot.room ? ` • ${nextSlot.room}` : ''}
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 border border-indigo-400/30 text-[10px] font-bold text-indigo-200 shrink-0 capitalize">
                  {nextSlot.type}
                </span>
              </>
            ) : (
              <div className="flex items-center gap-1.5 text-[11px] text-emerald-300 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>All classes for today complete!</span>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="space-y-1.5 pt-0.5">
            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-500 to-indigo-600 hover:from-cyan-300 hover:to-indigo-500 text-slate-950 font-black text-xs shadow-md shadow-cyan-500/20 flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>Save Class Log &amp; Dismiss</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={handleSnoozeClick}
                className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
              >
                Snooze 5m
              </button>

              <button
                type="button"
                onClick={handleDismissOnly}
                className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-semibold border border-slate-700 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                <span>Dismiss</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );

  return typeof document !== 'undefined'
    ? createPortal(modalContent, document.body)
    : modalContent;
};
