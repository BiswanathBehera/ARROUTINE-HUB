import {
  BookOpen,
  TrendingUp,
  Film,
  Code2,
  Dumbbell,
  GraduationCap,
  Coffee,
  Sparkles,
  LucideIcon,
} from 'lucide-react';
import { TaskCategory } from '../types/routine';

export interface CategoryInfo {
  id: TaskCategory;
  label: string;
  icon: LucideIcon;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  cardBorder: string;
  colorHex: string;
  description: string;
}

export const CATEGORIES: Record<TaskCategory, CategoryInfo> = {
  study: {
    id: 'study',
    label: 'Study Hours',
    icon: BookOpen,
    badgeBg: 'bg-blue-500/15',
    badgeText: 'text-blue-300',
    badgeBorder: 'border-blue-500/30',
    cardBorder: 'hover:border-blue-500/50',
    colorHex: '#3b82f6',
    description: 'Academic concepts, lecture notes, exam preparation',
  },
  trading: {
    id: 'trading',
    label: 'Trading',
    icon: TrendingUp,
    badgeBg: 'bg-emerald-500/15',
    badgeText: 'text-emerald-300',
    badgeBorder: 'border-emerald-500/30',
    cardBorder: 'hover:border-emerald-500/50',
    colorHex: '#10b981',
    description: 'Market analysis, candlestick charts, journal & execution',
  },
  video_editing: {
    id: 'video_editing',
    label: 'Video Editing',
    icon: Film,
    badgeBg: 'bg-pink-500/15',
    badgeText: 'text-pink-300',
    badgeBorder: 'border-pink-500/30',
    cardBorder: 'hover:border-pink-500/50',
    colorHex: '#ec4899',
    description: 'Footage trimming, timeline cuts, VFX, audio sync & render',
  },
  programming: {
    id: 'programming',
    label: 'Programming',
    icon: Code2,
    badgeBg: 'bg-violet-500/15',
    badgeText: 'text-violet-300',
    badgeBorder: 'border-violet-500/30',
    cardBorder: 'hover:border-violet-500/50',
    colorHex: '#8b5cf6',
    description: 'Coding projects, DSA problems, architecture, debugging',
  },
  exercise: {
    id: 'exercise',
    label: 'Exercise',
    icon: Dumbbell,
    badgeBg: 'bg-amber-500/15',
    badgeText: 'text-amber-300',
    badgeBorder: 'border-amber-500/30',
    cardBorder: 'hover:border-amber-500/50',
    colorHex: '#f59e0b',
    description: 'Gym workout, cardio, mobility stretching, fitness routine',
  },
  college: {
    id: 'college',
    label: 'College Hours',
    icon: GraduationCap,
    badgeBg: 'bg-sky-500/15',
    badgeText: 'text-sky-300',
    badgeBorder: 'border-sky-500/30',
    cardBorder: 'hover:border-sky-500/50',
    colorHex: '#0284c7',
    description: 'Fixed campus hours, mandatory lectures, labs & tutorials',
  },
  break: {
    id: 'break',
    label: 'Break & Rest',
    icon: Coffee,
    badgeBg: 'bg-teal-500/15',
    badgeText: 'text-teal-300',
    badgeBorder: 'border-teal-500/30',
    cardBorder: 'hover:border-teal-500/50',
    colorHex: '#14b8a6',
    description: 'Meals, refreshments, rest, mind reset',
  },
  personal: {
    id: 'personal',
    label: 'Personal & Routine',
    icon: Sparkles,
    badgeBg: 'bg-slate-500/15',
    badgeText: 'text-slate-300',
    badgeBorder: 'border-slate-500/30',
    cardBorder: 'hover:border-slate-500/50',
    colorHex: '#94a3b8',
    description: 'Errands, planning, reading, night routine',
  },
};

export const CATEGORY_LIST = Object.values(CATEGORIES);
