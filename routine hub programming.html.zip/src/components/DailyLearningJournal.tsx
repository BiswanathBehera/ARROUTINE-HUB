import React, { useState } from 'react';
import {
  BookOpen,
  Lightbulb,
  Check,
  Copy,
  Edit2,
  Sparkles,
  Tag,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { Task } from '../types/routine';
import { CATEGORIES } from '../utils/categories';
import { formatTime12h } from '../utils/dateUtils';

interface DailyLearningJournalProps {
  tasks: Task[];
  onUpdateLearned: (taskId: string, topic?: string, learned?: string) => void;
}

export const DailyLearningJournal: React.FC<DailyLearningJournalProps> = ({
  tasks,
  onUpdateLearned,
}) => {
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [tempTopic, setTempTopic] = useState('');
  const [tempLearned, setTempLearned] = useState('');
  const [isCopied, setIsCopied] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);

  // Filter tasks that have topics or learnings, or all tasks for logging
  const tasksWithLearnings = tasks.filter((t) => t.topic || t.learned);

  const startEdit = (t: Task) => {
    setEditingTaskId(t.id);
    setTempTopic(t.topic || '');
    setTempLearned(t.learned || '');
  };

  const saveEdit = (taskId: string) => {
    onUpdateLearned(taskId, tempTopic.trim() || undefined, tempLearned.trim() || undefined);
    setEditingTaskId(null);
  };

  const copyDailySummary = () => {
    if (tasks.length === 0) return;

    let text = `# Daily Learning Journal - RoutineHub\n\n`;
    tasks.forEach((t) => {
      if (t.topic || t.learned) {
        const cat = CATEGORIES[t.category]?.label || t.category;
        text += `### [${cat}] ${t.title} (${formatTime12h(t.startTime)} - ${formatTime12h(t.endTime)})\n`;
        if (t.topic) text += `**Topic:** ${t.topic}\n`;
        if (t.learned) text += `**What I Learned:**\n${t.learned}\n\n`;
      }
    });

    navigator.clipboard.writeText(text).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    });
  };

  return (
    <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl border border-slate-800/80 p-4 sm:p-5 shadow-2xl space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20">
            <Lightbulb className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
              What I Have Learned Today & Topic Tracker
              <span className="text-[10px] font-semibold px-2 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {tasksWithLearnings.length} Logged
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Record key insights, formulas, code takeaways, and trade lessons from your daily sessions.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {tasksWithLearnings.length > 0 && (
            <button
              onClick={copyDailySummary}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors shadow-sm"
              title="Copy all topics and learnings to clipboard"
            >
              {isCopied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-300">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Copy Journal</span>
                </>
              )}
            </button>
          )}

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-white transition-colors"
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
          {tasks.map((task) => {
            const cat = CATEGORIES[task.category] || CATEGORIES.study;
            const CatIcon = cat.icon;
            const isEditing = editingTaskId === task.id;

            return (
              <div
                key={task.id}
                className={`p-3.5 rounded-xl border transition-all ${
                  task.learned
                    ? 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                    : 'bg-slate-950/40 border-slate-800/60'
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold border ${cat.badgeBg} ${cat.badgeText} ${cat.badgeBorder}`}
                    >
                      <CatIcon className="w-3 h-3" />
                      {cat.label}
                    </span>
                    <span className="text-xs font-bold text-white truncate">
                      {task.title}
                    </span>
                  </div>

                  <button
                    onClick={() => (isEditing ? saveEdit(task.id) : startEdit(task))}
                    className="text-[11px] px-2 py-0.5 rounded text-indigo-300 hover:text-white bg-slate-900 border border-slate-800 hover:bg-slate-800 shrink-0 flex items-center gap-1 transition-colors"
                  >
                    <Edit2 className="w-3 h-3 text-indigo-400" />
                    {isEditing ? 'Save' : task.learned ? 'Edit' : '+ Add Notes'}
                  </button>
                </div>

                {isEditing ? (
                  <div className="space-y-2 mt-2 pt-2 border-t border-slate-800">
                    <div>
                      <label className="block text-[10px] text-slate-400 uppercase font-semibold mb-0.5">
                        Topic Name:
                      </label>
                      <input
                        type="text"
                        value={tempTopic}
                        onChange={(e) => setTempTopic(e.target.value)}
                        placeholder="e.g. AVL Trees, Order Block Retest, Audio Ducking"
                        className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-amber-300 uppercase font-semibold mb-0.5">
                        What I Have Learned:
                      </label>
                      <textarea
                        rows={2}
                        value={tempLearned}
                        onChange={(e) => setTempLearned(e.target.value)}
                        placeholder="What concept, formula, trade rule, or insight did you take away?"
                        className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-white"
                      />
                    </div>
                    <div className="flex justify-end gap-1.5 pt-1">
                      <button
                        onClick={() => setEditingTaskId(null)}
                        className="px-2 py-1 text-[11px] text-slate-400 hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => saveEdit(task.id)}
                        className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold rounded"
                      >
                        Save Learnings
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-1.5 text-xs">
                    {task.topic ? (
                      <div className="flex items-center gap-1.5 text-indigo-300 font-medium">
                        <Tag className="w-3 h-3 text-indigo-400 shrink-0" />
                        <span className="text-[11px] font-semibold text-slate-200">
                          Topic: <span className="text-indigo-300">{task.topic}</span>
                        </span>
                      </div>
                    ) : (
                      <span className="text-[10px] text-slate-500 italic">No topic tagged</span>
                    )}

                    {task.learned ? (
                      <div className="p-2 rounded-lg bg-amber-950/20 border border-amber-500/20 text-slate-200 text-xs leading-relaxed">
                        <strong className="text-amber-400 text-[10px] block uppercase tracking-wider mb-0.5">
                          What I Learned:
                        </strong>
                        {task.learned}
                      </div>
                    ) : (
                      <p className="text-[11px] text-slate-500 italic">
                        Click "+ Add Notes" to log what you learned in this session.
                      </p>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
