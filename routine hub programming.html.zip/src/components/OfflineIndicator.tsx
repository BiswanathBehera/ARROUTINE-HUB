import React, { useState, useEffect } from 'react';
import { WifiOff } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const [isOffline, setIsOffline] = useState(
    typeof navigator !== 'undefined' ? !navigator.onLine : false
  );

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (!isOffline) return null;

  return (
    <div className="bg-amber-500/95 text-slate-950 text-xs font-semibold py-1.5 px-4 text-center flex items-center justify-center gap-2 z-50">
      <WifiOff className="w-3.5 h-3.5 shrink-0" />
      <span>Offline Mode — RoutineHub is running locally from cached app storage</span>
    </div>
  );
};
