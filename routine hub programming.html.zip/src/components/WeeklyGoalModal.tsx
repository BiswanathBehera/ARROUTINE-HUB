import React, { useState, useEffect } from 'react';
import { X, Target, Plus, Trash2, CheckCircle2, Sparkles, Flag } from 'lucide-react';
import { TaskCategory, Priority, WeeklyGoal, WeeklyGoalMilestone } from '../types/routine';
import { CATEGORIES } from '../utils/categories';

interface WeeklyGoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (goalData: Omit<WeeklyGoal, 'id'>, existingId?: string) => void;
  goalToEdit?: WeeklyGoal | null;
}

const TEMPLATE_GOALS = [
  {
    title: 'Dynamic Programming & LeetCode Practice',
    category: 'programming' as TaskCategory,
    targetValue: 12,
    unit: 'problems',
    priority: 'high' as Priority,
    notes: 'Focus on 0/1 Knapsack, Coin Change, and Longest Common Subsequence',
    milestones: ['0/1 Knapsack & Subset Sum', 'Coin Change I & II', 'Longest Common Subsequence', 'Edit Distance'],
  },
  {
    title: 'Market Trading & Risk Journaling',
    category: 'trading' as TaskCategory,
    targetValue: 5,
    unit: 'sessions',
    priority: 'high' as Priority,
    notes: 'Strict 1:2 R:R ratio, review Fair Value Gaps and post-market reviews',
    milestones: ['Mon NY Open review', 'Tue FVG entry setup', 'Wed mid-week recap', 'Fri trade journal audit'],
  },
  {
    title: 'YouTube Tech Tutorials & Video Editing',
    category: 'video_editing' as TaskCategory,
    targetValue: 2,
    unit: 'videos',
    priority: 'medium' as Priority,
    notes: 'Complete script, voiceover cleanup, 4K timeline cuts & thumbnail',
    milestones: ['Scripting & B-Roll capture', 'Rough cuts & voiceover', 'Audio ducking & color grade', 'Render & 3D Thumbnail'],
  },
  {
    title: 'Academic Study & College OS/Networks',
    category: 'study' as TaskCategory,
    targetValue: 15,
    unit: 'hours',
    priority: 'high' as Priority,
    notes: 'Virtual Memory, Subnetting, TCP/IP Handshakes, and College Practical Lab prep',
    milestones: ['OS Page replacement algos', 'CIDR notation & subnetting', 'Complete Friday lab file writeup'],
  },
  {
    title: 'Gym Strength Training & Cardio',
    category: 'exercise' as TaskCategory,
    targetValue: 5,
    unit: 'workouts',
    priority: 'medium' as Priority,
    notes: 'Push-Pull-Legs split with 15 min high incline cardio walk each workout',
    milestones: ['Chest & Triceps Push', 'Back & Biceps Pull', 'Legs & Hamstrings', 'Cardio & Core Mobility'],
  },
];

export const WeeklyGoalModal: React.FC<WeeklyGoalModalProps> = ({
  isOpen,
  onClose,
  onSave,
  goalToEdit,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<TaskCategory>('programming');
  const [targetValue, setTargetValue] = useState<number>(10);
  const [currentValue, setCurrentValue] = useState<number>(0);
  const [unit, setUnit] = useState('problems');
  const [priority, setPriority] = useState<Priority>('high');
  const [notes, setNotes] = useState('');
  const [milestones, setMilestones] = useState<WeeklyGoalMilestone[]>([]);
  const [newMilestoneTitle, setNewMilestoneTitle] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (goalToEdit) {
      setTitle(goalToEdit.title);
      setCategory(goalToEdit.category);
      setTargetValue(goalToEdit.targetValue);
      setCurrentValue(goalToEdit.currentValue);
      setUnit(goalToEdit.unit || 'units');
      setPriority(goalToEdit.priority || 'medium');
      setNotes(goalToEdit.notes || '');
      setMilestones(goalToEdit.milestones ? [...goalToEdit.milestones] : []);
    } else {
      setTitle('');
      setCategory('programming');
      setTargetValue(10);
      setCurrentValue(0);
      setUnit('problems');
      setPriority('high');
      setNotes('');
      setMilestones([]);
    }
    setError(null);
  }, [goalToEdit, isOpen]);

  if (!isOpen) return null;

  const handleApplyTemplate = (tmpl: typeof TEMPLATE_GOALS[0]) => {
    setTitle(tmpl.title);
    setCategory(tmpl.category);
    setTargetValue(tmpl.targetValue);
    setUnit(tmpl.unit);
    setPriority(tmpl.priority);
    setNotes(tmpl.notes);
    setMilestones(
      tmpl.milestones.map((m, idx) => ({
        id: `ms-${Date.now()}-${idx}`,
        title: m,
        completed: false,
      }))
    );
  };

  const handleAddMilestone = () => {
    if (!newMilestoneTitle.trim()) return;
    const newMs: WeeklyGoalMilestone = {
      id: `ms-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      title: newMilestoneTitle.trim(),
      completed: false,
    };
    setMilestones((prev) => [...prev, newMs]);
    setNewMilestoneTitle('');
  };

  const handleRemoveMilestone = (id: string) => {
    setMilestones((prev) => prev.filter((m) => m.id !== id));
  };

  const handleToggleMilestone = (id: string) => {
    setMilestones((prev) =>
      prev.map((m) => (m.id === id ? { ...m, completed: !m.completed } : m))
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please provide a goal objective title');
      return;
    }
    if (targetValue <= 0) {
      setError('Target value must be greater than 0');
      return;
    }

    const completed = currentValue >= targetValue;

    onSave(
      {
        title: title.trim(),
        category,
        targetValue,
        currentValue,
        unit: unit.trim() || 'units',
        completed,
        priority,
        notes: notes.trim() || undefined,
        milestones,
      },
      goalToEdit?.id
    );

    onClose();
  };

  const COMMON_UNITS = ['problems', 'hours', 'sessions', 'videos', 'workouts', 'chapters', 'days'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-slate-100 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">
                {goalToEdit ? 'Edit Weekly Objective' : 'New Weekly Objective'}
              </h3>
              <p className="text-xs text-slate-400">
                Define measurable targets to conquer throughout the current week
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Templates (only when adding fresh) */}
        {!goalToEdit && (
          <div className="mt-4 p-3 bg-slate-950/60 rounded-xl border border-slate-800/80">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Fast 1-Click Weekly Templates:</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {TEMPLATE_GOALS.map((tmpl) => (
                <button
                  key={tmpl.title}
                  type="button"
                  onClick={() => handleApplyTemplate(tmpl)}
                  className="px-2.5 py-1 text-xs rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700 transition-colors"
                >
                  {tmpl.title.split(' ')[0]} ({tmpl.targetValue} {tmpl.unit})
                </button>
              ))}
            </div>
          </div>
        )}

        {error && (
          <div className="mt-3 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-300 text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          
          {/* Goal Title */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Objective Title <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Master Dynamic Programming & Solve 12 LeetCode Problems"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-indigo-500 transition-colors"
              autoFocus
            />
          </div>

          {/* Category & Priority Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as TaskCategory)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-indigo-500"
              >
                {Object.entries(CATEGORIES).map(([catKey, info]) => (
                  <option key={catKey} value={catKey}>
                    {info.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Priority
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['low', 'medium', 'high'] as Priority[]).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPriority(p)}
                    className={`py-2 text-xs font-medium rounded-xl border capitalize transition-all ${
                      priority === p
                        ? p === 'high'
                          ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                          : p === 'medium'
                          ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                          : 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Target & Current Values & Unit */}
          <div className="p-3.5 bg-slate-950/60 rounded-xl border border-slate-800 space-y-3">
            <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Flag className="w-3.5 h-3.5 text-indigo-400" />
              Progress Target & Measurement
            </span>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  Target Count
                </label>
                <input
                  type="number"
                  min="1"
                  value={targetValue}
                  onChange={(e) => setTargetValue(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-white text-sm focus:outline-none focus:border-indigo-500 font-mono text-center"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  Current Progress
                </label>
                <input
                  type="number"
                  min="0"
                  value={currentValue}
                  onChange={(e) => setCurrentValue(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-white text-sm focus:outline-none focus:border-indigo-500 font-mono text-center"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  Unit Label
                </label>
                <input
                  type="text"
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  placeholder="e.g. problems"
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-white text-sm focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Common Units quick click */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[10px] text-slate-500">Quick units:</span>
              {COMMON_UNITS.map((u) => (
                <button
                  key={u}
                  type="button"
                  onClick={() => setUnit(u)}
                  className={`text-[10px] px-2 py-0.5 rounded transition-colors ${
                    unit.toLowerCase() === u
                      ? 'bg-indigo-500/20 text-indigo-300 font-medium'
                      : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {u}
                </button>
              ))}
            </div>
          </div>

          {/* Sub-Milestones / Step Checklist */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-slate-300">
                Key Milestones & Steps ({milestones.filter((m) => m.completed).length}/{milestones.length})
              </label>
            </div>

            {/* Milestone List */}
            {milestones.length > 0 && (
              <div className="space-y-1.5 mb-2 max-h-36 overflow-y-auto pr-1">
                {milestones.map((ms) => (
                  <div
                    key={ms.id}
                    className="flex items-center justify-between gap-2 p-2 rounded-lg bg-slate-950/70 border border-slate-800/80 text-xs"
                  >
                    <button
                      type="button"
                      onClick={() => handleToggleMilestone(ms.id)}
                      className="flex items-center gap-2 flex-1 text-left"
                    >
                      <CheckCircle2
                        className={`w-4 h-4 shrink-0 transition-colors ${
                          ms.completed ? 'text-emerald-400' : 'text-slate-600'
                        }`}
                      />
                      <span
                        className={
                          ms.completed
                            ? 'line-through text-slate-500'
                            : 'text-slate-200'
                        }
                      >
                        {ms.title}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveMilestone(ms.id)}
                      className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                      title="Remove milestone"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Add Milestone Input */}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={newMilestoneTitle}
                onChange={(e) => setNewMilestoneTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddMilestone();
                  }
                }}
                placeholder="Add sub-milestone (e.g. '0/1 Knapsack & Subset Sum')..."
                className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-indigo-500"
              />
              <button
                type="button"
                onClick={handleAddMilestone}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add</span>
              </button>
            </div>
          </div>

          {/* Strategy & Notes */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Strategy & Implementation Notes
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="e.g. Solve at least 2 questions daily post-college hours between 18:00 - 19:45..."
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-indigo-500 resize-none"
            />
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-medium text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/25 transition-all flex items-center gap-1.5"
            >
              <Target className="w-3.5 h-3.5" />
              <span>{goalToEdit ? 'Save Changes' : 'Create Weekly Goal'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
