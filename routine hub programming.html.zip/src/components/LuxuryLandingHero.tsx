import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, type Variants } from 'motion/react';
import {
  ArrowUpRight,
  CheckCircle2,
  Circle,
  Clock,
  Smartphone,
  Monitor,
  Flame,
  Moon,
  Sun,
  GraduationCap,
  Briefcase,
  Play,
  Plus,
  Activity,
  ChevronRight,
  ShieldCheck,
  Wifi,
  BatteryCharging,
} from 'lucide-react';
import { Task, CollegeConfig, SleepConfig, DayOccupancySummary } from '../types/routine';
import { formatTime12h, formatDuration } from '../utils/dateUtils';
import { useTheme } from '../context/ThemeContext';
import { ConsistencyStreakBadge } from './ConsistencyStreakBadge';

export type WorkspaceTab = 'home' | 'schedule' | 'college' | 'analytics' | 'remaining';

interface LuxuryLandingHeroProps {
  tasks: Task[];
  currentDayTasks: Task[];
  selectedDate: string;
  onSelectDate?: (date: string) => void;
  collegeConfig: CollegeConfig;
  sleepConfig: SleepConfig;
  sleepHoursToday: number;
  dayOccupancy: DayOccupancySummary;
  onEnterWorkspace: (targetTab?: WorkspaceTab) => void;
  onToggleComplete: (taskId: string) => void;
  onOpenFocusMode: () => void;
  onOpenAddTask: () => void;
  onAssignFreeSlot: (startTime: string, endTime: string) => void;
  onOpenApkModal?: () => void;
}

type FrameViewMode = 'dual-platform' | 'bento-telemetry' | 'timeline-24h' | 'gap-allocator';

const firstOpenContainerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.05,
    },
  },
};

const firstOpenItemVariants: Variants = {
  hidden: { opacity: 0, y: 18 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.55,
      ease: [0.16, 1, 0.3, 1],
    },
  },
};

export const LuxuryLandingHero: React.FC<LuxuryLandingHeroProps> = ({
  tasks,
  currentDayTasks,
  selectedDate,
  onSelectDate,
  collegeConfig,
  sleepConfig,
  sleepHoursToday,
  dayOccupancy,
  onEnterWorkspace,
  onToggleComplete,
  onOpenFocusMode,
  onOpenAddTask,
  onAssignFreeSlot,
  onOpenApkModal,
}) => {
  const { isLight, toggleTheme } = useTheme();
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeFrame, setActiveFrame] = useState<FrameViewMode>('dual-platform');
  const [activeDeviceFocus, setActiveDeviceFocus] = useState<'both' | 'android' | 'web'>('both');

  // Magnetic button pull state for the solitary Primary CTA
  const magneticBtnRef = useRef<HTMLButtonElement | null>(null);
  const [magneticOffset, setMagneticOffset] = useState({ x: 0, y: 0 });

  const handleMagneticMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (!magneticBtnRef.current) return;
    const rect = magneticBtnRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const deltaX = (e.clientX - centerX) * 0.18;
    const deltaY = (e.clientY - centerY) * 0.22;
    setMagneticOffset({ x: deltaX, y: deltaY });
  };

  const handleMagneticLeave = () => {
    setMagneticOffset({ x: 0, y: 0 });
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 16);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Live telemetry calculations
  const totalTasks = currentDayTasks.length;
  const completedTasks = currentDayTasks.filter((t) => t.completed).length;
  const completionPct = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const focusHours = (dayOccupancy.routineMinutes / 60).toFixed(1);
  const freeHoursFormatted = formatDuration(dayOccupancy.freeMinutes);
  const sleepScore = Math.min(
    100,
    Math.round((sleepHoursToday / (sleepConfig.targetHours || 8)) * 100)
  );

  const frameTabs: {
    id: FrameViewMode;
    index: string;
    label: string;
    shortLabel: string;
  }[] = [
    {
      id: 'dual-platform',
      index: '01.',
      label: 'Mobile & Web View',
      shortLabel: 'App View',
    },
    {
      id: 'bento-telemetry',
      index: '02.',
      label: 'Daily Progress & Stats',
      shortLabel: 'Progress',
    },
    {
      id: 'timeline-24h',
      index: '03.',
      label: '24-Hour Daily Routine',
      shortLabel: '24h Routine',
    },
    {
      id: 'gap-allocator',
      index: '04.',
      label: 'Free Time Planner',
      shortLabel: 'Free Time',
    },
  ];

  return (
    <div className="luxury-obsidian-root min-h-screen w-full overflow-x-hidden relative flex flex-col justify-between selection:bg-[#D4AF77] selection:text-[#0F172A]">
      {/* Soft, Subtle Ambient Aurora Glows & Architectural Hairline Depth */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div
          className="absolute -top-40 left-1/4 w-[560px] h-[560px] rounded-full opacity-20 blur-[140px] aurora-orb-float"
          style={{ background: 'radial-gradient(circle, #D4AF77 0%, transparent 70%)' }}
        />
        <div
          className="absolute top-1/3 right-12 w-[500px] h-[500px] rounded-full opacity-15 blur-[150px] aurora-orb-float-delayed"
          style={{ background: 'radial-gradient(circle, #38BDF8 0%, transparent 70%)' }}
        />
        <div
          className="absolute -bottom-36 left-1/3 w-[520px] h-[520px] rounded-full opacity-12 blur-[150px]"
          style={{ background: 'radial-gradient(circle, #34D399 0%, transparent 70%)' }}
        />

        {/* Editorial Vertical Hairlines */}
        <div className="max-w-[1440px] mx-auto h-full px-6 sm:px-10 lg:px-14 grid grid-cols-4 lg:grid-cols-12 opacity-[0.035]">
          {Array.from({ length: 12 }).map((_, idx) => (
            <div key={idx} className="border-r border-current h-full hidden lg:block" />
          ))}
        </div>
      </div>

      {/* =====================================================================
          STICKY 12PX GLASSMORPHIC TOP BAR (3-Zone Contract + Animated Indicator)
         ===================================================================== */}
      <motion.header
        initial={{ y: -18, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
        className={`sticky top-0 z-50 w-full luxury-sticky-bar transition-all duration-200 ${
          isScrolled ? 'py-3' : 'py-4 sm:py-5'
        }`}
      >
        <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-14 flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark in Playfair Display with Subtitle & Official Icon */}
          <button
            onClick={() => onEnterWorkspace('home')}
            className="flex items-center gap-3 group whitespace-nowrap shrink-0 cursor-pointer focus:outline-none text-left"
          >
            <img
              src="/pwa-192x192.png"
              alt="AR BISWANATH BEHERA Icon"
              className="w-10 h-10 rounded-xl border border-[#D4AF77]/50 shadow-[0_0_14px_rgba(212,175,119,0.28)] object-cover shrink-0"
            />
            <div className="flex flex-col items-start leading-none">
              <span className="font-luxury-serif text-lg sm:text-xl font-semibold tracking-[0.14em] text-white group-hover:text-[#D4AF77] transition-colors">
                RoutineHub
              </span>
              <span className="mt-1 font-luxury-mono text-[9px] sm:text-[10px] font-semibold tracking-[0.18em] uppercase text-[#D4AF77]/90">
                AR BISWANATH BEHERA
              </span>
            </div>
          </button>

          {/* Zone 2: 4 Concise Single-Line Navigation Links with Animated Active Indicator */}
          <nav
            aria-label="Interactive Stage Navigation"
            className="hidden lg:flex items-center gap-6"
          >
            {frameTabs.map((tab) => {
              const active = activeFrame === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveFrame(tab.id)}
                  className={`relative py-1.5 text-xs font-medium tracking-wide transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active ? 'text-white font-semibold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <span>
                    {tab.index} {tab.label}
                  </span>
                  {active && (
                    <motion.span
                      layoutId="heroNavActiveIndicator"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                      className="absolute left-0 right-0 -bottom-1 h-[2px] bg-[#D4AF77]"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Consistency Streak Badge, Theme Switch & Workspace Entry */}
          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            <ConsistencyStreakBadge
              tasks={tasks}
              selectedDate={selectedDate}
              onSelectDate={onSelectDate}
            />
            <button
              onClick={toggleTheme}
              aria-label="Toggle Light or Dark Theme"
              className="min-h-[40px] px-3 py-1.5 rounded-lg glass-layer-12 text-xs font-medium text-slate-200 hover:border-[#D4AF77]/50 transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {isLight ? (
                <>
                  <Moon className="w-3.5 h-3.5 text-slate-700" />
                  <span>Slate Dark</span>
                </>
              ) : (
                <>
                  <Sun className="w-3.5 h-3.5 text-[#D4AF77]" />
                  <span>Cream Light</span>
                </>
              )}
            </button>

            {onOpenApkModal && (
              <button
                onClick={onOpenApkModal}
                className="min-h-[40px] px-3.5 py-1.5 rounded-lg bg-emerald-500/15 border border-emerald-400/40 hover:bg-emerald-500/25 text-xs font-semibold text-emerald-200 transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Smartphone className="w-3.5 h-3.5 text-emerald-300" />
                <span>Install APK</span>
              </button>
            )}

            <button
              onClick={() => onEnterWorkspace('home')}
              className="min-h-[40px] px-4 py-1.5 rounded-lg border border-white/15 hover:border-[#D4AF77] text-xs font-medium text-white hover:text-[#D4AF77] transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>Enter Studio</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </motion.header>

      {/* =====================================================================
          MAIN FULL-SCREEN SPLIT-GRID & BENTO HERO CONTENT
          ("First Open" Staggered Fade-In-Up + Solitary Magnetic Primary CTA)
         ===================================================================== */}
      <div className="relative z-10 flex-1 flex items-center max-w-[1440px] w-full mx-auto px-6 sm:px-10 lg:px-14 py-8 sm:py-12 lg:py-16">
        <motion.div
          variants={firstOpenContainerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 xl:gap-14 items-stretch w-full"
        >
          {/* LEFT COLUMN: Editorial Narrative, Playfair Display Headline & Solitary Magnetic CTA (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-8">
            <div className="space-y-6">
              {/* Unboxed Editorial Metadata with Typographic Separators (Zero-Pill Discipline) */}
              <motion.div
                variants={firstOpenItemVariants}
                className="flex flex-wrap items-center gap-2.5 text-xs font-luxury-mono text-slate-400 border-b border-white/10 pb-3"
              >
                <span className="text-[#D4AF77] font-medium">01. Temporal Architecture</span>
                <span aria-hidden="true">·</span>
                <span>Android Touch</span>
                <span aria-hidden="true">·</span>
                <span>Web Studio</span>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums">{freeHoursFormatted} Free Today</span>
              </motion.div>

              {/* Playfair Display Headline with Generous Letter-Spacing & Balance */}
              <motion.h1
                variants={firstOpenItemVariants}
                style={{ textWrap: 'balance' }}
                className="font-luxury-serif font-semibold text-4xl sm:text-5xl xl:text-[56px] leading-[1.08] tracking-[0.06em] text-white"
              >
                Architect{' '}
                <span className="italic font-normal text-[#D4AF77]">Every Waking Hour</span> With
                Quiet Precision.
              </motion.h1>

              {/* Readable Plus Jakarta Sans Body Prose */}
              <motion.p
                variants={firstOpenItemVariants}
                className="font-luxury-sans text-sm sm:text-base text-slate-300 leading-relaxed max-w-[54ch] font-normal"
              >
                A hyper-minimalist daily schedule and deep-work telemetry studio crafted for both{' '}
                <span className="text-white font-medium">Android mobile touch</span> and{' '}
                <span className="text-white font-medium">desktop web browsers</span>. Protect fixed{' '}
                {collegeConfig.commitmentType === 'job' ? 'work shifts' : 'college lectures'},
                reclaim unallocated time windows, and sustain restorative sleep.
              </motion.p>
            </div>

            {/* Strictly ONE High-Priority Primary Action Button in the Viewport (with Magnetic Pull) */}
            <motion.div variants={firstOpenItemVariants} className="space-y-5 pt-2">
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                <button
                  ref={magneticBtnRef}
                  onMouseMove={handleMagneticMove}
                  onMouseLeave={handleMagneticLeave}
                  onClick={() => onEnterWorkspace('home')}
                  style={{
                    transform: `translate3d(${magneticOffset.x}px, ${magneticOffset.y}px, 0)`,
                  }}
                  className="luxury-cta-high-contrast magnetic-cta min-h-[52px] px-8 py-4 rounded-xl text-xs sm:text-sm font-semibold tracking-[0.14em] uppercase flex items-center justify-center gap-3 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>Launch Workspace</span>
                  <ArrowUpRight className="w-4 h-4 stroke-[2.25]" />
                </button>

                <button
                  onClick={onOpenFocusMode}
                  className="min-h-[52px] px-5 py-3.5 rounded-xl glass-layer-12 hover:border-[#D4AF77]/50 text-slate-200 hover:text-white text-xs font-medium tracking-wide transition-all flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 text-[#D4AF77]" />
                  <span>Focus Timer</span>
                </button>
              </div>

              {/* Unboxed Live Telemetry Summary Row (Tabular Numerals) */}
              <div className="pt-5 border-t border-white/10 grid grid-cols-3 gap-4 sm:gap-6">
                <button
                  onClick={() => onEnterWorkspace('schedule')}
                  className="text-left group p-2 -m-2 rounded-lg hover:bg-white/[0.03] transition-colors cursor-pointer"
                >
                  <div className="text-xs text-slate-400 group-hover:text-[#D4AF77] transition-colors">
                    Completion
                  </div>
                  <div className="mt-1 flex items-baseline gap-1.5 font-luxury-mono tabular-nums">
                    <span className="font-luxury-serif text-2xl sm:text-3xl font-semibold text-white">
                      {completionPct}%
                    </span>
                    <span className="text-xs text-slate-400">
                      {completedTasks}/{totalTasks}
                    </span>
                  </div>
                </button>

                <button
                  onClick={() => onEnterWorkspace('remaining')}
                  className="text-left group p-2 -m-2 rounded-lg hover:bg-white/[0.03] transition-colors border-l border-white/10 pl-4 sm:pl-5 cursor-pointer"
                >
                  <div className="text-xs text-slate-400 group-hover:text-[#D4AF77] transition-colors">
                    Free Capacity
                  </div>
                  <div className="mt-1 flex items-baseline gap-1.5 font-luxury-mono tabular-nums">
                    <span className="font-luxury-serif text-2xl sm:text-3xl font-semibold text-white">
                      {freeHoursFormatted}
                    </span>
                  </div>
                </button>

                <button
                  onClick={() => onEnterWorkspace('analytics')}
                  className="text-left group p-2 -m-2 rounded-lg hover:bg-white/[0.03] transition-colors border-l border-white/10 pl-4 sm:pl-5 cursor-pointer"
                >
                  <div className="text-xs text-slate-400 group-hover:text-[#D4AF77] transition-colors">
                    Focus · Rest
                  </div>
                  <div className="mt-1 flex items-baseline gap-1.5 font-luxury-mono tabular-nums">
                    <span className="font-luxury-serif text-2xl sm:text-3xl font-semibold text-white">
                      {focusHours}h
                    </span>
                    <span className="text-xs text-[#D4AF77]">{sleepScore}%</span>
                  </div>
                </button>
              </div>
            </motion.div>

            {/* Direct Module Navigation Links (Clean Typography, Zero Pill Clutter) */}
            <motion.div
              variants={firstOpenItemVariants}
              className="flex flex-wrap items-center gap-x-4 gap-y-2 pt-1 text-xs text-slate-400"
            >
              <span className="font-medium text-slate-500">Modules:</span>
              {(
                [
                  { id: 'home', label: 'Home Dashboard' },
                  { id: 'schedule', label: '24h Schedule' },
                  {
                    id: 'college',
                    label: collegeConfig.commitmentType === 'job' ? 'Work Shifts' : 'College Hours',
                  },
                  { id: 'remaining', label: 'Free Time Slots' },
                  { id: 'analytics', label: 'Analytics' },
                ] as { id: WorkspaceTab; label: string }[]
              ).map((item, idx) => (
                <React.Fragment key={item.id}>
                  {idx > 0 && <span aria-hidden="true">·</span>}
                  <button
                    onClick={() => onEnterWorkspace(item.id)}
                    className="text-slate-300 hover:text-[#D4AF77] underline-offset-4 hover:underline transition-colors whitespace-nowrap cursor-pointer"
                  >
                    {item.label}
                  </button>
                </React.Fragment>
              ))}
            </motion.div>
          </div>

          {/* RIGHT COLUMN: Split-Layout Interactive Visual Frames in 12px Glass Bento Stage (7 Cols) */}
          <motion.div
            variants={firstOpenItemVariants}
            className="lg:col-span-7 flex flex-col justify-between space-y-4"
          >
            {/* Interactive Stage Selector Bar with Animated Active Pill Indicator */}
            <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-3 overflow-x-auto no-scrollbar">
              <div className="flex items-center gap-1.5 p-1 rounded-xl glass-layer-12">
                {frameTabs.map((tab) => {
                  const isActive = activeFrame === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveFrame(tab.id)}
                      className={`relative px-3.5 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
                        isActive ? 'text-slate-950 font-semibold' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {isActive && (
                        <motion.span
                          layoutId="stageTabIndicator"
                          transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                          className="absolute inset-0 rounded-lg bg-[#D4AF77]"
                        />
                      )}
                      <span className="relative z-10 font-luxury-mono text-[11px]">
                        {tab.index}
                      </span>
                      <span className="relative z-10 hidden sm:inline">{tab.label}</span>
                      <span className="relative z-10 sm:hidden">{tab.shortLabel}</span>
                    </button>
                  );
                })}
              </div>

              <span className="hidden sm:inline text-xs font-luxury-mono text-slate-400 whitespace-nowrap">
                Interactive Preview
              </span>
            </div>

            {/* 12px Glassmorphic Frame Surface */}
            <div className="luxury-frame-surface rounded-3xl relative p-5 sm:p-7 min-h-[480px] sm:min-h-[520px] flex flex-col justify-between overflow-hidden">
              <AnimatePresence mode="wait">
                {/* FRAME 01: DUAL ANDROID APP & WEB BROWSER INTERACTIVE SHOWCASE */}
                {activeFrame === 'dual-platform' && (
                  <motion.div
                    key="dual-platform"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.25 }}
                    className="space-y-5 flex-1 flex flex-col justify-between"
                  >
                    {/* Stage Subheader & Device Filter */}
                    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-3.5">
                      <div>
                        <span className="text-xs font-luxury-mono text-[#D4AF77]">
                          01. Mobile &amp; Web View
                        </span>
                        <h2 className="font-luxury-serif text-xl sm:text-2xl tracking-[0.04em] text-white mt-0.5">
                          Desktop Web &amp; Android Phone App Preview
                        </h2>
                      </div>

                      <div className="flex items-center gap-1 p-1 rounded-lg glass-layer-12">
                        {(
                          [
                            { id: 'both', label: 'Split View' },
                            { id: 'web', label: 'Web Browser' },
                            { id: 'android', label: 'Android App' },
                          ] as const
                        ).map((mode) => (
                          <button
                            key={mode.id}
                            onClick={() => setActiveDeviceFocus(mode.id)}
                            className={`px-3 py-1 rounded-md text-xs font-medium transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                              activeDeviceFocus === mode.id
                                ? 'bg-white text-slate-900 font-semibold shadow-xs'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            {mode.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Dual Visual Frames Grid */}
                    <div
                      className={`grid gap-5 items-stretch ${
                        activeDeviceFocus === 'both'
                          ? 'grid-cols-1 xl:grid-cols-12'
                          : 'grid-cols-1'
                      }`}
                    >
                      {/* FRAME A: Desktop Web Browser Interactive Viewport */}
                      {(activeDeviceFocus === 'both' || activeDeviceFocus === 'web') && (
                        <div
                          className={`${
                            activeDeviceFocus === 'both' ? 'xl:col-span-7' : 'col-span-1'
                          } rounded-2xl glass-layer-12 bento-card-hover flex flex-col justify-between overflow-hidden`}
                        >
                          {/* Browser Window Top Chrome */}
                          <div className="px-4 py-2.5 border-b border-white/10 bg-slate-950/50 flex items-center justify-between gap-2">
                            <div className="flex items-center gap-1.5">
                              <span className="w-2.5 h-2.5 rounded-full bg-white/20" />
                              <span className="w-2.5 h-2.5 rounded-full bg-[#D4AF77]/50" />
                              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400/50" />
                            </div>
                            <div className="px-3 py-0.5 rounded-md bg-slate-900/80 border border-white/8 font-luxury-mono text-[11px] text-slate-400 truncate">
                              routinehub.app/workspace · Desktop Web
                            </div>
                            <Monitor className="w-3.5 h-3.5 text-[#D4AF77]" />
                          </div>

                          {/* Browser Interior: Live Mini Command Matrix */}
                          <div className="p-4 sm:p-5 space-y-4 flex-1 flex flex-col justify-between">
                            <div className="flex items-center justify-between gap-2">
                              <div>
                                <div className="text-xs font-luxury-mono text-slate-400 tabular-nums">
                                  Web Studio · {selectedDate}
                                </div>
                                <div className="font-luxury-serif text-lg tracking-[0.04em] text-white mt-0.5">
                                  24-Hour Routine &amp; Fixed Hours Matrix
                                </div>
                              </div>
                              <button
                                onClick={() => onEnterWorkspace('schedule')}
                                className="px-3 py-1.5 rounded-lg border border-white/15 hover:border-[#D4AF77] text-xs font-medium text-slate-200 hover:text-[#D4AF77] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                              >
                                Expand Web
                              </button>
                            </div>

                            {/* Live Time Allocation Progress Bar */}
                            <div className="space-y-1.5">
                              <div className="flex justify-between font-luxury-mono text-[11px] text-slate-400 tabular-nums">
                                <span>
                                  {collegeConfig.commitmentType === 'job' ? 'Work' : 'College'}{' '}
                                  {formatDuration(dayOccupancy.collegeMinutes)}
                                </span>
                                <span>Tasks {formatDuration(dayOccupancy.routineMinutes)}</span>
                                <span className="text-emerald-400">
                                  Free {formatDuration(dayOccupancy.freeMinutes)}
                                </span>
                              </div>
                              <div className="h-2 w-full rounded-full bg-slate-950/70 overflow-hidden flex border border-white/8">
                                <div
                                  style={{
                                    width: `${Math.min(100, (dayOccupancy.collegeMinutes / 1440) * 100)}%`,
                                  }}
                                  className="bg-sky-400 h-full"
                                />
                                <div
                                  style={{
                                    width: `${Math.min(100, (dayOccupancy.routineMinutes / 1440) * 100)}%`,
                                  }}
                                  className="bg-[#D4AF77] h-full"
                                />
                                <div
                                  style={{
                                    width: `${Math.min(100, (dayOccupancy.freeMinutes / 1440) * 100)}%`,
                                  }}
                                  className="bg-emerald-400/75 h-full"
                                />
                              </div>
                            </div>

                            {/* Interactive Task Rows inside Web Frame */}
                            <div className="space-y-2">
                              <div className="flex items-center justify-between font-luxury-mono text-[11px] text-slate-400 tabular-nums">
                                <span>Scheduled Blocks (Click to complete)</span>
                                <span>
                                  {completedTasks}/{totalTasks} Done
                                </span>
                              </div>
                              <div className="space-y-1.5 max-h-[155px] overflow-y-auto pr-1">
                                {currentDayTasks.slice(0, 3).map((task) => (
                                  <button
                                    key={task.id}
                                    onClick={() => onToggleComplete(task.id)}
                                    className="w-full p-2.5 rounded-xl border border-white/8 hover:border-[#D4AF77]/50 bg-slate-950/45 flex items-center justify-between gap-2 text-left transition-all cursor-pointer"
                                  >
                                    <div className="flex items-center gap-2.5 min-w-0">
                                      {task.completed ? (
                                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                                      ) : (
                                        <Circle className="w-4 h-4 text-[#D4AF77] shrink-0" />
                                      )}
                                      <span
                                        className={`text-xs truncate ${
                                          task.completed
                                            ? 'line-through text-slate-400'
                                            : 'text-white font-medium'
                                        }`}
                                      >
                                        {task.title}
                                      </span>
                                    </div>
                                    <span className="font-luxury-mono text-[11px] text-[#D4AF77] tabular-nums shrink-0">
                                      {formatTime12h(task.startTime)}
                                    </span>
                                  </button>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* FRAME B: Tactile Android Mobile Device Frame */}
                      {(activeDeviceFocus === 'both' || activeDeviceFocus === 'android') && (
                        <div
                          className={`${
                            activeDeviceFocus === 'both'
                              ? 'xl:col-span-5'
                              : 'col-span-1 max-w-md mx-auto w-full'
                          } rounded-[26px] glass-layer-12 bento-card-hover p-3.5 flex flex-col justify-between relative`}
                        >
                          {/* Android Status Bar */}
                          <div className="px-3 pt-1 pb-2 flex items-center justify-between text-[11px] font-luxury-mono text-slate-300 border-b border-white/8 tabular-nums">
                            <span>09:41</span>
                            <span className="text-[10px] tracking-wider uppercase text-[#D4AF77]">
                              Android Touch
                            </span>
                            <div className="flex items-center gap-1.5">
                              <Wifi className="w-3 h-3 text-slate-300" />
                              <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
                            </div>
                          </div>

                          {/* Android Mobile Screen Body: Aurora Greeting + Mini Bento */}
                          <div className="py-3 px-1.5 space-y-3 flex-1 flex flex-col justify-between">
                            <div className="p-3.5 rounded-2xl aurora-hero-surface">
                              <div className="flex items-center justify-between">
                                <span className="font-luxury-mono text-[10px] tracking-wider uppercase text-[#D4AF77]">
                                  Mobile Home Bento
                                </span>
                                <Smartphone className="w-3.5 h-3.5 text-[#D4AF77]" />
                              </div>
                              <div className="font-luxury-serif text-base tracking-[0.04em] text-white mt-1">
                                Aurora Glassmorphic UI
                              </div>
                              <p className="text-[11px] text-slate-300 mt-0.5">
                                Staggered spring tiles &amp; 12px blur bottom bar
                              </p>
                            </div>

                            {/* 2x2 Mini Bento Tiles inside Android Frame */}
                            <div className="grid grid-cols-2 gap-2">
                              <button
                                onClick={() => onEnterWorkspace('home')}
                                className="p-2.5 rounded-xl bg-slate-950/50 border border-white/8 hover:border-[#D4AF77]/50 text-left transition-colors cursor-pointer"
                              >
                                <div className="text-[10px] text-slate-400">Completion</div>
                                <div className="font-luxury-serif text-lg font-semibold text-white tabular-nums">
                                  {completionPct}%
                                </div>
                              </button>
                              <button
                                onClick={() => onEnterWorkspace('remaining')}
                                className="p-2.5 rounded-xl bg-slate-950/50 border border-white/8 hover:border-[#D4AF77]/50 text-left transition-colors cursor-pointer"
                              >
                                <div className="text-[10px] text-slate-400">Free Gap</div>
                                <div className="font-luxury-serif text-lg font-semibold text-white tabular-nums">
                                  {freeHoursFormatted}
                                </div>
                              </button>
                              <button
                                onClick={onOpenFocusMode}
                                className="p-2.5 rounded-xl bg-slate-950/50 border border-white/8 hover:border-[#D4AF77]/50 text-left transition-colors cursor-pointer"
                              >
                                <div className="text-[10px] text-slate-400">Focus</div>
                                <div className="font-luxury-serif text-lg font-semibold text-white tabular-nums">
                                  {focusHours}h
                                </div>
                              </button>
                              <button
                                onClick={() => onEnterWorkspace('analytics')}
                                className="p-2.5 rounded-xl bg-slate-950/50 border border-white/8 hover:border-[#D4AF77]/50 text-left transition-colors cursor-pointer"
                              >
                                <div className="text-[10px] text-slate-400">Sleep Score</div>
                                <div className="font-luxury-serif text-lg font-semibold text-white tabular-nums">
                                  {sleepScore}%
                                </div>
                              </button>
                            </div>

                            {/* Simulated Glassmorphic Bottom Nav Pill */}
                            <div className="pt-1 space-y-2">
                              <button
                                onClick={() => onEnterWorkspace('home')}
                                className="w-full py-2.5 px-3.5 rounded-xl bg-slate-950/60 border border-white/10 flex items-center justify-between text-xs font-medium text-white hover:border-[#D4AF77] transition-all cursor-pointer"
                              >
                                <span>Open Mobile Home</span>
                                <ChevronRight className="w-3.5 h-3.5 text-[#D4AF77]" />
                              </button>
                              <div className="w-20 h-1 bg-white/25 rounded-full mx-auto" />
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}

                {/* FRAME 02: BENTO TELEMETRY INTERACTIVE PREVIEW */}
                {activeFrame === 'bento-telemetry' && (
                  <motion.div
                    key="bento-telemetry"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.25 }}
                    className="space-y-5 flex-1 flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between border-b border-white/10 pb-3.5">
                      <div>
                        <span className="text-xs font-luxury-mono text-[#D4AF77]">
                          02. Daily Progress &amp; Stats
                        </span>
                        <h2 className="font-luxury-serif text-xl sm:text-2xl tracking-[0.04em] text-white mt-0.5">
                          Your 4 Key Daily Productivity Numbers
                        </h2>
                      </div>
                      <button
                        onClick={() => onEnterWorkspace('home')}
                        className="px-3.5 py-2 rounded-lg border border-white/15 hover:border-[#D4AF77] text-xs font-medium text-white hover:text-[#D4AF77] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        Open Dashboard
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <button
                        type="button"
                        onClick={() => onEnterWorkspace('schedule')}
                        className="p-5 rounded-2xl glass-layer-12 bento-card-hover border border-cyan-500/25 hover:border-cyan-400/60 space-y-2 text-left cursor-pointer transition-all active:scale-98"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-luxury-mono text-cyan-300 font-semibold">
                            01. Task Completion
                          </span>
                          <Activity className="w-4 h-4 text-cyan-400" />
                        </div>
                        <div className="font-luxury-serif text-3xl font-semibold text-white tabular-nums">
                          {completionPct}%{' '}
                          <span className="text-sm font-luxury-mono text-slate-400">
                            ({completedTasks} of {totalTasks})
                          </span>
                        </div>
                        <p className="text-xs text-slate-400">
                          Click to open 24h schedule &amp; execution checklist.
                        </p>
                      </button>

                      <button
                        type="button"
                        onClick={() => onEnterWorkspace('remaining')}
                        className="p-5 rounded-2xl glass-layer-12 bento-card-hover border border-emerald-500/25 hover:border-emerald-400/60 space-y-2 text-left cursor-pointer transition-all active:scale-98"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-luxury-mono text-emerald-400 font-semibold">
                            02. Unallocated Free Time
                          </span>
                          <Clock className="w-4 h-4 text-emerald-400" />
                        </div>
                        <div className="font-luxury-serif text-3xl font-semibold text-white tabular-nums">
                          {freeHoursFormatted}
                        </div>
                        <p className="text-xs text-slate-400">
                          {dayOccupancy.freeSlots.length} open windows — click to assign blocks.
                        </p>
                      </button>

                      <button
                        type="button"
                        onClick={onOpenFocusMode}
                        className="p-5 rounded-2xl glass-layer-12 bento-card-hover border border-violet-500/25 hover:border-violet-400/60 space-y-2 text-left cursor-pointer transition-all active:scale-98"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-luxury-mono text-violet-300 font-semibold">
                            03. Focus Hours
                          </span>
                          <Flame className="w-4 h-4 text-violet-400" />
                        </div>
                        <div className="font-luxury-serif text-3xl font-semibold text-white tabular-nums">
                          {focusHours} hrs
                        </div>
                        <p className="text-xs text-slate-400">
                          Click to launch Distraction-Free Focus Mode timer.
                        </p>
                      </button>

                      <button
                        type="button"
                        onClick={() => onEnterWorkspace('analytics')}
                        className="p-5 rounded-2xl glass-layer-12 bento-card-hover border border-amber-500/25 hover:border-amber-400/60 space-y-2 text-left cursor-pointer transition-all active:scale-98"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-luxury-mono text-[#D4AF77] font-semibold">
                            04. Sleep Recovery Score
                          </span>
                          <Moon className="w-4 h-4 text-[#D4AF77]" />
                        </div>
                        <div className="font-luxury-serif text-3xl font-semibold text-white tabular-nums">
                          {sleepScore}%{' '}
                          <span className="text-sm font-luxury-mono text-slate-400">
                            ({sleepHoursToday}h / {sleepConfig.targetHours}h)
                          </span>
                        </div>
                        <p className="text-xs text-slate-400">
                          Protected rest window: {formatTime12h(sleepConfig.bedTime)} –{' '}
                          {formatTime12h(sleepConfig.wakeTime)}.
                        </p>
                      </button>
                    </div>
                  </motion.div>
                )}

                {/* FRAME 03: 24H ROUTINE TIMELINE & INTERACTIVE TASK CHECKLIST */}
                {activeFrame === 'timeline-24h' && (
                  <motion.div
                    key="timeline-24h"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.25 }}
                    className="space-y-4 flex-1 flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between border-b border-white/10 pb-3.5">
                      <div>
                        <span className="text-xs font-luxury-mono text-[#D4AF77]">
                          03. 24-Hour Daily Routine
                        </span>
                        <h2 className="font-luxury-serif text-xl sm:text-2xl tracking-[0.04em] text-white mt-0.5">
                          Today&apos;s Task Checklist &amp; Fixed Hours
                        </h2>
                      </div>
                      <button
                        onClick={onOpenAddTask}
                        className="px-3.5 py-2 rounded-lg border border-white/15 hover:border-[#D4AF77] text-xs font-medium text-white hover:text-[#D4AF77] flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>New Task</span>
                      </button>
                    </div>

                    {/* Mandatory College/Work Banner */}
                    <div className="p-3.5 rounded-2xl glass-layer-12 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        {collegeConfig.commitmentType === 'job' ? (
                          <Briefcase className="w-4 h-4 text-[#D4AF77]" />
                        ) : (
                          <GraduationCap className="w-4 h-4 text-[#D4AF77]" />
                        )}
                        <div>
                          <div className="text-xs font-luxury-mono text-[#D4AF77]">
                            Locked {collegeConfig.commitmentType === 'job' ? 'Work Shift' : 'College'}{' '}
                            Block
                          </div>
                          <div className="text-xs text-white font-medium">
                            {collegeConfig.collegeName || (collegeConfig.commitmentType === 'job' ? 'Work Shift' : 'College Lectures')} · {formatTime12h(collegeConfig.startTime)} to{' '}
                            {formatTime12h(collegeConfig.endTime)}
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => onEnterWorkspace('college')}
                        className="text-xs font-medium text-[#D4AF77] hover:underline whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        Configure &rarr;
                      </button>
                    </div>

                    {/* Interactive Tasks List */}
                    <div className="space-y-2 max-h-[250px] overflow-y-auto pr-1">
                      {currentDayTasks.map((task) => (
                        <div
                          key={task.id}
                          onClick={() => onToggleComplete(task.id)}
                          className="p-3.5 rounded-2xl glass-layer-12 bento-card-hover flex items-center justify-between gap-3 cursor-pointer"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            {task.completed ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                            ) : (
                              <Circle className="w-4 h-4 text-[#D4AF77] shrink-0" />
                            )}
                            <div className="min-w-0">
                              <div
                                className={`text-sm truncate ${
                                  task.completed
                                    ? 'line-through text-slate-400'
                                    : 'text-white font-medium'
                                }`}
                              >
                                {task.title}
                              </div>
                              {task.topic && (
                                <div className="text-xs text-slate-400 truncate">
                                  Topic: {task.topic}
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="text-right shrink-0 font-luxury-mono tabular-nums">
                            <div className="text-xs text-[#D4AF77]">
                              {formatTime12h(task.startTime)} – {formatTime12h(task.endTime)}
                            </div>
                            <div className="text-[10px] text-slate-400 capitalize">
                              {task.category}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}

                {/* FRAME 04: FREE-GAP ALLOCATOR */}
                {activeFrame === 'gap-allocator' && (
                  <motion.div
                    key="gap-allocator"
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.25 }}
                    className="space-y-4 flex-1 flex flex-col justify-between"
                  >
                    <div className="flex items-center justify-between border-b border-white/10 pb-3.5">
                      <div>
                        <span className="text-xs font-luxury-mono text-emerald-400">
                          04. Free Time Planner
                        </span>
                        <h2 className="font-luxury-serif text-xl sm:text-2xl tracking-[0.04em] text-white mt-0.5">
                          {freeHoursFormatted} Free Time Across {dayOccupancy.freeSlots.length}{' '}
                          Open Slots
                        </h2>
                      </div>
                      <button
                        onClick={() => onEnterWorkspace('remaining')}
                        className="px-3.5 py-2 rounded-lg border border-white/15 hover:border-[#D4AF77] text-xs font-medium text-white hover:text-[#D4AF77] whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        Full Slot Planner
                      </button>
                    </div>

                    <div className="space-y-2.5 max-h-[290px] overflow-y-auto pr-1">
                      {dayOccupancy.freeSlots.slice(0, 5).map((slot, idx) => (
                        <div
                          key={`${slot.startTime}-${idx}`}
                          className="p-3.5 rounded-2xl glass-layer-12 bento-card-hover flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                        >
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2 font-luxury-mono text-xs tabular-nums">
                              <span className="text-emerald-400 font-semibold">
                                {formatDuration(slot.durationMinutes)} Open
                              </span>
                              <span aria-hidden="true" className="text-slate-500">
                                ·
                              </span>
                              <span className="text-white">
                                {formatTime12h(slot.startTime)} &ndash;{' '}
                                {formatTime12h(slot.endTime)}
                              </span>
                            </div>
                            <p className="text-xs text-slate-400 capitalize">
                              {slot.period} unallocated window · Ready for deep work or recovery
                            </p>
                          </div>

                          <button
                            onClick={() => {
                              onAssignFreeSlot(slot.startTime, slot.endTime);
                            }}
                            className="px-3.5 py-1.5 rounded-lg border border-white/15 hover:border-[#D4AF77] text-xs font-medium text-[#D4AF77] hover:bg-[#D4AF77] hover:text-slate-950 transition-colors self-start sm:self-center whitespace-nowrap shrink-0 cursor-pointer"
                          >
                            + Assign Block
                          </button>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Bottom Stage Footer Bar */}
              <div className="mt-5 pt-3.5 border-t border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF77]" />
                  <span>Local-first persistence · Android &amp; Web Browser synchronized</span>
                </div>
                <button
                  onClick={() => onEnterWorkspace('home')}
                  className="text-white hover:text-[#D4AF77] font-medium flex items-center gap-1 cursor-pointer"
                >
                  <span>Enter Full Planner</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Quiet Editorial Footer */}
      <footer className="relative z-10 border-t border-white/8 py-4 px-6 sm:px-10 lg:px-14">
        <div className="max-w-[1440px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2">
            <div className="flex flex-col items-center sm:items-start leading-tight">
              <span className="font-luxury-serif text-white tracking-wider">RoutineHub</span>
              <span className="font-luxury-mono text-[9px] tracking-[0.16em] uppercase text-[#D4AF77]">
                AR BISWANATH BEHERA
              </span>
            </div>
            <span aria-hidden="true" className="hidden sm:inline">·</span>
            <span>Hyper-Minimalist Temporal Architecture</span>
          </div>
          <div className="flex items-center gap-3">
            <span>Android Mobile Touch</span>
            <span aria-hidden="true">·</span>
            <span>Desktop Web Studio</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

