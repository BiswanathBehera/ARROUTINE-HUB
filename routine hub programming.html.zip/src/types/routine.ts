export type Priority = 'low' | 'medium' | 'high';

export type TaskCategory =
  | 'study'
  | 'trading'
  | 'video_editing'
  | 'programming'
  | 'exercise'
  | 'college'
  | 'personal'
  | 'break';

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Task {
  id: string;
  title: string;
  topic?: string;     // Specific topic covered (e.g. "Dynamic Programming", "Candlestick Patterns")
  learned?: string;   // What I have learned / key takeaways & insights
  category: TaskCategory;
  startTime: string; // "HH:MM" 24h format
  endTime: string;   // "HH:MM" 24h format
  priority: Priority;
  completed: boolean;
  notes?: string;
  subtasks: Subtask[];
  date: string; // YYYY-MM-DD
  isCollegeFixed?: boolean;
}

export type CommitmentType = 'college' | 'job';

export interface CollegeClassSlot {
  id: string;
  name: string;
  topic?: string;     // e.g. "Virtual Memory & Page Replacement" or "Sprint Review"
  learned?: string;   // What was taught & learned / key takeaways
  room?: string;      // Room, Desk, or Meeting Link
  professor?: string; // Professor or Manager/Lead
  startTime: string;
  endTime: string;
  type: 'lecture' | 'lab' | 'break' | 'tutorial' | 'meeting' | 'shift' | 'deep_work';
  dayOfWeek?: number; // 1 = Mon, ..., 6 = Sat
  alarmEnabled?: boolean; // Per-slot alarm toggle (defaults to true)
}

export interface FreeTimeSlot {
  id: string;
  startTime: string;
  endTime: string;
  durationMinutes: number;
  period: 'morning' | 'afternoon' | 'evening' | 'night';
}

export interface SleepConfig {
  enabled: boolean;
  bedTime: string; // "HH:MM" e.g. "22:30" (10:30 PM)
  wakeTime: string; // "HH:MM" e.g. "05:30" (5:30 AM)
  targetHours: number; // e.g. 7 (7.0 - 8.0 hours)
  windDownReminderMinutes: number; // e.g. 30 (alerts at 10:00 PM)
  windDownEnabled: boolean;
}

export type SleepLogsMap = Record<string, number>;


export interface DayOccupancySummary {
  wakingMinutes: number;
  sleepMinutes: number;
  collegeMinutes: number;
  routineMinutes: number;
  freeMinutes: number;
  freeSlots: {
    id: string;
    startTime: string;
    endTime: string;
    durationMinutes: number;
    period: 'morning' | 'afternoon' | 'evening' | 'night';
  }[];
}

export interface CollegeConfig {
  enabled: boolean;
  commitmentType?: CommitmentType; // 'college' | 'job' (default: 'college')
  collegeName: string; // University Campus or Company / Workplace Name
  startTime: string; // "09:00"
  endTime: string;   // "16:00"
  activeDays: number[]; // 0 = Sun, 1 = Mon, ..., 6 = Sat (e.g. [1, 2, 3, 4, 5])
  slots: CollegeClassSlot[];
  weeklyTimetable?: Record<number, CollegeClassSlot[]>; // Per-day timetable slots (1..6)
  dayStartHour?: string; // default "05:30" waking hour
  dayEndHour?: string;   // default "22:30" sleep hour
}

export interface NotificationSettings {
  soundEnabled: boolean;
  browserNotifications: boolean;
  reminderAdvanceMinutes: number; // e.g. 15 mins before
  hourlyRemainingAlert: boolean;
  classEndAlarmEnabled?: boolean;   // Alert after every class ends (default: true)
  classStartAlarmEnabled?: boolean; // Reminder when each class starts (default: true)
}

export interface WeeklyGoalMilestone {
  id: string;
  title: string;
  completed: boolean;
}

export interface WeeklyGoal {
  id: string;
  title: string;
  category: TaskCategory;
  targetValue: number;
  currentValue: number;
  unit: string; // e.g. 'hours', 'problems', 'sessions', 'videos', 'days'
  completed: boolean;
  weekStartDate?: string; // YYYY-MM-DD of Monday for this week
  notes?: string;
  priority?: Priority;
  milestones?: WeeklyGoalMilestone[];
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  provider: 'google' | 'email';
  avatarColor: string;
  createdAt: string;
  password?: string;
  syncEnabled?: boolean;
}


