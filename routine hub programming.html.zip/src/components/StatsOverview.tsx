import React from 'react';
import {
  PieChart,
  Target,
  Zap,
  BookOpen,
  TrendingUp,
  Film,
  Code2,
  Dumbbell,
  GraduationCap,
  Briefcase,
  Clock,
  Moon,
} from 'lucide-react';
import { CollegeConfig, SleepConfig, Task } from '../types/routine';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTime12h,
} from '../utils/dateUtils';

interface StatsOverviewProps {
  tasks: Task[];
  collegeConfig: CollegeConfig;
  sleepConfig?: SleepConfig;
}

export const StatsOverview: React.FC<StatsOverviewProps> = ({
  tasks,
  collegeConfig,
  sleepConfig,
}) => {
  const isJob = collegeConfig.commitmentType === 'job';
  const mandatoryMinutes = collegeConfig.enabled
    ? calculateDurationMinutes(collegeConfig.startTime, collegeConfig.endTime)
    : 0;

  // Compute category durations strictly for self-upgrade routine tasks
  const categoryMinutes: Record<string, number> = {
    study: 0,
    trading: 0,
    programming: 0,
    video_editing: 0,
    exercise: 0,
    personal: 0,
  };

  tasks.forEach((task) => {
    const dur = calculateDurationMinutes(task.startTime, task.endTime);
    if (categoryMinutes[task.category] !== undefined) {
      categoryMinutes[task.category] += dur;
    } else {
      categoryMinutes.personal += dur;
    }
  });

  // Calculate self-upgrade total minutes
  const totalRoutineMinutes = Object.values(categoryMinutes).reduce((a, b) => a + b, 0);

  const isSleepActive = sleepConfig?.enabled ?? true;
  const sleepBedTime = sleepConfig?.bedTime || '22:30';
  const sleepWakeTime = sleepConfig?.wakeTime || '05:30';
  const sleepMinutes = isSleepActive
    ? calculateDurationMinutes(sleepBedTime, sleepWakeTime)
    : 0;

  const cards = [
    {
      title: 'Study Hours',
      icon: BookOpen,
      duration: categoryMinutes.study,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/10 border-blue-500/20',
      barColor: 'bg-blue-500',
    },
    {
      title: 'Programming',
      icon: Code2,
      duration: categoryMinutes.programming,
      color: 'text-violet-400',
      bgColor: 'bg-violet-500/10 border-violet-500/20',
      barColor: 'bg-violet-500',
    },
    {
      title: 'Trading',
      icon: TrendingUp,
      duration: categoryMinutes.trading,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10 border-emerald-500/20',
      barColor: 'bg-emerald-500',
    },
    {
      title: 'Video Editing',
      icon: Film,
      duration: categoryMinutes.video_editing,
      color: 'text-pink-400',
      bgColor: 'bg-pink-500/10 border-pink-500/20',
      barColor: 'bg-pink-500',
    },
    {
      title: 'Exercise',
      icon: Dumbbell,
      duration: categoryMinutes.exercise,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/10 border-amber-500/20',
      barColor: 'bg-amber-500',
    },
    {
      title: 'Restorative Sleep',
      icon: Moon,
      duration: sleepMinutes,
      color: 'text-indigo-400',
      bgColor: 'bg-indigo-500/10 border-indigo-500/20',
      barColor: 'bg-indigo-500',
      customPct: Math.round((sleepMinutes / 1440) * 100),
      customSubtitle: `${formatTime12h(sleepBedTime)} – ${formatTime12h(sleepWakeTime)}`,
    },
  ];

  const totalTasks = tasks.length;
  const completedCount = tasks.filter((t) => t.completed).length;
  const remainingCount = tasks.filter((t) => !t.completed).length;
  const completionPercent = totalTasks === 0 ? 0 : Math.round((completedCount / totalTasks) * 100);

  // Dynamic feedback badge
  const getProductivityBadge = () => {
    if (totalTasks === 0) return { label: 'No Tasks Scheduled', color: 'text-slate-400 bg-slate-800 border-slate-700' };
    if (completionPercent === 100) return { label: '🌟 100% Completed - Outstanding Day!', color: 'text-emerald-300 bg-emerald-500/20 border-emerald-500/40' };
    if (completionPercent >= 75) return { label: '🔥 75%+ Crushing Today’s Goals', color: 'text-teal-300 bg-teal-500/20 border-teal-500/40' };
    if (completionPercent >= 50) return { label: '⚡ Over Halfway Complete', color: 'text-indigo-300 bg-indigo-500/20 border-indigo-500/40' };
    if (completionPercent > 0) return { label: '🚀 Active Routine in Progress', color: 'text-amber-300 bg-amber-500/20 border-amber-500/40' };
    return { label: '⏳ Ready to Start Today', color: 'text-slate-300 bg-slate-800 border-slate-700' };
  };

  const badge = getProductivityBadge();

  return (
    <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl border border-slate-800/80 p-4 sm:p-5 shadow-2xl space-y-4">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <PieChart className="w-4 h-4 text-indigo-400" />
          <h3 className="text-sm font-bold text-white tracking-wide">
            Self-Upgrade Productivity Overview
          </h3>
        </div>

        <div className="flex flex-wrap items-center gap-3 sm:gap-4 text-xs">
          <span className="text-slate-400">
            Self-Upgrade Tracked:{' '}
            <strong className="text-white font-mono">
              {formatDuration(totalRoutineMinutes)}
            </strong>
          </span>
          {isSleepActive && (
            <span className="text-indigo-400 flex items-center gap-1 font-mono">
              <Moon className="w-3 h-3" />
              Sleep: {formatDuration(sleepMinutes)}
            </span>
          )}
          {collegeConfig.enabled && mandatoryMinutes > 0 && (
            <span className="text-slate-500 hidden md:inline">
              ({isJob ? 'Work' : 'College'}: <span className="text-sky-300 font-mono">{formatDuration(mandatoryMinutes)}</span>)
            </span>
          )}
          <span className="text-slate-400">
            Tasks Left:{' '}
            <strong className="text-amber-400 font-mono">{remainingCount}</strong>
          </span>
          <span className="text-slate-400">
            Completed:{' '}
            <strong className="text-emerald-400 font-mono">{completedCount}</strong>
          </span>
        </div>
      </div>

      {/* Visual Task Completion Progress Bar Section */}
      <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-200">
              Daily Task Completion Rate
            </span>
            <span className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${badge.color}`}>
              {badge.label}
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="text-slate-400">
              <strong className="text-emerald-400 font-bold">{completedCount}</strong> of{' '}
              <strong className="text-white">{totalTasks}</strong> tasks completed
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-lg font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-300 via-blue-300 to-emerald-300">
              {completionPercent}%
            </span>
          </div>
        </div>

        {/* The Visual Progress Track */}
        <div className="relative">
          <div className="w-full bg-slate-900 h-4 rounded-full overflow-hidden p-0.5 border border-slate-800 shadow-inner">
            <div
              className={`h-full rounded-full transition-all duration-700 ease-out shadow-sm ${
                completionPercent === 100
                  ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-300'
                  : 'bg-gradient-to-r from-indigo-500 via-blue-500 to-emerald-400'
              }`}
              style={{ width: `${Math.min(100, completionPercent)}%` }}
            />
          </div>

          {/* Milestone markers at 25%, 50%, 75% */}
          <div className="absolute top-0 bottom-0 left-1/4 w-0.5 bg-slate-800 pointer-events-none opacity-60" />
          <div className="absolute top-0 bottom-0 left-2/4 w-0.5 bg-slate-800 pointer-events-none opacity-60" />
          <div className="absolute top-0 bottom-0 left-3/4 w-0.5 bg-slate-800 pointer-events-none opacity-60" />
        </div>

        {/* Milestone Labels */}
        <div className="flex justify-between text-[10px] text-slate-500 font-mono px-0.5">
          <span>0%</span>
          <span>25% Quarter</span>
          <span>50% Halfway</span>
          <span>75% Almost</span>
          <span className={completionPercent === 100 ? 'text-emerald-400 font-bold' : ''}>
            100% Goal
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {cards.map((c) => {
          const Icon = c.icon;
          const pct =
            c.customPct !== undefined
              ? c.customPct
              : totalRoutineMinutes > 0
              ? Math.round((c.duration / totalRoutineMinutes) * 100)
              : 0;

          const subtitle = c.customSubtitle || `${pct}% of daily schedule`;

          return (
            <div
              key={c.title}
              className={`p-3 rounded-xl border ${c.bgColor} flex flex-col justify-between`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-200 truncate">
                  {c.title}
                </span>
                <Icon className={`w-4 h-4 ${c.color} shrink-0`} />
              </div>

              <div>
                <div className="text-base font-bold text-white font-mono">
                  {formatDuration(c.duration)}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5 truncate" title={subtitle}>
                  {subtitle}
                </div>
                <div className="w-full bg-slate-800/90 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div
                    className={`h-full ${c.barColor} rounded-full`}
                    style={{ width: `${Math.min(100, pct)}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
