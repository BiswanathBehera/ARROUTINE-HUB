import React, { useEffect, useState } from 'react';
import { Lock, Clock, Sparkles, Moon } from 'lucide-react';
import { CollegeConfig, SleepConfig, Task } from '../types/routine';
import { CATEGORIES } from '../utils/categories';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTime12h,
  timeToMinutes,
} from '../utils/dateUtils';

interface VisualTimelineProps {
  tasks: Task[];
  collegeConfig: CollegeConfig;
  sleepConfig?: SleepConfig;
  isToday: boolean;
  onSelectTask: (task: Task) => void;
  onOpenCollegeSchedule: () => void;
  onOpenSleepSchedule?: () => void;
}

export const VisualTimeline: React.FC<VisualTimelineProps> = ({
  tasks,
  collegeConfig,
  sleepConfig,
  isToday,
  onSelectTask,
  onOpenCollegeSchedule,
  onOpenSleepSchedule,
}) => {
  const [currentMinutes, setCurrentMinutes] = useState(() => {
    const d = new Date();
    return d.getHours() * 60 + d.getMinutes();
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const d = new Date();
      setCurrentMinutes(d.getHours() * 60 + d.getMinutes());
    }, 30000); // update every 30s
    return () => clearInterval(timer);
  }, []);

  // Timeline runs from 05:00 (300 mins) to 24:00 (1440 mins)
  const DAY_START_MIN = 300; // 5:00 AM
  const DAY_END_MIN = 1440;  // 12:00 AM / Midnight
  const TOTAL_RANGE = DAY_END_MIN - DAY_START_MIN; // 1140 minutes (19 hours)

  const getPercentLeft = (mins: number) => {
    const clamped = Math.max(DAY_START_MIN, Math.min(DAY_END_MIN, mins));
    return ((clamped - DAY_START_MIN) / TOTAL_RANGE) * 100;
  };

  const collegeStartMin = timeToMinutes(collegeConfig.startTime);
  const collegeEndMin = timeToMinutes(collegeConfig.endTime);

  const collegeLeftPct = getPercentLeft(collegeStartMin);
  const collegeWidthPct = Math.max(
    2,
    getPercentLeft(collegeEndMin) - collegeLeftPct
  );

  // Sleep Schedule Configuration
  const isSleepActive = sleepConfig?.enabled ?? true;
  const bedTime = sleepConfig?.bedTime || '22:30';
  const wakeTime = sleepConfig?.wakeTime || '05:30';
  const bedMin = timeToMinutes(bedTime);
  const wakeMin = timeToMinutes(wakeTime);

  // Morning sleep block (e.g. 5:00 AM to 5:30 AM)
  const morningSleepEnd = Math.min(DAY_END_MIN, Math.max(DAY_START_MIN, wakeMin));
  const morningSleepLeftPct = getPercentLeft(DAY_START_MIN);
  const morningSleepWidthPct = Math.max(0, getPercentLeft(morningSleepEnd) - morningSleepLeftPct);

  // Night restorative sleep block (e.g. 10:30 PM to Midnight)
  const eveningSleepStart = Math.max(DAY_START_MIN, Math.min(DAY_END_MIN, bedMin));
  const eveningSleepLeftPct = getPercentLeft(eveningSleepStart);
  const eveningSleepWidthPct = Math.max(0, getPercentLeft(DAY_END_MIN) - eveningSleepLeftPct);

  // Time hour marks for axis
  const hourTicks = [6, 8, 10, 12, 14, 16, 18, 20, 22, 24];

  // Current time marker position
  const nowLeftPct = getPercentLeft(currentMinutes);
  const isNowInRange = currentMinutes >= DAY_START_MIN && currentMinutes <= DAY_END_MIN;

  const isJob = collegeConfig.commitmentType === 'job';

  return (
    <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl border border-slate-800/80 p-4 sm:p-5 shadow-2xl transition-colors">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-indigo-400" />
          <h3 className="text-sm font-bold text-white tracking-wide">
            24-Hour Visual Schedule Timeline
          </h3>
          <span className="text-[11px] text-slate-400 hidden md:inline">
            (5:00 AM – Midnight)
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 text-xs">
          {isSleepActive && (
            <button
              type="button"
              onClick={onOpenSleepSchedule}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-950/80 hover:bg-indigo-900/80 border border-indigo-500/40 hover:border-indigo-400 text-indigo-300 hover:text-white transition-all shadow-sm"
              title="Click to view & customize 7h sleep & wind-down schedule"
            >
              <Moon className="w-3.5 h-3.5 text-indigo-400" />
              <span className="font-semibold text-[11px]">
                Restorative Sleep ({formatTime12h(bedTime)} – {formatTime12h(wakeTime)})
              </span>
              <Lock className="w-3 h-3 text-indigo-400" />
            </button>
          )}

          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-sky-500/80 border border-sky-400" />
            <span className="text-slate-300 font-medium">
              {isJob ? 'Work Shift' : 'College'}
            </span>
            <Lock className="w-3 h-3 text-sky-400" />
          </div>

          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-indigo-500/80 border border-indigo-400" />
            <span className="text-slate-300 font-medium">Self-Upgrade</span>
          </div>

          {isToday && isNowInRange && (
            <div className="flex items-center gap-1 text-emerald-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
              <span>Now</span>
            </div>
          )}
        </div>
      </div>

      {/* Interactive Timeline Bar */}
      <div className="relative pt-6 pb-6 select-none overflow-x-auto">
        <div className="min-w-[650px] relative">
          
          {/* Main Track Background */}
          <div className="relative h-14 bg-slate-950/80 rounded-xl border border-slate-800 overflow-hidden shadow-inner">
            
            {/* Hour grid lines */}
            {hourTicks.map((h) => {
              const tickMin = h === 24 ? 1440 : h * 60;
              const left = getPercentLeft(tickMin);
              return (
                <div
                  key={h}
                  className="absolute top-0 bottom-0 border-l border-slate-800/80 pointer-events-none"
                  style={{ left: `${left}%` }}
                />
              );
            })}

            {/* Fixed College or Job Hours Block */}
            {collegeConfig.enabled && (
              <div
                onClick={onOpenCollegeSchedule}
                className="absolute top-1 bottom-1 rounded-lg bg-sky-950/60 border border-sky-500/50 hover:border-sky-400 transition-all cursor-pointer group z-10 flex flex-col justify-center items-center px-2 overflow-hidden shadow-md"
                style={{
                  left: `${collegeLeftPct}%`,
                  width: `${collegeWidthPct}%`,
                  backgroundImage:
                    'repeating-linear-gradient(45deg, rgba(2, 132, 199, 0.08), rgba(2, 132, 199, 0.08) 8px, rgba(14, 165, 233, 0.15) 8px, rgba(14, 165, 233, 0.15) 16px)',
                }}
                title={`Mandatory ${isJob ? 'Work' : 'College'} Hours: ${formatTime12h(collegeConfig.startTime)} to ${formatTime12h(collegeConfig.endTime)} (${collegeConfig.collegeName})`}
              >
                <div className="flex items-center gap-1 text-sky-300 group-hover:text-white font-semibold text-[11px] truncate">
                  <Lock className="w-3 h-3 text-sky-400 shrink-0" />
                  <span className="truncate">
                    {isJob ? 'Work Shift' : 'College Hours'} ({formatTime12h(collegeConfig.startTime)} -{' '}
                    {formatTime12h(collegeConfig.endTime)})
                  </span>
                </div>
                <div className="text-[9px] text-sky-400/80 truncate hidden sm:block">
                  {isJob
                    ? 'Workplace Duty (Handled in Timetable tab)'
                    : `${collegeConfig.slots.length} Lectures & Labs (Handled in Timetable tab)`}
                </div>
              </div>
            )}

            {/* Morning Restorative Sleep Block (e.g. 5:00 AM - 5:30 AM) */}
            {isSleepActive && morningSleepWidthPct > 0 && (
              <div
                onClick={onOpenSleepSchedule}
                className="absolute top-1 bottom-1 rounded-lg bg-indigo-950/75 border border-indigo-500/50 hover:border-indigo-400 transition-all cursor-pointer group z-10 flex flex-col justify-center items-center px-1 overflow-hidden shadow-md"
                style={{
                  left: `${morningSleepLeftPct}%`,
                  width: `${morningSleepWidthPct}%`,
                  backgroundImage:
                    'repeating-linear-gradient(45deg, rgba(79, 70, 229, 0.1), rgba(79, 70, 229, 0.1) 8px, rgba(99, 102, 241, 0.2) 8px, rgba(99, 102, 241, 0.2) 16px)',
                }}
                title={`Locked Restorative Sleep Window (until ${formatTime12h(wakeTime)}): Tap to configure sleep settings`}
              >
                <div className="flex items-center gap-1 text-indigo-300 group-hover:text-white font-semibold text-[10px] truncate">
                  <Moon className="w-3 h-3 text-indigo-400 shrink-0" />
                  <span className="truncate hidden sm:inline">Sleep ({formatTime12h(wakeTime)})</span>
                </div>
              </div>
            )}

            {/* Evening Restorative Sleep Block (e.g. 10:30 PM - Midnight) */}
            {isSleepActive && eveningSleepWidthPct > 0 && (
              <div
                onClick={onOpenSleepSchedule}
                className="absolute top-1 bottom-1 rounded-lg bg-indigo-950/75 border border-indigo-500/50 hover:border-indigo-400 transition-all cursor-pointer group z-10 flex flex-col justify-center items-center px-2 overflow-hidden shadow-md"
                style={{
                  left: `${eveningSleepLeftPct}%`,
                  width: `${eveningSleepWidthPct}%`,
                  backgroundImage:
                    'repeating-linear-gradient(45deg, rgba(79, 70, 229, 0.1), rgba(79, 70, 229, 0.1) 8px, rgba(99, 102, 241, 0.2) 8px, rgba(99, 102, 241, 0.2) 16px)',
                }}
                title={`Locked Restorative Sleep Window (${formatTime12h(bedTime)} to ${formatTime12h(wakeTime)} · 7h Protected): Tap to configure sleep settings`}
              >
                <div className="flex items-center gap-1 text-indigo-300 group-hover:text-white font-semibold text-[11px] truncate">
                  <Moon className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span className="truncate font-bold">
                    🌙 Restorative Sleep ({formatTime12h(bedTime)} – {formatTime12h(wakeTime)})
                  </span>
                  <Lock className="w-3 h-3 text-indigo-400 shrink-0" />
                </div>
                <div className="text-[9px] text-indigo-300/80 truncate hidden sm:block">
                  7h Protected Recovery Window (No task overlap)
                </div>
              </div>
            )}

            {/* Dynamic Routine Tasks Blocks */}
            {tasks.map((task) => {
              const startMin = timeToMinutes(task.startTime);
              const endMin = timeToMinutes(task.endTime);
              const leftPct = getPercentLeft(startMin);
              const rightPct = getPercentLeft(endMin);
              const widthPct = Math.max(1.8, rightPct - leftPct);

              const cat = CATEGORIES[task.category] || CATEGORIES.personal;
              const Icon = cat.icon;

              return (
                <div
                  key={task.id}
                  onClick={() => onSelectTask(task)}
                  className={`absolute top-2 bottom-2 rounded-lg cursor-pointer transition-transform hover:scale-y-105 hover:z-20 flex items-center px-1.5 overflow-hidden shadow-md border ${
                    task.completed
                      ? 'bg-slate-800/90 border-emerald-500/40 text-emerald-300 opacity-80'
                      : `${cat.badgeBg} ${cat.badgeBorder} text-white`
                  }`}
                  style={{
                    left: `${leftPct}%`,
                    width: `${widthPct}%`,
                    borderLeftWidth: '3px',
                    borderLeftColor: cat.colorHex,
                  }}
                  title={`${task.title} (${formatTime12h(task.startTime)} - ${formatTime12h(
                    task.endTime
                  )}) - ${cat.label}${task.completed ? ' [Completed]' : ''}`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0 mr-1" style={{ color: cat.colorHex }} />
                  <span className="text-[10px] font-semibold truncate leading-tight">
                    {task.title}
                  </span>
                </div>
              );
            })}

            {/* Current Time Indicator Vertical Red Line */}
            {isToday && isNowInRange && (
              <div
                className="absolute top-0 bottom-0 z-30 pointer-events-none"
                style={{ left: `${nowLeftPct}%` }}
              >
                <div className="w-0.5 h-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.9)]" />
                <div className="absolute -top-1.5 -left-1.5 w-3.5 h-3.5 rounded-full bg-rose-500 border-2 border-white animate-pulse shadow-md" />
              </div>
            )}
          </div>

          {/* Time axis ticks label */}
          <div className="relative mt-2 h-4 text-[10px] text-slate-400 font-mono">
            {hourTicks.map((h) => {
              const tickMin = h === 24 ? 1440 : h * 60;
              const left = getPercentLeft(tickMin);
              const label =
                h === 12
                  ? '12 PM'
                  : h === 24
                  ? '12 AM'
                  : h > 12
                  ? `${h - 12} PM`
                  : `${h} AM`;

              return (
                <div
                  key={h}
                  className="absolute -translate-x-1/2 whitespace-nowrap"
                  style={{ left: `${left}%` }}
                >
                  {label}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Routine Category Legend */}
      <div className="mt-2 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-slate-400 font-medium flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-indigo-400" /> Categories:
          </span>
          <span className="inline-flex items-center gap-1 text-[11px] text-blue-300">
            <span className="w-2 h-2 rounded-full bg-blue-500" /> Study Hours
          </span>
          <span className="inline-flex items-center gap-1 text-[11px] text-emerald-300">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> Trading
          </span>
          <span className="inline-flex items-center gap-1 text-[11px] text-pink-300">
            <span className="w-2 h-2 rounded-full bg-pink-500" /> Video Editing
          </span>
          <span className="inline-flex items-center gap-1 text-[11px] text-violet-300">
            <span className="w-2 h-2 rounded-full bg-violet-500" /> Programming
          </span>
          <span className="inline-flex items-center gap-1 text-[11px] text-amber-300">
            <span className="w-2 h-2 rounded-full bg-amber-500" /> Exercise
          </span>
        </div>

        <div className="text-[11px] text-slate-400">
          Tip: Tap any block to view or edit details.
        </div>
      </div>
    </div>
  );
};
