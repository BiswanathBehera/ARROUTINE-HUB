import React, { useEffect, useState, useMemo } from 'react';
import { motion, useReducedMotion, type Variants } from 'motion/react';
import {
  Sparkles,
  CheckCircle2,
  Circle,
  Clock,
  Flame,
  Moon,
  Zap,
  Plus,
  Calendar,
  ArrowUpRight,
  Play,
  FileUp,
  GraduationCap,
  Briefcase,
  TrendingUp,
  Minus,
  ChevronRight,
  Layers,
  ShieldCheck,
  Download,
  Bell,
  Smartphone,
  User,
} from 'lucide-react';
import {
  CollegeConfig,
  DayOccupancySummary,
  SleepConfig,
  SleepLogsMap,
  Task,
  UserAccount,
  WeeklyGoal,
} from '../types/routine';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTime12h,
  getTodayDateString,
  timeToMinutes,
} from '../utils/dateUtils';
import { ConsistencyStreakBadge } from './ConsistencyStreakBadge';

interface MobileHomeDashboardProps {
  tasks: Task[];
  currentDayTasks: Task[];
  selectedDate: string;
  onSelectDate: (date: string) => void;
  collegeConfig: CollegeConfig;
  sleepConfig: SleepConfig;
  sleepLogs: SleepLogsMap;
  onUpdateSleepLog: (dateStr: string, hours: number) => void;
  dayOccupancy: DayOccupancySummary;
  weeklyGoals: WeeklyGoal[];
  onToggleComplete: (taskId: string) => void;
  onEditTask: (task: Task) => void;
  onOpenAddTask: () => void;
  onAssignFreeSlot: (startTime: string, endTime: string) => void;
  onOpenFocusMode: () => void;
  onOpenTimetableUpload: () => void;
  onOpenSleepSettings: () => void;
  onOpenExport?: () => void;
  onTestAlarm?: () => void;
  onOpenApkModal?: () => void;
  activeUser?: UserAccount | null;
  onOpenAuthModal?: () => void;
  onNavigateTab: (tab: 'home' | 'schedule' | 'college' | 'analytics' | 'remaining') => void;
}

const CATEGORY_ACCENTS: Record<
  string,
  { label: string; dot: string; badge: string; text: string }
> = {
  study: {
    label: 'Academics',
    dot: 'bg-cyan-400',
    badge: 'bg-cyan-500/15 border-cyan-400/30 text-cyan-300',
    text: 'text-cyan-300',
  },
  programming: {
    label: 'Coding',
    dot: 'bg-emerald-400',
    badge: 'bg-emerald-500/15 border-emerald-400/30 text-emerald-300',
    text: 'text-emerald-300',
  },
  trading: {
    label: 'Trading',
    dot: 'bg-teal-400',
    badge: 'bg-teal-500/15 border-teal-400/30 text-teal-300',
    text: 'text-teal-300',
  },
  'video-editing': {
    label: 'Creative',
    dot: 'bg-violet-400',
    badge: 'bg-violet-500/15 border-violet-400/30 text-violet-300',
    text: 'text-violet-300',
  },
  exercise: {
    label: 'Fitness',
    dot: 'bg-sky-400',
    badge: 'bg-sky-500/15 border-sky-400/30 text-sky-300',
    text: 'text-sky-300',
  },
  other: {
    label: 'Routine',
    dot: 'bg-slate-400',
    badge: 'bg-slate-500/15 border-slate-400/30 text-slate-300',
    text: 'text-slate-300',
  },
};

export const MobileHomeDashboard: React.FC<MobileHomeDashboardProps> = ({
  tasks,
  currentDayTasks,
  selectedDate,
  onSelectDate,
  collegeConfig,
  sleepConfig,
  sleepLogs,
  onUpdateSleepLog,
  dayOccupancy,
  weeklyGoals,
  onToggleComplete,
  onEditTask,
  onOpenAddTask,
  onAssignFreeSlot,
  onOpenFocusMode,
  onOpenTimetableUpload,
  onOpenSleepSettings,
  onOpenExport,
  onTestAlarm,
  onOpenApkModal,
  activeUser,
  onOpenAuthModal,
  onNavigateTab,
}) => {
  const [now, setNow] = useState(() => new Date());
  const prefersReducedMotion = useReducedMotion();

  // Magnetic button pull & tactile pointer state for the Primary CTA and 7-day candle interfaces
  const [magneticOffset, setMagneticOffset] = useState({ x: 0, y: 0 });
  const [pressedCandleDate, setPressedCandleDate] = useState<string | null>(null);
  const [isCandlePointerDown, setIsCandlePointerDown] = useState(false);

  const triggerTactileFeedback = () => {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      try {
        navigator.vibrate(8);
      } catch {
        // Ignore vibration errors on unsupported browsers
      }
    }
  };

  const handleMagneticPointerMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (prefersReducedMotion) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    setMagneticOffset({
      x: (e.clientX - centerX) * 0.16,
      y: (e.clientY - centerY) * 0.2,
    });
  };

  const handleMagneticPointerDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    triggerTactileFeedback();
    handleMagneticPointerMove(e);
  };

  const handleMagneticPointerReset = () => {
    setMagneticOffset({ x: 0, y: 0 });
  };

  const handleCandlePointerDown = (
    dateStr: string,
    e: React.PointerEvent<HTMLButtonElement>
  ) => {
    // Allow left mouse click, touch, or pen contact
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    setIsCandlePointerDown(true);
    setPressedCandleDate(dateStr);
    triggerTactileFeedback();
    onSelectDate(dateStr);
  };

  const handleCandlePointerEnter = (
    dateStr: string,
    e: React.PointerEvent<HTMLButtonElement>
  ) => {
    // Support smooth pointer scrubbing across candle bars when button/touch is held down
    if (isCandlePointerDown || (e.pointerType === 'mouse' && e.buttons === 1)) {
      setPressedCandleDate(dateStr);
      triggerTactileFeedback();
      onSelectDate(dateStr);
    }
  };

  const handleCandlePointerUpOrCancel = () => {
    setIsCandlePointerDown(false);
    setPressedCandleDate(null);
  };

  const handleCandleKeyDown = (
    dateStr: string,
    e: React.KeyboardEvent<HTMLButtonElement>
  ) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      triggerTactileFeedback();
      onSelectDate(dateStr);
    }
  };

  const bentoContainerVariants: Variants = useMemo(
    () => ({
      hidden: { opacity: 0 },
      visible: {
        opacity: 1,
        transition: {
          staggerChildren: prefersReducedMotion ? 0 : 0.065,
          delayChildren: prefersReducedMotion ? 0 : 0.04,
        },
      },
    }),
    [prefersReducedMotion]
  );

  const bentoTileVariants: Variants = useMemo(
    () =>
      prefersReducedMotion
        ? {
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { duration: 0.15 } },
          }
        : {
            hidden: { opacity: 0, y: 18, scale: 0.98 },
            visible: {
              opacity: 1,
              y: 0,
              scale: 1,
              transition: {
                type: 'spring',
                stiffness: 340,
                damping: 26,
                mass: 0.85,
              },
            },
          },
    [prefersReducedMotion]
  );

  const tileHoverMotion = useMemo(
    () =>
      prefersReducedMotion
        ? undefined
        : {
            y: -2,
            scale: 1.006,
            transition: { type: 'spring' as const, stiffness: 400, damping: 25 },
          },
    [prefersReducedMotion]
  );

  const tileTapMotion = useMemo(
    () =>
      prefersReducedMotion
        ? undefined
        : {
            scale: 0.992,
            transition: { type: 'spring' as const, stiffness: 450, damping: 30 },
          },
    [prefersReducedMotion]
  );

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 15000);
    return () => clearInterval(timer);
  }, []);

  const todayStr = getTodayDateString();
  const isSelectedToday = selectedDate === todayStr;
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  // Dynamic time-of-day greeting
  const greetingData = useMemo(() => {
    const hour = now.getHours();
    if (hour >= 5 && hour < 12) {
      return {
        greeting: 'Good Morning',
        subtitle: 'Peak cognitive clarity window is open.',
        chip: 'Morning Flow',
      };
    }
    if (hour >= 12 && hour < 17) {
      return {
        greeting: 'Good Afternoon',
        subtitle: 'Stay locked in on high-leverage blocks.',
        chip: 'Midday Momentum',
      };
    }
    if (hour >= 17 && hour < 22) {
      return {
        greeting: 'Good Evening',
        subtitle: 'Execute deep self-upgrade sessions before wind-down.',
        chip: 'Evening Sprint',
      };
    }
    return {
      greeting: 'Late Night Flow',
      subtitle: 'Protect your restorative sleep window.',
      chip: 'Recovery Mode',
    };
  }, [now]);

  // 7-day strip centered around selectedDate's week (Mon - Sun)
  const weekDays = useMemo(() => {
    const [y, m, d] = selectedDate.split('-').map(Number);
    const target = new Date(y, m - 1, d);
    const day = target.getDay();
    const distToMonday = day === 0 ? -6 : 1 - day;
    const monday = new Date(target);
    monday.setDate(target.getDate() + distToMonday);

    return Array.from({ length: 7 }, (_, i) => {
      const dt = new Date(monday);
      dt.setDate(monday.getDate() + i);
      const yr = dt.getFullYear();
      const mo = String(dt.getMonth() + 1).padStart(2, '0');
      const da = String(dt.getDate()).padStart(2, '0');
      const dateStr = `${yr}-${mo}-${da}`;
      const dayTasks = tasks.filter((t) => t.date === dateStr);
      const completed = dayTasks.filter((t) => t.completed).length;
      const total = dayTasks.length;
      const pct = total > 0 ? Math.round((completed / total) * 100) : 0;

      return {
        dateStr,
        shortDay: dt.toLocaleDateString(undefined, { weekday: 'short' }),
        dayNum: dt.getDate(),
        isSelected: dateStr === selectedDate,
        isToday: dateStr === todayStr,
        total,
        completed,
        pct,
      };
    });
  }, [selectedDate, tasks, todayStr]);

  // Active or Next Upcoming Task Spotlight
  const spotlightTask = useMemo(() => {
    const sorted = [...currentDayTasks].sort(
      (a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime)
    );
    if (sorted.length === 0) return null;

    if (isSelectedToday) {
      const running = sorted.find((t) => {
        const s = timeToMinutes(t.startTime);
        const e = timeToMinutes(t.endTime);
        return !t.completed && currentMinutes >= s && currentMinutes <= e;
      });
      if (running) {
        const s = timeToMinutes(running.startTime);
        const e = timeToMinutes(running.endTime);
        const total = Math.max(1, e - s);
        const elapsed = Math.max(0, currentMinutes - s);
        const remaining = Math.max(0, e - currentMinutes);
        return {
          task: running,
          status: 'Live Now' as const,
          progressPct: Math.min(100, Math.round((elapsed / total) * 100)),
          timeMeta: `${remaining}m left`,
        };
      }

      const upcoming = sorted.find(
        (t) => !t.completed && timeToMinutes(t.startTime) > currentMinutes
      );
      if (upcoming) {
        const startsIn = timeToMinutes(upcoming.startTime) - currentMinutes;
        return {
          task: upcoming,
          status: 'Up Next' as const,
          progressPct: 0,
          timeMeta: `in ${formatDuration(startsIn)}`,
        };
      }
    }

    const firstPending = sorted.find((t) => !t.completed) || sorted[0];
    return {
      task: firstPending,
      status: firstPending.completed ? ('Completed' as const) : ('Scheduled' as const),
      progressPct: firstPending.completed ? 100 : 0,
      timeMeta: formatDuration(
        calculateDurationMinutes(firstPending.startTime, firstPending.endTime)
      ),
    };
  }, [currentDayTasks, isSelectedToday, currentMinutes]);

  // Metric 1: Task Completion Stats
  const completionStats = useMemo(() => {
    const total = currentDayTasks.length;
    const completed = currentDayTasks.filter((t) => t.completed).length;
    const pending = total - completed;
    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
    const highPriorityPending = currentDayTasks.filter(
      (t) => !t.completed && t.priority === 'high'
    ).length;
    const pendingList = currentDayTasks
      .filter((t) => !t.completed)
      .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime))
      .slice(0, 3);

    return {
      total,
      completed,
      pending,
      percentage,
      highPriorityPending,
      pendingList,
    };
  }, [currentDayTasks]);

  // Metric 2: Free Time Stats
  const freeTimeStats = useMemo(() => {
    const { freeMinutes, wakingMinutes, freeSlots } = dayOccupancy;
    const freePct =
      wakingMinutes > 0 ? Math.min(100, Math.round((freeMinutes / wakingMinutes) * 100)) : 0;

    let bestSlot = freeSlots[0] || null;
    if (isSelectedToday && freeSlots.length > 0) {
      const upcomingSlot = freeSlots.find(
        (slot) => timeToMinutes(slot.endTime) > currentMinutes
      );
      bestSlot = upcomingSlot || freeSlots[0];
    } else if (freeSlots.length > 0) {
      bestSlot = [...freeSlots].sort((a, b) => b.durationMinutes - a.durationMinutes)[0];
    }

    return {
      freeMinutes,
      freePct,
      slotCount: freeSlots.length,
      bestSlot,
    };
  }, [dayOccupancy, isSelectedToday, currentMinutes]);

  // Metric 3: Focus Hours & Deep Work Breakdown
  const focusStats = useMemo(() => {
    const deepCategories = new Set(['study', 'programming', 'trading', 'video-editing']);
    let deepWorkMinutes = 0;
    let completedFocusMinutes = 0;
    let fitnessMinutes = 0;

    currentDayTasks.forEach((t) => {
      const dur = calculateDurationMinutes(t.startTime, t.endTime);
      if (deepCategories.has(t.category)) {
        deepWorkMinutes += dur;
        if (t.completed) {
          completedFocusMinutes += dur;
        }
      } else if (t.category === 'exercise') {
        fitnessMinutes += dur;
      }
    });

    const collegeMins = dayOccupancy.collegeMinutes;
    const totalFocusMinutes = deepWorkMinutes + collegeMins;
    const totalFocusHours = (totalFocusMinutes / 60).toFixed(1);
    const deepWorkHours = (deepWorkMinutes / 60).toFixed(1);
    const completedDeepHours = (completedFocusMinutes / 60).toFixed(1);

    const denom = Math.max(1, totalFocusMinutes + fitnessMinutes);
    const deepShare = Math.round((deepWorkMinutes / denom) * 100);
    const collegeShare = Math.round((collegeMins / denom) * 100);
    const fitnessShare = Math.max(0, 100 - deepShare - collegeShare);

    return {
      totalFocusMinutes,
      totalFocusHours,
      deepWorkHours,
      completedDeepHours,
      collegeHours: (collegeMins / 60).toFixed(1),
      deepShare,
      collegeShare,
      fitnessShare,
    };
  }, [currentDayTasks, dayOccupancy.collegeMinutes]);

  // Metric 4: Sleep Score & Restorative Recovery
  const sleepStats = useMemo(() => {
    const targetHours = sleepConfig.targetHours || 7;
    const loggedHours =
      sleepLogs[selectedDate] !== undefined ? sleepLogs[selectedDate] : targetHours;

    const ratio = loggedHours / Math.max(1, targetHours);
    let score = Math.round(Math.min(100, ratio * 95 + (loggedHours >= targetHours ? 5 : 0)));
    if (loggedHours > 10.5) {
      score = Math.max(70, 100 - Math.round((loggedHours - 10.5) * 10));
    }
    score = Math.max(20, Math.min(100, score));

    let tier = 'Optimal Recovery';
    let tierColor = 'text-emerald-300 bg-emerald-500/15 border-emerald-400/30';
    if (score < 70) {
      tier = 'Sleep Debt';
      tierColor = 'text-amber-300 bg-amber-500/15 border-amber-400/30';
    } else if (score < 88) {
      tier = 'Balanced Rest';
      tierColor = 'text-cyan-300 bg-cyan-500/15 border-cyan-400/30';
    }

    const bedMin = timeToMinutes(sleepConfig.bedTime || '22:30');
    let minsUntilBed = bedMin - currentMinutes;
    if (minsUntilBed < 0) minsUntilBed += 1440;

    return {
      targetHours,
      loggedHours,
      score,
      tier,
      tierColor,
      minsUntilBed,
    };
  }, [sleepConfig, sleepLogs, selectedDate, currentMinutes]);

  // Weekly Momentum summary
  const weeklyPulse = useMemo(() => {
    const totalTasks = weekDays.reduce((acc, d) => acc + d.total, 0);
    const completedTasks = weekDays.reduce((acc, d) => acc + d.completed, 0);
    const weeklyRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    const activeGoals = weeklyGoals.filter((g) => !g.completed).length;
    return { totalTasks, completedTasks, weeklyRate, activeGoals };
  }, [weekDays, weeklyGoals]);

  // SVG Ring Constants for Task Completion
  const ringRadius = 38;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const ringOffset =
    ringCircumference - (completionStats.percentage / 100) * ringCircumference;

  return (
    <section className="space-y-5 sm:space-y-6 pb-8">
      {/* =====================================================================
          1. GREETING HERO CARD (VIBRANT AURORA ACROSS MOBILE, TABLET & LAPTOP)
         ===================================================================== */}
      <motion.div
        initial={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, y: 14, scale: 0.99 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="relative group"
      >
        {/* Ambient Aurora Glow Behind Card */}
        <div
          aria-hidden="true"
          className="absolute -inset-1 rounded-[28px] bg-gradient-to-r from-cyan-500/25 via-violet-500/25 to-emerald-500/20 blur-2xl opacity-85 group-hover:opacity-100 transition duration-500 pointer-events-none"
        />

        <div className="relative overflow-hidden rounded-[26px] aurora-hero-surface p-5 sm:p-7">
          {/* Internal Soft Aurora Orbs */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 -left-16 w-72 h-72 rounded-full bg-cyan-500/25 blur-[85px] aurora-orb-float"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -bottom-28 left-1/3 w-80 h-80 rounded-full bg-violet-500/25 blur-[90px] aurora-orb-float-delayed"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-16 -right-16 w-64 h-64 rounded-full bg-emerald-500/20 blur-[80px] aurora-orb-float"
          />

          <div className="relative z-10 space-y-4 sm:space-y-5">
            {/* Top Bar: Status Chip, Streak Flame/Candle Badge & Live Clock */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-luxury-mono text-slate-400 border-b border-white/10 pb-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                  {greetingData.chip}
                </span>
                <ConsistencyStreakBadge
                  tasks={tasks}
                  selectedDate={selectedDate}
                  onSelectDate={onSelectDate}
                />
                {onOpenAuthModal && (
                  <button
                    type="button"
                    onClick={onOpenAuthModal}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl border text-[11px] font-semibold transition-all cursor-pointer ${
                      activeUser
                        ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/25'
                        : 'bg-amber-400/15 border-amber-400/45 text-amber-200 hover:bg-amber-400/25'
                    }`}
                    title={
                      activeUser
                        ? `Signed in as ${activeUser.name} (${activeUser.email})`
                        : 'Open Initialize Login / Create Account'
                    }
                  >
                    <User className="w-3.5 h-3.5 text-amber-300" />
                    <span>{activeUser ? activeUser.name : 'Sign In / Account'}</span>
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2 tabular-nums text-slate-200">
                <span className="text-cyan-300 font-semibold">
                  {now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
                <span aria-hidden="true" className="text-slate-500">
                  ·
                </span>
                <span className="text-slate-300 font-sans">
                  {now.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                </span>
              </div>
            </div>

            {/* Main Greeting Headline + Action Triggers */}
            <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 sm:gap-5">
              <div className="space-y-2 max-w-xl w-full">
                <h2
                  style={{ textWrap: 'balance' }}
                  className="font-sans text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white leading-tight"
                >
                  {greetingData.greeting},{' '}
                  <span className="bg-gradient-to-r from-cyan-300 via-violet-300 to-emerald-300 bg-clip-text text-transparent">
                    {activeUser ? activeUser.name : 'Achiever'}
                  </span>
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {greetingData.subtitle} You have{' '}
                  <span className="text-cyan-300 font-semibold font-luxury-mono tabular-nums">
                    {completionStats.pending}
                  </span>{' '}
                  pending tasks and{' '}
                  <span className="text-emerald-400 font-semibold font-luxury-mono tabular-nums">
                    {formatDuration(freeTimeStats.freeMinutes)}
                  </span>{' '}
                  of open capacity today.
                </p>

                {/* Daily Efficiency Progress Bar (Applied across Mobile, Tablet & Laptop) */}
                <div className="pt-1.5 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] font-luxury-mono tabular-nums">
                    <span className="text-slate-300 font-medium">Daily Execution Progress</span>
                    <span className="text-cyan-300 font-bold">
                      {completionStats.completed}/{completionStats.total} ({completionStats.percentage}%)
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-slate-950/80 border border-white/10 overflow-hidden p-0.5">
                    <div
                      style={{ width: `${Math.max(4, completionStats.percentage)}%` }}
                      className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-violet-400 to-emerald-400 transition-all duration-500 shadow-[0_0_10px_rgba(34,211,238,0.5)]"
                    />
                  </div>
                </div>
              </div>

              {/* Hero Actions: Vibrant Dual Buttons on Mobile, Tablet & Laptop */}
              <div className="grid grid-cols-2 sm:flex items-center gap-2.5 sm:gap-3">
                <button
                  onClick={onOpenFocusMode}
                  className="min-h-[46px] px-4 py-2.5 rounded-xl bg-violet-500/15 border border-violet-400/35 hover:border-violet-300 hover:bg-violet-500/25 text-violet-100 hover:text-white text-xs font-semibold flex items-center justify-center gap-2 transition-all active:scale-95 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Zap className="w-4 h-4 text-violet-300" />
                  <span>Focus Mode</span>
                </button>
                <button
                  onPointerDown={handleMagneticPointerDown}
                  onPointerMove={handleMagneticPointerMove}
                  onPointerUp={handleMagneticPointerReset}
                  onPointerLeave={handleMagneticPointerReset}
                  onPointerCancel={handleMagneticPointerReset}
                  onClick={onOpenAddTask}
                  style={{
                    transform: `translate3d(${magneticOffset.x}px, ${magneticOffset.y}px, 0)`,
                    touchAction: 'manipulation',
                  }}
                  className="min-h-[46px] px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-500 to-indigo-600 text-slate-950 font-bold shadow-[0_0_20px_rgba(34,211,238,0.3)] hover:shadow-[0_0_26px_rgba(34,211,238,0.45)] magnetic-cta text-xs tracking-wide flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer select-none"
                >
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                  <span>+ Add Task</span>
                </button>
              </div>
            </div>

            {/* 7-Day Horizontal Tactile Date Selector (PointerEvent-driven across Mobile, Tablet & Laptop) */}
            <div
              className="pt-1"
              onPointerUp={handleCandlePointerUpOrCancel}
              onPointerLeave={handleCandlePointerUpOrCancel}
              onPointerCancel={handleCandlePointerUpOrCancel}
            >
              <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
                {weekDays.map((day) => {
                  const isPressed = pressedCandleDate === day.dateStr;
                  return (
                    <button
                      key={day.dateStr}
                      type="button"
                      onPointerDown={(e) => handleCandlePointerDown(day.dateStr, e)}
                      onPointerEnter={(e) => handleCandlePointerEnter(day.dateStr, e)}
                      onPointerUp={handleCandlePointerUpOrCancel}
                      onPointerCancel={handleCandlePointerUpOrCancel}
                      onKeyDown={(e) => handleCandleKeyDown(day.dateStr, e)}
                      style={{ touchAction: 'manipulation' }}
                      className={`min-h-[58px] rounded-2xl px-1.5 py-2 flex flex-col items-center justify-center gap-1 transition-all border cursor-pointer relative select-none ${
                        isPressed
                          ? 'scale-95 bg-gradient-to-b from-cyan-400/40 to-indigo-500/40 border-cyan-300 text-white shadow-[0_0_22px_rgba(34,211,238,0.45)]'
                          : day.isSelected
                          ? 'bg-gradient-to-b from-cyan-500/30 to-indigo-600/30 border-cyan-400/70 text-white shadow-[0_0_16px_rgba(34,211,238,0.25)]'
                          : day.isToday
                          ? 'bg-slate-900/75 border-cyan-400/30 text-cyan-200 hover:bg-slate-800/70'
                          : 'bg-slate-950/50 border-white/10 text-slate-400 hover:text-white hover:bg-slate-900/60'
                      }`}
                    >
                      {(day.isSelected || isPressed) && (
                        <span
                          className={`absolute top-1 w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee] ${
                            isPressed ? 'scale-125 animate-ping' : ''
                          }`}
                        />
                      )}
                      <span className="text-[10px] font-semibold uppercase tracking-wider opacity-85">
                        {day.shortDay}
                      </span>
                      <span className="text-sm font-bold font-luxury-mono tabular-nums">
                        {day.dayNum}
                      </span>
                      <span
                        className={`text-[10px] font-luxury-mono tabular-nums ${
                          day.isSelected || isPressed
                            ? 'text-cyan-300 font-semibold'
                            : day.pct === 100
                            ? 'text-emerald-400'
                            : 'text-slate-400'
                        }`}
                      >
                        {day.total === 0 ? '—' : `${day.pct}%`}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Live Active / Upcoming Spotlight Strip inside Hero */}
            {spotlightTask ? (
              <div className="rounded-2xl glass-layer-12 border border-cyan-400/20 p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start sm:items-center gap-3 min-w-0">
                  <button
                    onClick={() => onToggleComplete(spotlightTask.task.id)}
                    aria-label="Toggle spotlight task completion"
                    className="min-w-[44px] min-h-[44px] -m-1.5 flex items-center justify-center rounded-xl text-cyan-400 hover:bg-white/5 transition-colors shrink-0 cursor-pointer"
                  >
                    {spotlightTask.task.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    ) : (
                      <Circle className="w-5 h-5 text-cyan-400" />
                    )}
                  </button>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs font-luxury-mono tabular-nums text-slate-400">
                      <span className="text-cyan-300 font-semibold">
                        {spotlightTask.status}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="text-slate-200">
                        {formatTime12h(spotlightTask.task.startTime)} –{' '}
                        {formatTime12h(spotlightTask.task.endTime)}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="text-emerald-400 font-semibold">{spotlightTask.timeMeta}</span>
                    </div>
                    <p
                      onClick={() => onEditTask(spotlightTask.task)}
                      className={`text-sm sm:text-base font-semibold truncate mt-0.5 cursor-pointer hover:text-cyan-300 transition-colors ${
                        spotlightTask.task.completed
                          ? 'line-through text-slate-400'
                          : 'text-white'
                      }`}
                    >
                      {spotlightTask.task.title}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  <button
                    onClick={onOpenFocusMode}
                    className="min-h-[40px] px-3.5 py-2 rounded-xl bg-cyan-500/15 border border-cyan-400/35 hover:border-cyan-400 text-cyan-200 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95 whitespace-nowrap cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 text-cyan-300" />
                    <span>Start Focus</span>
                  </button>
                  <button
                    onClick={() => onNavigateTab('schedule')}
                    className="min-h-[40px] px-3 py-2 rounded-xl border border-white/12 hover:border-cyan-400/40 text-slate-200 hover:text-white text-xs font-medium flex items-center gap-1 transition-all whitespace-nowrap cursor-pointer"
                  >
                    <span>Timeline</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="rounded-2xl glass-layer-12 border border-cyan-400/20 p-4 flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-white">No routine blocks scheduled yet</p>
                  <p className="text-xs text-slate-400">
                    Add your first study, coding, or workout block for this date.
                  </p>
                </div>
                <button
                  onClick={onOpenAddTask}
                  className="min-h-[44px] px-3.5 py-2 rounded-xl bg-cyan-500/15 border border-cyan-400/35 hover:border-cyan-400 text-xs font-semibold text-cyan-300 shrink-0 cursor-pointer"
                >
                  + Add Block
                </button>
              </div>
            )}
          </div>
        </div>
      </motion.div>

      {/* =====================================================================
          2. MODULAR GLASSMORPHIC BENTO GRID (COLORFUL AURORA CARDS ON ALL VIEWPORTS)
         ===================================================================== */}
      <motion.div
        key={selectedDate}
        variants={bentoContainerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-2 lg:grid-cols-12 gap-3.5 sm:gap-5"
      >
        {/* -------------------------------------------------------------------
            BENTO TILE 1: TASK COMPLETION VELOCITY (col-span-2 lg:col-span-5)
           ------------------------------------------------------------------- */}
        <motion.div
          variants={bentoTileVariants}
          whileHover={tileHoverMotion}
          whileTap={tileTapMotion}
          className="col-span-2 lg:col-span-5 glass-bento-tile border-cyan-500/20 rounded-[24px] p-5 sm:p-6 flex flex-col justify-between gap-4 relative overflow-hidden"
        >
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -right-12 -top-12 w-44 h-44 rounded-full bg-cyan-500/20 blur-2xl"
          />

          <div className="flex items-start justify-between gap-3">
            <div>
              <span className="text-xs font-luxury-mono font-semibold text-cyan-400">
                01. Task Completion
              </span>
              <h3 className="font-sans text-lg sm:text-xl font-bold tracking-tight text-white mt-0.5">
                Daily Execution Ring
              </h3>
            </div>
            <button
              onClick={() => onNavigateTab('schedule')}
              className="min-h-[36px] px-3 py-1 rounded-xl bg-cyan-500/12 border border-cyan-400/30 hover:border-cyan-400 text-xs font-semibold text-cyan-200 hover:text-white flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <span>All Tasks</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Radial SVG Ring + Numeric Breakdown */}
          <div className="flex items-center gap-4 sm:gap-5">
            <div className="relative w-24 h-24 shrink-0 flex items-center justify-center">
              <svg className="w-24 h-24 -rotate-90" viewBox="0 0 96 96">
                <defs>
                  <linearGradient id="auroraRingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#22D3EE" />
                    <stop offset="50%" stopColor="#8B5CF6" />
                    <stop offset="100%" stopColor="#10B981" />
                  </linearGradient>
                </defs>
                <circle
                  cx="48"
                  cy="48"
                  r={ringRadius}
                  fill="transparent"
                  stroke="rgba(148, 163, 184, 0.14)"
                  strokeWidth="7"
                />
                <circle
                  cx="48"
                  cy="48"
                  r={ringRadius}
                  fill="transparent"
                  stroke="url(#auroraRingGrad)"
                  strokeWidth="7"
                  strokeLinecap="round"
                  strokeDasharray={ringCircumference}
                  strokeDashoffset={ringOffset}
                  className="transition-all duration-700 ease-out"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="font-sans text-xl font-bold text-white tabular-nums">
                  {completionStats.percentage}%
                </span>
                <span className="text-[10px] text-cyan-300 font-luxury-mono tabular-nums">
                  {completionStats.completed}/{completionStats.total}
                </span>
              </div>
            </div>

            <div className="flex-1 grid grid-cols-2 gap-2.5">
              <div className="rounded-2xl bg-emerald-500/10 border border-emerald-400/25 p-3">
                <span className="text-[11px] text-emerald-200/80 block">
                  Completed
                </span>
                <span className="font-sans text-xl font-bold text-emerald-400 tabular-nums">
                  {completionStats.completed}
                </span>
                <span className="text-[10px] text-slate-400 block">blocks done</span>
              </div>
              <div className="rounded-2xl bg-violet-500/10 border border-violet-400/25 p-3">
                <span className="text-[11px] text-violet-200/80 block">
                  High Priority
                </span>
                <span className="font-sans text-xl font-bold text-violet-300 tabular-nums">
                  {completionStats.highPriorityPending}
                </span>
                <span className="text-[10px] text-slate-400 block">remaining</span>
              </div>
            </div>
          </div>

          {/* Quick-Toggle Next Pending Tasks */}
          <div className="space-y-1.5 pt-2 border-t border-white/10">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span className="font-medium">Quick Check-Off Queue</span>
              <span className="font-luxury-mono tabular-nums text-cyan-300">
                {completionStats.pending} left
              </span>
            </div>

            {completionStats.pendingList.length > 0 ? (
              <div className="space-y-1.5">
                {completionStats.pendingList.map((task) => {
                  return (
                    <div
                      key={task.id}
                      className="flex items-center justify-between gap-2 rounded-xl bg-slate-950/60 border border-white/10 px-3 py-2 hover:border-cyan-400/40 transition-colors"
                    >
                      <div className="flex items-center gap-2.5 min-w-0 flex-1">
                        <button
                          onClick={() => onToggleComplete(task.id)}
                          aria-label={`Mark ${task.title} complete`}
                          className="min-w-[40px] min-h-[40px] -m-1.5 flex items-center justify-center rounded-xl text-cyan-400 hover:text-emerald-400 transition-colors shrink-0 cursor-pointer"
                        >
                          <Circle className="w-4 h-4" />
                        </button>
                        <span
                          onClick={() => onEditTask(task)}
                          className="text-xs font-medium text-slate-100 truncate cursor-pointer hover:text-cyan-300"
                        >
                          {task.title}
                        </span>
                      </div>
                      <span className="text-[11px] font-luxury-mono tabular-nums text-cyan-300/90 shrink-0">
                        {formatTime12h(task.startTime)}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="rounded-xl bg-emerald-500/15 border border-emerald-400/30 px-3 py-2.5 flex items-center justify-between">
                <span className="text-xs font-semibold text-emerald-300">
                  All scheduled tasks completed
                </span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </div>
            )}
          </div>
        </motion.div>

        {/* -------------------------------------------------------------------
            BENTO TILE 2: FREE TIME & OPEN WINDOWS (col-span-1 lg:col-span-4)
           ------------------------------------------------------------------- */}
        <motion.div
          variants={bentoTileVariants}
          whileHover={tileHoverMotion}
          whileTap={tileTapMotion}
          className="col-span-1 lg:col-span-4 glass-bento-tile border-emerald-500/20 rounded-[24px] p-4 sm:p-6 flex flex-col justify-between gap-3.5 relative overflow-hidden"
        >
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -left-10 -bottom-10 w-40 h-40 rounded-full bg-emerald-500/20 blur-2xl"
          />

          <div className="space-y-1">
            <div className="flex items-center justify-between gap-1.5 text-xs font-luxury-mono text-slate-400">
              <span className="text-emerald-400 font-semibold truncate">02. Free Time</span>
              <span className="tabular-nums text-emerald-300/90">
                {freeTimeStats.slotCount} slots
              </span>
            </div>

            <div className="pt-1">
              <div className="font-sans text-2xl sm:text-3xl font-extrabold text-white tabular-nums tracking-tight">
                {formatDuration(freeTimeStats.freeMinutes)}
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                <span className="text-emerald-400 font-luxury-mono tabular-nums font-bold">
                  {freeTimeStats.freePct}%
                </span>{' '}
                open capacity
              </p>
            </div>
          </div>

          {/* Next / Best Open Slot Highlight */}
          {freeTimeStats.bestSlot ? (
            <div className="rounded-2xl bg-emerald-500/10 border border-emerald-400/25 p-3 space-y-1">
              <div className="flex items-center justify-between text-[11px] sm:text-xs text-emerald-300 font-luxury-mono tabular-nums font-semibold">
                <span>Best Gap</span>
                <span>{formatDuration(freeTimeStats.bestSlot.durationMinutes)}</span>
              </div>
              <div className="text-xs sm:text-sm font-semibold text-white font-luxury-mono tabular-nums truncate">
                {formatTime12h(freeTimeStats.bestSlot.startTime)} –{' '}
                {formatTime12h(freeTimeStats.bestSlot.endTime)}
              </div>
            </div>
          ) : (
            <div className="rounded-2xl bg-slate-950/50 border border-white/8 p-3 text-xs text-slate-400">
              Schedule is 100% packed today.
            </div>
          )}

          {/* Quick Action Trigger Button */}
          <button
            onClick={() => {
              if (freeTimeStats.bestSlot) {
                onAssignFreeSlot(
                  freeTimeStats.bestSlot.startTime,
                  freeTimeStats.bestSlot.endTime
                );
              } else {
                onNavigateTab('remaining');
              }
            }}
            className="min-h-[44px] w-full rounded-xl bg-emerald-500/18 border border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/25 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4 text-emerald-300" />
            <span>Fill Free Slot</span>
          </button>
        </motion.div>

        {/* -------------------------------------------------------------------
            BENTO TILE 3: FOCUS HOURS & DEEP WORK (col-span-1 lg:col-span-3)
           ------------------------------------------------------------------- */}
        <motion.div
          variants={bentoTileVariants}
          whileHover={tileHoverMotion}
          whileTap={tileTapMotion}
          className="col-span-1 lg:col-span-3 glass-bento-tile border-violet-500/20 rounded-[24px] p-4 sm:p-6 flex flex-col justify-between gap-3.5 relative overflow-hidden"
        >
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -right-10 -bottom-10 w-40 h-40 rounded-full bg-violet-500/22 blur-2xl"
          />

          <div className="space-y-1">
            <div className="flex items-center justify-between gap-1.5 text-xs font-luxury-mono text-slate-400">
              <span className="text-violet-300 font-semibold truncate">
                03. Focus Hours
              </span>
              <span className="text-violet-300/80">Deep</span>
            </div>

            <div className="pt-1">
              <div className="flex items-baseline gap-1.5">
                <span className="font-sans text-2xl sm:text-3xl font-extrabold text-white tabular-nums tracking-tight">
                  {focusStats.totalFocusHours}h
                </span>
                <span className="text-xs text-violet-300 font-luxury-mono tabular-nums">
                  total
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 truncate">
                <span className="text-violet-300 font-luxury-mono tabular-nums font-semibold">
                  {focusStats.deepWorkHours}h
                </span>{' '}
                deep ·{' '}
                <span className="text-cyan-300 font-luxury-mono tabular-nums font-semibold">
                  {focusStats.collegeHours}h
                </span>{' '}
                {collegeConfig.commitmentType === 'job' ? 'work' : 'class'}
              </p>
            </div>
          </div>

          {/* Multi-Segment Focus Bar */}
          <div className="space-y-1.5">
            <div className="h-2.5 w-full rounded-full bg-slate-950/80 overflow-hidden flex border border-white/10">
              <div
                style={{ width: `${Math.max(12, focusStats.deepShare)}%` }}
                className="h-full bg-violet-400 transition-all duration-500"
                title="Deep Self-Upgrade"
              />
              <div
                style={{ width: `${focusStats.collegeShare}%` }}
                className="h-full bg-cyan-400 transition-all duration-500"
                title="College / Work Schedule"
              />
              <div
                style={{ width: `${focusStats.fitnessShare}%` }}
                className="h-full bg-emerald-400 transition-all duration-500"
                title="Fitness & Recovery"
              />
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-400 font-luxury-mono tabular-nums">
              <span className="text-violet-300 font-semibold">
                {focusStats.completedDeepHours}h done
              </span>
              <span>{focusStats.deepShare}% deep</span>
            </div>
          </div>

          <button
            onClick={onOpenFocusMode}
            className="min-h-[44px] w-full rounded-xl bg-violet-500/18 border border-violet-400/40 text-violet-200 hover:bg-violet-500/25 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
          >
            <Zap className="w-4 h-4 text-violet-300" />
            <span>Enter Focus</span>
          </button>
        </motion.div>

        {/* -------------------------------------------------------------------
            BENTO TILE 4: SLEEP SCORE & BIORHYTHM (col-span-2 sm:col-span-1 lg:col-span-5)
           ------------------------------------------------------------------- */}
        <motion.div
          variants={bentoTileVariants}
          whileHover={tileHoverMotion}
          whileTap={tileTapMotion}
          className="col-span-2 sm:col-span-1 lg:col-span-5 glass-bento-tile border-indigo-500/20 rounded-[24px] p-5 sm:p-6 flex flex-col justify-between gap-4 relative overflow-hidden"
        >
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -right-12 -bottom-12 w-44 h-44 rounded-full bg-indigo-500/20 blur-2xl"
          />

          <div className="flex items-start justify-between gap-2">
            <div>
              <span className="text-xs font-luxury-mono font-semibold text-indigo-300">
                04. Sleep Score &amp; Recovery
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="font-sans text-3xl font-extrabold text-white tabular-nums">
                  {sleepStats.score}
                </span>
                <span className="text-xs text-slate-400 font-luxury-mono tabular-nums">/ 100</span>
                <span aria-hidden="true" className="text-slate-500">
                  ·
                </span>
                <span className="text-xs font-semibold text-emerald-400">{sleepStats.tier}</span>
              </div>
            </div>

            <button
              onClick={onOpenSleepSettings}
              className="min-h-[36px] px-3 py-1 rounded-xl bg-indigo-500/15 border border-indigo-400/35 hover:border-indigo-400 text-xs font-semibold text-indigo-200 hover:text-white transition-colors cursor-pointer"
            >
              Configure
            </button>
          </div>

          {/* Sleep Window & Interactive Log Stepper */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-indigo-500/10 border border-indigo-400/25 p-3.5 flex flex-col justify-between">
              <span className="text-[11px] text-indigo-200/80">Sleep Window</span>
              <span className="text-xs sm:text-sm font-semibold text-white font-luxury-mono tabular-nums mt-1">
                {formatTime12h(sleepConfig.bedTime)} – {formatTime12h(sleepConfig.wakeTime)}
              </span>
              <span className="text-[11px] text-cyan-300 font-luxury-mono tabular-nums mt-1 font-medium">
                Bedtime in {formatDuration(sleepStats.minsUntilBed)}
              </span>
            </div>

            <div className="rounded-2xl bg-slate-950/60 border border-white/10 p-3.5 flex flex-col justify-between">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-300">Logged Rest</span>
                <span className="text-emerald-400 font-luxury-mono tabular-nums font-semibold">
                  Goal {sleepStats.targetHours}h
                </span>
              </div>

              <div className="flex items-center justify-between gap-1 mt-1.5">
                <button
                  onClick={() =>
                    onUpdateSleepLog(
                      selectedDate,
                      Math.max(0, Number((sleepStats.loggedHours - 0.5).toFixed(1)))
                    )
                  }
                  aria-label="Decrease sleep hours"
                  className="min-w-[38px] min-h-[38px] rounded-xl bg-white/5 border border-white/15 hover:border-cyan-400/50 flex items-center justify-center text-slate-200 active:scale-95 transition-all cursor-pointer"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="font-sans text-base font-bold text-white tabular-nums">
                  {sleepStats.loggedHours}h
                </span>
                <button
                  onClick={() =>
                    onUpdateSleepLog(
                      selectedDate,
                      Math.min(14, Number((sleepStats.loggedHours + 0.5).toFixed(1)))
                    )
                  }
                  aria-label="Increase sleep hours"
                  className="min-w-[38px] min-h-[38px] rounded-xl bg-cyan-500/15 border border-cyan-400/40 hover:border-cyan-400 flex items-center justify-center text-cyan-300 active:scale-95 transition-all cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </motion.div>

        {/* -------------------------------------------------------------------
            BENTO TILE 5: WEEKLY MOMENTUM & QUICK LAUNCH DOCK (col-span-2 sm:col-span-1 lg:col-span-7)
           ------------------------------------------------------------------- */}
        <motion.div
          variants={bentoTileVariants}
          whileHover={tileHoverMotion}
          whileTap={tileTapMotion}
          className="col-span-2 sm:col-span-1 lg:col-span-7 glass-bento-tile border-cyan-500/20 rounded-[24px] p-5 sm:p-6 flex flex-col justify-between gap-4 relative overflow-hidden"
        >
          <div
            aria-hidden="true"
            className="pointer-events-none absolute left-1/3 -top-16 w-48 h-48 rounded-full bg-emerald-500/18 blur-3xl"
          />

          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <span className="text-xs font-luxury-mono font-semibold text-emerald-400">
                05. Weekly Momentum &amp; Quick Actions
              </span>
              <h3 className="font-sans text-lg sm:text-xl font-bold tracking-tight text-white mt-0.5 tabular-nums">
                {weeklyPulse.weeklyRate}% Weekly Completion · {weeklyPulse.completedTasks}/
                {weeklyPulse.totalTasks} Tasks
              </h3>
            </div>

            <button
              onClick={() => onNavigateTab('analytics')}
              className="min-h-[36px] px-3 py-1 rounded-xl bg-emerald-500/12 border border-emerald-400/30 hover:border-emerald-400 text-xs font-semibold text-emerald-200 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
            >
              <span>Analytics</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
            {/* 7-Day Interactive Candle / Spark Bars (PointerEvent-driven for Desktop, Tablet & Mobile) */}
            <div
              className="md:col-span-6 rounded-2xl bg-slate-950/60 border border-cyan-500/20 p-3.5 select-none"
              onPointerUp={handleCandlePointerUpOrCancel}
              onPointerLeave={handleCandlePointerUpOrCancel}
              onPointerCancel={handleCandlePointerUpOrCancel}
            >
              <div className="flex items-center justify-between text-[11px] font-luxury-mono text-slate-400 mb-1.5">
                <span className="text-cyan-300 font-semibold">7-Day Interactive Candle Bars</span>
                <span>Tap or drag across candles</span>
              </div>
              <div className="grid grid-cols-7 gap-1.5 items-end h-28 pt-2">
                {weekDays.map((d) => {
                  const barHeight = d.total === 0 ? 16 : Math.max(22, d.pct);
                  const isPressed = pressedCandleDate === d.dateStr;
                  const isActiveCandle = d.isSelected || isPressed;
                  return (
                    <button
                      key={d.dateStr}
                      type="button"
                      onPointerDown={(e) => handleCandlePointerDown(d.dateStr, e)}
                      onPointerEnter={(e) => handleCandlePointerEnter(d.dateStr, e)}
                      onPointerUp={handleCandlePointerUpOrCancel}
                      onPointerCancel={handleCandlePointerUpOrCancel}
                      onKeyDown={(e) => handleCandleKeyDown(d.dateStr, e)}
                      style={{ touchAction: 'manipulation' }}
                      title={`${d.shortDay}: ${d.completed}/${d.total} completed (${d.pct}%)`}
                      className={`flex flex-col items-center gap-1 h-full justify-end group cursor-pointer rounded-xl p-1 transition-all select-none relative ${
                        isPressed
                          ? 'scale-95 bg-cyan-400/25 ring-1 ring-cyan-300 shadow-[0_0_18px_rgba(34,211,238,0.4)]'
                          : d.isSelected
                          ? 'bg-cyan-500/15 ring-1 ring-cyan-400/60 shadow-[0_0_12px_rgba(34,211,238,0.2)]'
                          : 'hover:bg-white/5'
                      }`}
                    >
                      <span
                        className={`text-[9px] font-luxury-mono tabular-nums transition-colors ${
                          isActiveCandle ? 'text-cyan-300 font-bold' : 'text-slate-400'
                        }`}
                      >
                        {d.total > 0 ? `${d.pct}%` : '—'}
                      </span>

                      {/* Glowing Candle Wick / Spark Flame Indicator */}
                      <span
                        aria-hidden="true"
                        className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${
                          isPressed
                            ? 'bg-amber-300 scale-125 shadow-[0_0_10px_#fcd34d]'
                            : d.isSelected
                            ? 'bg-cyan-300 shadow-[0_0_8px_#22d3ee]'
                            : d.pct === 100
                            ? 'bg-emerald-400/90 shadow-[0_0_6px_#34d399]'
                            : 'bg-slate-600/40 group-hover:bg-cyan-400/60'
                        }`}
                      />

                      <div className="w-full h-12 bg-slate-900/90 rounded-lg overflow-hidden flex items-end p-0.5 border border-white/10">
                        <div
                          style={{ height: `${barHeight}%` }}
                          className={`w-full rounded-md transition-all duration-300 ${
                            isPressed
                              ? 'bg-gradient-to-t from-cyan-300 via-sky-300 to-amber-300 shadow-[0_0_14px_rgba(34,211,238,0.85)]'
                              : d.isSelected
                              ? 'bg-gradient-to-t from-cyan-400 via-sky-400 to-violet-400 shadow-[0_0_10px_rgba(34,211,238,0.6)]'
                              : d.pct === 100
                              ? 'bg-emerald-400'
                              : d.pct > 0
                              ? 'bg-cyan-400/85'
                              : 'bg-slate-700/60'
                          }`}
                        />
                      </div>
                      <span
                        className={`text-[10px] font-luxury-mono tabular-nums ${
                          isActiveCandle
                            ? 'text-cyan-300 font-bold'
                            : 'text-slate-400 group-hover:text-white'
                        }`}
                      >
                        {d.shortDay.slice(0, 2)}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2x2 Tactile Quick Launch Grid (Colorful Aurora Accents across Mobile, Tablet & Laptop) */}
            <div className="md:col-span-6 grid grid-cols-2 gap-2.5">
              <button
                onClick={onOpenTimetableUpload}
                className="min-h-[54px] rounded-2xl bg-violet-500/12 border border-violet-400/30 hover:border-violet-400 hover:bg-violet-500/20 p-3 flex items-center gap-2.5 text-left transition-all active:scale-95 cursor-pointer"
              >
                <div className="w-8 h-8 rounded-xl bg-violet-500/20 flex items-center justify-center text-violet-300 shrink-0">
                  <FileUp className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-semibold text-white block truncate">
                    Scan Schedule
                  </span>
                  <span className="text-[11px] text-violet-200/80 block truncate">
                    Photo / PDF
                  </span>
                </div>
              </button>

              <button
                onClick={() => onNavigateTab('remaining')}
                className="min-h-[54px] rounded-2xl bg-emerald-500/12 border border-emerald-400/30 hover:border-emerald-400 hover:bg-emerald-500/20 p-3 flex items-center gap-2.5 text-left transition-all active:scale-95 cursor-pointer"
              >
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center text-emerald-300 shrink-0">
                  <Layers className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-semibold text-white block truncate">
                    Free Slots
                  </span>
                  <span className="text-[11px] text-emerald-300 font-luxury-mono tabular-nums block truncate">
                    {formatDuration(freeTimeStats.freeMinutes)} open
                  </span>
                </div>
              </button>

              <button
                onClick={() => onNavigateTab('college')}
                className="min-h-[54px] rounded-2xl bg-cyan-500/12 border border-cyan-400/30 hover:border-cyan-400 hover:bg-cyan-500/20 p-3 flex items-center gap-2.5 text-left transition-all active:scale-95 cursor-pointer"
              >
                <div className="w-8 h-8 rounded-xl bg-cyan-500/20 flex items-center justify-center text-cyan-300 shrink-0">
                  {collegeConfig.commitmentType === 'job' ? (
                    <Briefcase className="w-4 h-4" />
                  ) : (
                    <GraduationCap className="w-4 h-4" />
                  )}
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-semibold text-white block truncate">
                    {collegeConfig.commitmentType === 'job' ? 'Work Shift' : 'Timetable'}
                  </span>
                  <span className="text-[11px] text-cyan-200/80 font-luxury-mono tabular-nums block truncate">
                    {formatTime12h(collegeConfig.startTime)}
                  </span>
                </div>
              </button>

              <button
                onClick={() => onNavigateTab('schedule')}
                className="min-h-[54px] rounded-2xl bg-amber-500/12 border border-amber-400/30 hover:border-amber-400 hover:bg-amber-500/20 p-3 flex items-center gap-2.5 text-left transition-all active:scale-95 cursor-pointer"
              >
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-300 shrink-0">
                  <Calendar className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <span className="text-xs font-semibold text-white block truncate">
                    24h Planner
                  </span>
                  <span className="text-[11px] text-amber-200/80 block truncate">
                    Full timeline
                  </span>
                </div>
              </button>

              {onOpenExport && (
                <button
                  onClick={onOpenExport}
                  className="min-h-[54px] rounded-2xl bg-indigo-500/12 border border-indigo-400/30 hover:border-indigo-400 hover:bg-indigo-500/20 p-3 flex items-center gap-2.5 text-left transition-all active:scale-95 cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-300 shrink-0">
                    <Download className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-xs font-semibold text-white block truncate">
                      Export PDF
                    </span>
                    <span className="text-[11px] text-indigo-200/80 block truncate">
                      Save PDF &amp; File
                    </span>
                  </div>
                </button>
              )}

              {onTestAlarm && (
                <button
                  onClick={onTestAlarm}
                  className="min-h-[54px] rounded-2xl bg-rose-500/12 border border-rose-400/30 hover:border-rose-400 hover:bg-rose-500/20 p-3 flex items-center gap-2.5 text-left transition-all active:scale-95 cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-xl bg-rose-500/20 flex items-center justify-center text-rose-300 shrink-0">
                    <Bell className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-xs font-semibold text-white block truncate">
                      Test Alarm
                    </span>
                    <span className="text-[11px] text-rose-200/80 block truncate">
                      Best Tune Chime
                    </span>
                  </div>
                </button>
              )}

              {onOpenApkModal && (
                <button
                  onClick={onOpenApkModal}
                  className="col-span-2 min-h-[54px] rounded-2xl bg-gradient-to-r from-cyan-500/20 via-violet-500/20 to-emerald-500/20 border border-cyan-400/45 hover:border-cyan-300 p-3 flex items-center justify-between gap-2.5 text-left transition-all active:scale-95 cursor-pointer shadow-[0_0_16px_rgba(34,211,238,0.18)]"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-xl bg-cyan-500/25 flex items-center justify-center text-cyan-300 shrink-0">
                      <Smartphone className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-xs font-bold text-white block truncate">
                        Download / Install Android APK
                      </span>
                      <span className="text-[11px] text-cyan-200/90 block truncate">
                        Install RoutineHub App on Phone
                      </span>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-lg bg-cyan-400 text-slate-950 text-[10px] font-extrabold uppercase tracking-wider shrink-0">
                    Get APK
                  </span>
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
};

