import React, { useEffect, useState, useMemo } from 'react';
import confetti from 'canvas-confetti';
import {
  Minimize2,
  Maximize2,
  Clock,
  CheckCircle2,
  Circle,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  GraduationCap,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  CheckSquare,
  Square,
  Flame,
  Coffee,
  ArrowRight,
  ListFilter,
  BookOpen,
  Lightbulb,
  Tag,
} from 'lucide-react';
import { CollegeClassSlot, CollegeConfig, Task } from '../types/routine';
import { CATEGORIES } from '../utils/categories';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTime12h,
  timeToMinutes,
} from '../utils/dateUtils';
import { sounds } from '../utils/audio';

interface FocusModeProps {
  tasks: Task[];
  collegeConfig: CollegeConfig;
  onExit: () => void;
  onToggleComplete: (taskId: string) => void;
  onToggleSubtask: (taskId: string, subtaskId: string) => void;
  soundEnabled: boolean;
}

export const FocusMode: React.FC<FocusModeProps> = ({
  tasks,
  collegeConfig,
  onExit,
  onToggleComplete,
  onToggleSubtask,
  soundEnabled,
}) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isTimerPaused, setIsTimerPaused] = useState(false);
  const [selectedTaskIdOverride, setSelectedTaskIdOverride] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Keep live time updated every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Keyboard shortcut: Escape to exit
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onExit();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onExit]);

  const currentMinutes = currentTime.getHours() * 60 + currentTime.getMinutes();
  const currentSeconds = currentTime.getSeconds();
  const currentDayOfWeek = currentTime.getDay();

  const isCollegeDay =
    collegeConfig.enabled && collegeConfig.activeDays.includes(currentDayOfWeek);
  const collegeStartMin = timeToMinutes(collegeConfig.startTime);
  const collegeEndMin = timeToMinutes(collegeConfig.endTime);

  const isInCollegeHours =
    isCollegeDay && currentMinutes >= collegeStartMin && currentMinutes < collegeEndMin;

  // Active college slot if currently in college
  const currentCollegeSlot: CollegeClassSlot | undefined = useMemo(() => {
    if (!isInCollegeHours) return undefined;
    return collegeConfig.slots.find((slot) => {
      const s = timeToMinutes(slot.startTime);
      const e = timeToMinutes(slot.endTime);
      return currentMinutes >= s && currentMinutes < e;
    });
  }, [isInCollegeHours, collegeConfig.slots, currentMinutes]);

  // Find active task based on current time
  const autoActiveTask = useMemo(() => {
    return tasks.find((t) => {
      const start = timeToMinutes(t.startTime);
      const end = timeToMinutes(t.endTime);
      return currentMinutes >= start && currentMinutes < end;
    });
  }, [tasks, currentMinutes]);

  // If user selected an override task or use auto-detected
  const activeTask = useMemo(() => {
    if (selectedTaskIdOverride) {
      const found = tasks.find((t) => t.id === selectedTaskIdOverride);
      if (found) return found;
    }
    return autoActiveTask;
  }, [selectedTaskIdOverride, tasks, autoActiveTask]);

  // Upcoming tasks queue for today
  const upcomingTasks = useMemo(() => {
    return tasks
      .filter((t) => !t.completed && timeToMinutes(t.startTime) > currentMinutes)
      .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime));
  }, [tasks, currentMinutes]);

  const nextTask = upcomingTasks[0];

  // Remaining tasks statistics
  const remainingTasks = tasks.filter((t) => !t.completed);
  const remainingCount = remainingTasks.length;
  const remainingMinutes = remainingTasks.reduce(
    (sum, t) => sum + calculateDurationMinutes(t.startTime, t.endTime),
    0
  );

  // Time calculations for the active task
  let taskStartMin = 0;
  let taskEndMin = 0;
  let totalSessionSeconds = 0;
  let elapsedSeconds = 0;
  let remainingSeconds = 0;

  if (activeTask) {
    taskStartMin = timeToMinutes(activeTask.startTime);
    taskEndMin = timeToMinutes(activeTask.endTime);
    totalSessionSeconds = (taskEndMin - taskStartMin) * 60;
    elapsedSeconds = Math.max(
      0,
      (currentMinutes - taskStartMin) * 60 + currentSeconds
    );
    remainingSeconds = Math.max(0, totalSessionSeconds - elapsedSeconds);
  } else if (isInCollegeHours) {
    taskStartMin = currentCollegeSlot ? timeToMinutes(currentCollegeSlot.startTime) : collegeStartMin;
    taskEndMin = currentCollegeSlot ? timeToMinutes(currentCollegeSlot.endTime) : collegeEndMin;
    totalSessionSeconds = (taskEndMin - taskStartMin) * 60;
    elapsedSeconds = Math.max(
      0,
      (currentMinutes - taskStartMin) * 60 + currentSeconds
    );
    remainingSeconds = Math.max(0, totalSessionSeconds - elapsedSeconds);
  }

  const progressPercent =
    totalSessionSeconds > 0
      ? Math.min(100, Math.round((elapsedSeconds / totalSessionSeconds) * 100))
      : 0;

  const remHours = Math.floor(remainingSeconds / 3600);
  const remMinutes = Math.floor((remainingSeconds % 3600) / 60);
  const remSecs = remainingSeconds % 60;

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const handleCompleteActive = () => {
    if (activeTask) {
      onToggleComplete(activeTask.id);
      if (soundEnabled) {
        sounds.playComplete();
      }
      try {
        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.6 },
        });
      } catch {
        // ignore
      }
    }
  };

  const cat = activeTask ? CATEGORIES[activeTask.category] || CATEGORIES.study : null;
  const CatIcon = cat?.icon;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-slate-100 flex flex-col justify-between overflow-y-auto animate-fadeIn select-none">
      
      {/* Top Bar: Ambient header with Controls */}
      <header className="px-6 py-4 flex items-center justify-between border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
            <span className="text-xs font-bold uppercase tracking-widest text-slate-300">
              Focus Mode
            </span>
          </div>

          <span className="hidden sm:inline text-slate-600">|</span>

          {/* Current Live Time */}
          <span className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400 font-mono">
            <Clock className="w-3.5 h-3.5 text-indigo-400" />
            {currentTime.toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
              second: '2-digit',
              hour12: true,
            })}
          </span>
        </div>

        {/* Task Switcher dropdown / shortcuts */}
        <div className="flex items-center gap-2">
          {tasks.length > 0 && (
            <div className="hidden md:flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1 text-xs">
              <ListFilter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={selectedTaskIdOverride || ''}
                onChange={(e) => setSelectedTaskIdOverride(e.target.value || null)}
                className="bg-transparent text-slate-300 focus:outline-none cursor-pointer"
              >
                <option value="">Auto-Detect Current Task</option>
                {tasks.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.title} ({formatTime12h(t.startTime)} - {formatTime12h(t.endTime)})
                    {t.completed ? ' [Done]' : ''}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Fullscreen Button */}
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Exit Focus Mode Button */}
          <button
            onClick={onExit}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs font-semibold text-slate-200 hover:text-white transition-all shadow-sm"
          >
            <Minimize2 className="w-4 h-4 text-rose-400" />
            <span>Exit Focus (Esc)</span>
          </button>
        </div>
      </header>

      {/* Main Focus Stage */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 max-w-4xl mx-auto w-full">
        {/* CASE 1: Active Dynamic Task is running */}
        {activeTask ? (
          <div className="w-full space-y-6 text-center animate-fadeIn">
            {/* Category Pill & Priority */}
            <div className="flex flex-wrap items-center justify-center gap-2">
              {cat && CatIcon && (
                <span
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-semibold border ${cat.badgeBg} ${cat.badgeText} ${cat.badgeBorder} shadow-lg`}
                >
                  <CatIcon className="w-4 h-4" />
                  {cat.label}
                </span>
              )}

              <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium bg-slate-900 border border-slate-800 text-slate-300 font-mono">
                <Clock className="w-3.5 h-3.5 text-indigo-400" />
                {formatTime12h(activeTask.startTime)} – {formatTime12h(activeTask.endTime)} (
                {calculateDurationMinutes(activeTask.startTime, activeTask.endTime)}m)
              </span>

              {activeTask.completed && (
                <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  Completed
                </span>
              )}
            </div>

            {/* Task Main Title */}
            <div>
              <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight max-w-2xl mx-auto">
                {activeTask.title}
              </h1>
              {activeTask.topic && (
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-950/80 border border-indigo-500/40 text-indigo-200 text-xs font-semibold mt-2 shadow-sm">
                  <Tag className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Topic: {activeTask.topic}</span>
                </div>
              )}
            </div>

            {/* Big Countdown Timer */}
            <div className="py-2">
              <div className="font-mono text-5xl sm:text-7xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white via-indigo-200 to-blue-300 tracking-wider">
                {remHours > 0 && `${remHours.toString().padStart(2, '0')}:`}
                {remMinutes.toString().padStart(2, '0')}:
                {remSecs.toString().padStart(2, '0')}
              </div>
              <p className="text-xs text-slate-400 uppercase tracking-widest mt-1 font-medium">
                {remainingSeconds > 0 ? 'Remaining in this session' : 'Session complete!'}
              </p>
            </div>

            {/* Visual Session Progress Bar */}
            <div className="max-w-lg mx-auto w-full space-y-1.5">
              <div className="w-full bg-slate-900/90 h-3.5 rounded-full overflow-hidden p-0.5 border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-indigo-500 via-blue-500 to-cyan-400 rounded-full transition-all duration-1000 ease-linear shadow-sm"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                <span>{progressPercent}% elapsed</span>
                <span>{formatDuration(Math.ceil(remainingSeconds / 60))} left</span>
              </div>
            </div>

            {/* Task Notes / Directives */}
            {activeTask.notes && (
              <div className="max-w-xl mx-auto p-4 rounded-2xl bg-slate-900/70 border border-slate-800 text-sm text-slate-300 italic shadow-sm">
                "{activeTask.notes}"
              </div>
            )}

            {/* What I Learned Block in Focus Mode */}
            {activeTask.learned && (
              <div className="max-w-xl mx-auto p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 text-left space-y-1 shadow-sm">
                <div className="flex items-center gap-1.5 text-amber-300 font-bold text-xs uppercase tracking-wider">
                  <Lightbulb className="w-4 h-4 text-amber-400" />
                  What I Have Learned / Key Takeaways:
                </div>
                <p className="text-xs text-slate-200 leading-relaxed pl-5">
                  {activeTask.learned}
                </p>
              </div>
            )}

            {/* Interactive Checklist Subtasks */}
            {activeTask.subtasks && activeTask.subtasks.length > 0 && (
              <div className="max-w-md mx-auto text-left bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 space-y-2 shadow-lg">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>Action Checklist:</span>
                  <span className="font-mono text-indigo-400">
                    {activeTask.subtasks.filter((s) => s.completed).length}/
                    {activeTask.subtasks.length}
                  </span>
                </div>
                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {activeTask.subtasks.map((sub) => (
                    <button
                      key={sub.id}
                      onClick={() => onToggleSubtask(activeTask.id, sub.id)}
                      className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-slate-800/60 text-xs transition-colors text-left"
                    >
                      {sub.completed ? (
                        <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-500 shrink-0" />
                      )}
                      <span
                        className={`${
                          sub.completed ? 'line-through text-slate-500' : 'text-slate-200'
                        }`}
                      >
                        {sub.title}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Focus Action: Mark Completed */}
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={handleCompleteActive}
                className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-bold text-sm transition-all shadow-lg active:scale-95 ${
                  activeTask.completed
                    ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30 hover:scale-105'
                }`}
              >
                <CheckCircle2 className="w-5 h-5 text-emerald-300" />
                <span>
                  {activeTask.completed ? 'Mark as Incomplete' : 'Done! Check Off Task'}
                </span>
              </button>
            </div>
          </div>
        ) : isInCollegeHours ? (
          /* CASE 2: Currently in Fixed College Hours */
          <div className="w-full max-w-2xl space-y-6 text-center animate-fadeIn">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/30 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-sky-400" />
              Fixed College Schedule in Progress
            </div>

            <div className="w-16 h-16 rounded-3xl bg-sky-500/10 text-sky-400 flex items-center justify-center mx-auto border border-sky-500/20 shadow-xl">
              <GraduationCap className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                {currentCollegeSlot ? currentCollegeSlot.name : collegeConfig.collegeName}
              </h1>
              <p className="text-sm text-sky-300/80 flex items-center justify-center gap-2">
                <span>{collegeConfig.collegeName}</span>
                {currentCollegeSlot?.room && (
                  <>
                    <span>•</span>
                    <span>Room: {currentCollegeSlot.room}</span>
                  </>
                )}
                <span>•</span>
                <span className="font-mono text-white">
                  {formatTime12h(collegeConfig.startTime)} – {formatTime12h(collegeConfig.endTime)}
                </span>
              </p>
            </div>

            {/* Countdown to college day end */}
            <div className="py-2">
              <div className="font-mono text-5xl sm:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-sky-200 via-blue-300 to-cyan-200">
                {remHours > 0 && `${remHours.toString().padStart(2, '0')}:`}
                {remMinutes.toString().padStart(2, '0')}:
                {remSecs.toString().padStart(2, '0')}
              </div>
              <p className="text-xs text-sky-400 uppercase tracking-widest mt-1">
                Remaining until College Hours Conclude ({formatTime12h(collegeConfig.endTime)})
              </p>
            </div>

            {/* Next task after college */}
            {nextTask && (
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
                <span className="text-slate-400">Scheduled Immediately After College:</span>
                <span className="font-semibold text-indigo-300 flex items-center gap-1">
                  {nextTask.title} at {formatTime12h(nextTask.startTime)}
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            )}
          </div>
        ) : (
          /* CASE 3: Rest / Intermission / Free Interval */
          <div className="w-full max-w-lg space-y-6 text-center animate-fadeIn">
            <div className="w-16 h-16 rounded-3xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mx-auto border border-indigo-500/20">
              <Coffee className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                Rest & Refresh Interval
              </h1>
              <p className="text-sm text-slate-400">
                No scheduled routine task right now. Take a deep breath, hydrate, and prepare for your next session.
              </p>
            </div>

            {nextTask ? (
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-left">
                <div className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                  Up Next on Your Routine:
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-base font-bold text-white">{nextTask.title}</h4>
                    <span className="text-xs text-indigo-400 font-mono">
                      Starts at {formatTime12h(nextTask.startTime)} ({calculateDurationMinutes(nextTask.startTime, nextTask.endTime)}m)
                    </span>
                  </div>
                  <button
                    onClick={() => setSelectedTaskIdOverride(nextTask.id)}
                    className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md transition-colors"
                  >
                    Start Early
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-emerald-300">
                <Sparkles className="w-5 h-5 mx-auto mb-1 text-emerald-400" />
                You've cleared all scheduled tasks for today! Enjoy your evening.
              </div>
            )}
          </div>
        )}
      </main>

      {/* Bottom Bar: Distraction-free remaining tasks status */}
      <footer className="px-6 py-3.5 border-t border-slate-800/80 bg-slate-950/90 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <Flame className="w-4 h-4 text-amber-400" />
          <span>
            Today's Remaining Workload:{' '}
            <strong className="text-white font-mono">{remainingCount}</strong> task
            {remainingCount !== 1 ? 's' : ''} left (
            <strong className="text-indigo-300 font-mono">
              {formatDuration(remainingMinutes)}
            </strong>{' '}
            total)
          </span>
        </div>

        {nextTask && activeTask?.id !== nextTask.id && (
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="text-slate-500">Next:</span>
            <span className="font-semibold text-slate-200">{nextTask.title}</span>
            <span className="text-indigo-400 font-mono">
              ({formatTime12h(nextTask.startTime)})
            </span>
          </div>
        )}
      </footer>
    </div>
  );
};
