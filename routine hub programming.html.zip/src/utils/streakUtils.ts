import { Task } from '../types/routine';
import { getTodayDateString } from './dateUtils';

export type StreakTier = 'none' | 'spark' | 'ignited' | 'blazing' | 'unstoppable' | 'legendary';

export interface StreakMilestoneInfo {
  tier: StreakTier;
  label: string;
  minDays: number;
  colorClass: string;
  bgGradient: string;
  borderColor: string;
  flameColor: string;
}

export const STREAK_TIERS: Record<StreakTier, StreakMilestoneInfo> = {
  none: {
    tier: 'none',
    label: 'Not Started',
    minDays: 0,
    colorClass: 'text-slate-400',
    bgGradient: 'from-slate-900 to-slate-950',
    borderColor: 'border-slate-800',
    flameColor: 'text-slate-500',
  },
  spark: {
    tier: 'spark',
    label: 'Sparking',
    minDays: 1,
    colorClass: 'text-amber-300',
    bgGradient: 'from-amber-950/60 via-slate-900 to-amber-950/40',
    borderColor: 'border-amber-600/50',
    flameColor: 'text-amber-400 fill-amber-400/40',
  },
  ignited: {
    tier: 'ignited',
    label: 'Ignited',
    minDays: 3,
    colorClass: 'text-orange-400',
    bgGradient: 'from-orange-950/70 via-slate-900 to-amber-950/50',
    borderColor: 'border-orange-500/60',
    flameColor: 'text-orange-400 fill-orange-400',
  },
  blazing: {
    tier: 'blazing',
    label: 'Blazing',
    minDays: 7,
    colorClass: 'text-rose-400',
    bgGradient: 'from-rose-950/80 via-slate-900 to-orange-950/60',
    borderColor: 'border-rose-500/70',
    flameColor: 'text-rose-500 fill-rose-500',
  },
  unstoppable: {
    tier: 'unstoppable',
    label: 'Unstoppable',
    minDays: 14,
    colorClass: 'text-violet-300',
    bgGradient: 'from-violet-950/80 via-slate-900 to-fuchsia-950/60',
    borderColor: 'border-violet-500/80',
    flameColor: 'text-violet-400 fill-violet-400',
  },
  legendary: {
    tier: 'legendary',
    label: 'Legendary',
    minDays: 30,
    colorClass: 'text-amber-200',
    bgGradient: 'from-amber-950 via-yellow-950/70 to-slate-900',
    borderColor: 'border-yellow-400',
    flameColor: 'text-yellow-400 fill-yellow-400 animate-pulse',
  },
};

const MILESTONE_TARGETS = [3, 7, 14, 30, 50, 100];

export interface StreakCalculationResult {
  currentStreak: number;
  bestStreak: number;
  todayTasksCount: number;
  todayCompletedCount: number;
  todayCompletionRate: number;
  todayMetGoal: boolean;
  todayIsRestDay: boolean;
  tier: StreakTier;
  tierInfo: StreakMilestoneInfo;
  nextMilestone: number;
  daysToNextMilestone: number;
}

export interface DayStreakRecord {
  dateStr: string;
  dayName: string;
  dayNumber: number;
  isToday: boolean;
  totalTasks: number;
  completedTasks: number;
  rate: number;
  status: 'met' | 'missed' | 'frozen_rest' | 'in_progress';
}

const BEST_STREAK_STORAGE_KEY = 'consistency_streak_best_record_80';

export function loadBestStreak(): number {
  try {
    const saved = localStorage.getItem(BEST_STREAK_STORAGE_KEY);
    return saved ? Math.max(0, parseInt(saved, 10) || 0) : 0;
  } catch {
    return 0;
  }
}

export function saveBestStreak(streak: number): void {
  try {
    const currentBest = loadBestStreak();
    if (streak > currentBest) {
      localStorage.setItem(BEST_STREAK_STORAGE_KEY, String(streak));
    }
  } catch {
    // LocalStorage error
  }
}

export function calculate80PercentStreak(
  tasks: Task[],
  referenceDateStr?: string
): StreakCalculationResult {
  const todayStr = referenceDateStr || getTodayDateString();

  // Filter out college fixed tasks; only personal skill tasks count
  const skillTasks = tasks.filter(
    (t) => !t.isCollegeFixed && t.category !== 'college'
  );

  // Group tasks by date
  const tasksByDate = new Map<string, Task[]>();
  skillTasks.forEach((t) => {
    const list = tasksByDate.get(t.date) || [];
    list.push(t);
    tasksByDate.set(t.date, list);
  });

  // Calculate today's status
  const todayTasks = tasksByDate.get(todayStr) || [];
  const todayTotal = todayTasks.length;
  const todayCompleted = todayTasks.filter((t) => t.completed).length;
  const todayCompletionRate =
    todayTotal > 0 ? Math.round((todayCompleted / todayTotal) * 100) : 0;
  const todayMetGoal = todayTotal > 0 && todayCompletionRate >= 80;
  const todayIsRestDay = todayTotal === 0;

  // Backwards traversal to calculate streak
  const [y, m, d] = todayStr.split('-').map(Number);
  const baseDate = new Date(y, m - 1, d);

  let currentStreak = 0;
  let activeTraversalDate = new Date(baseDate);

  // Step 1: If today met the goal (>= 80%), today adds 1 to the streak
  if (todayMetGoal) {
    currentStreak += 1;
  }

  // Step 2: Step back day by day into history (up to 365 days max)
  for (let offset = 1; offset <= 365; offset++) {
    const prevDate = new Date(baseDate);
    prevDate.setDate(baseDate.getDate() - offset);

    const prevDateStr = `${prevDate.getFullYear()}-${String(
      prevDate.getMonth() + 1
    ).padStart(2, '0')}-${String(prevDate.getDate()).padStart(2, '0')}`;

    const dayTasks = tasksByDate.get(prevDateStr) || [];
    const total = dayTasks.length;

    // Rule: Rest day with zero scheduled tasks freezes streak (does NOT break it)
    if (total === 0) {
      continue;
    }

    const completed = dayTasks.filter((t) => t.completed).length;
    const rate = Math.round((completed / total) * 100);

    // Rule: Met 80% threshold
    if (rate >= 80) {
      currentStreak += 1;
    } else {
      // Failed to reach 80% on a scheduled day -> streak broken
      break;
    }
  }

  // Check and persist all-time best streak
  const savedBest = loadBestStreak();
  const bestStreak = Math.max(savedBest, currentStreak);
  if (currentStreak > savedBest) {
    saveBestStreak(currentStreak);
  }

  // Determine Tier
  let tier: StreakTier = 'none';
  if (currentStreak >= 30) tier = 'legendary';
  else if (currentStreak >= 14) tier = 'unstoppable';
  else if (currentStreak >= 7) tier = 'blazing';
  else if (currentStreak >= 3) tier = 'ignited';
  else if (currentStreak >= 1) tier = 'spark';

  // Find next milestone
  const nextMilestone =
    MILESTONE_TARGETS.find((m) => m > currentStreak) || currentStreak + 10;
  const daysToNextMilestone = Math.max(1, nextMilestone - currentStreak);

  return {
    currentStreak,
    bestStreak,
    todayTasksCount: todayTotal,
    todayCompletedCount: todayCompleted,
    todayCompletionRate,
    todayMetGoal,
    todayIsRestDay,
    tier,
    tierInfo: STREAK_TIERS[tier],
    nextMilestone,
    daysToNextMilestone,
  };
}

export function getRecentStreakHistory(
  tasks: Task[],
  daysCount = 7,
  referenceDateStr?: string
): DayStreakRecord[] {
  const todayStr = referenceDateStr || getTodayDateString();
  const [y, m, d] = todayStr.split('-').map(Number);
  const baseDate = new Date(y, m - 1, d);

  const skillTasks = tasks.filter(
    (t) => !t.isCollegeFixed && t.category !== 'college'
  );

  const tasksByDate = new Map<string, Task[]>();
  skillTasks.forEach((t) => {
    const list = tasksByDate.get(t.date) || [];
    list.push(t);
    tasksByDate.set(t.date, list);
  });

  const history: DayStreakRecord[] = [];
  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  for (let i = daysCount - 1; i >= 0; i--) {
    const curDate = new Date(baseDate);
    curDate.setDate(baseDate.getDate() - i);

    const dateStr = `${curDate.getFullYear()}-${String(
      curDate.getMonth() + 1
    ).padStart(2, '0')}-${String(curDate.getDate()).padStart(2, '0')}`;

    const dayTasks = tasksByDate.get(dateStr) || [];
    const totalTasks = dayTasks.length;
    const completedTasks = dayTasks.filter((t) => t.completed).length;
    const rate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

    let status: 'met' | 'missed' | 'frozen_rest' | 'in_progress' = 'met';

    if (dateStr === todayStr) {
      if (rate >= 80) {
        status = 'met';
      } else if (totalTasks === 0) {
        status = 'frozen_rest';
      } else {
        status = 'in_progress';
      }
    } else {
      if (totalTasks === 0) {
        status = 'frozen_rest';
      } else if (rate >= 80) {
        status = 'met';
      } else {
        status = 'missed';
      }
    }

    history.push({
      dateStr,
      dayName: daysOfWeek[curDate.getDay()],
      dayNumber: curDate.getDate(),
      isToday: dateStr === todayStr,
      totalTasks,
      completedTasks,
      rate,
      status,
    });
  }

  return history;
}
