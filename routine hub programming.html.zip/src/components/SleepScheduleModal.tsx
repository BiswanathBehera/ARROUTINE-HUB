import React, { useState } from 'react';
import {
  Moon,
  Sun,
  Clock,
  Sparkles,
  ShieldCheck,
  Bell,
  Volume2,
  X,
  Check,
  Bed,
  HeartHandshake,
  Coffee,
} from 'lucide-react';
import { SleepConfig } from '../types/routine';
import { calculateDurationMinutes, formatDuration, formatTime12h, timeToMinutes } from '../utils/dateUtils';
import { sounds } from '../utils/audio';

interface SleepScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SleepConfig;
  onSave: (config: SleepConfig) => void;
  soundEnabled: boolean;
}

export const SleepScheduleModal: React.FC<SleepScheduleModalProps> = ({
  isOpen,
  onClose,
  config,
  onSave,
  soundEnabled,
}) => {
  const [enabled, setEnabled] = useState(config.enabled ?? true);
  const [bedTime, setBedTime] = useState(config.bedTime || '22:30');
  const [wakeTime, setWakeTime] = useState(config.wakeTime || '05:30');
  const [targetHours, setTargetHours] = useState(config.targetHours || 7);
  const [windDownReminderMinutes, setWindDownReminderMinutes] = useState(
    config.windDownReminderMinutes || 30
  );
  const [windDownEnabled, setWindDownEnabled] = useState(config.windDownEnabled ?? true);

  if (!isOpen) return null;

  // Calculate duration
  const sleepDurationMinutes = calculateDurationMinutes(bedTime, wakeTime);
  const wakingDurationMinutes = Math.max(0, 1440 - sleepDurationMinutes);

  // Calculate wind-down reminder time (e.g. 22:30 - 30 min = 22:00)
  const bedMin = timeToMinutes(bedTime);
  let windDownMin = bedMin - windDownReminderMinutes;
  if (windDownMin < 0) windDownMin += 1440;
  const windDownHour = Math.floor(windDownMin / 60);
  const windDownM = windDownMin % 60;
  const windDownTimeStr = `${String(windDownHour).padStart(2, '0')}:${String(windDownM).padStart(2, '0')}`;

  const handleApplyPreset = (bed: string, wake: string, hours: number) => {
    setBedTime(bed);
    setWakeTime(wake);
    setTargetHours(hours);
  };

  const handleTestChime = () => {
    sounds.playSleepWindDown();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      enabled,
      bedTime,
      wakeTime,
      targetHours,
      windDownReminderMinutes,
      windDownEnabled,
    });
    if (soundEnabled) {
      sounds.playComplete();
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900 border border-indigo-500/30 rounded-2xl shadow-2xl p-5 sm:p-6 space-y-5 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30 shadow-inner">
              <Moon className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">
                  Restorative Sleep & Recovery Module
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Locked 7h
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Guaranteed nightly rejuvenation from 10:30 PM to 5:30 AM
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Enable / Disable Toggle */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <div>
                <div className="text-xs font-semibold text-white">
                  Active Sleep Schedule Protection
                </div>
                <div className="text-[11px] text-slate-400">
                  Visual timeline locking and daily 17h daylight capacity limit
                </div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => setEnabled(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          </div>

          {/* Quick Schedule Presets */}
          <div>
            <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Recommended Sleep Presets:
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleApplyPreset('22:30', '05:30', 7)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  bedTime === '22:30' && wakeTime === '05:30'
                    ? 'bg-indigo-950/80 border-indigo-500 text-white shadow-md shadow-indigo-900/30 ring-1 ring-indigo-400'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold text-indigo-300 flex items-center justify-between">
                  <span>10:30 PM – 5:30 AM</span>
                </div>
                <div className="text-[11px] font-semibold text-slate-300 mt-0.5">
                  7.0h (Recommended)
                </div>
                <div className="text-[10px] text-slate-500">Peak energy & focus</div>
              </button>

              <button
                type="button"
                onClick={() => handleApplyPreset('22:30', '06:00', 7.5)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  bedTime === '22:30' && wakeTime === '06:00'
                    ? 'bg-indigo-950/80 border-indigo-500 text-white shadow-md shadow-indigo-900/30 ring-1 ring-indigo-400'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold text-slate-300">
                  10:30 PM – 6:00 AM
                </div>
                <div className="text-[11px] font-semibold text-slate-300 mt-0.5">
                  7.5h Restorative
                </div>
                <div className="text-[10px] text-slate-500">Extended sleep</div>
              </button>

              <button
                type="button"
                onClick={() => handleApplyPreset('23:00', '07:00', 8)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  bedTime === '23:00' && wakeTime === '07:00'
                    ? 'bg-indigo-950/80 border-indigo-500 text-white shadow-md shadow-indigo-900/30 ring-1 ring-indigo-400'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="text-xs font-bold text-slate-300">
                  11:00 PM – 7:00 AM
                </div>
                <div className="text-[11px] font-semibold text-slate-300 mt-0.5">
                  8.0h Classic
                </div>
                <div className="text-[10px] text-slate-500">Full 8 hours cycle</div>
              </button>
            </div>
          </div>

          {/* Time Pickers */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Moon className="w-3.5 h-3.5 text-indigo-400" />
                Bed Time (Night)
              </label>
              <input
                type="time"
                value={bedTime}
                onChange={(e) => setBedTime(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm font-mono focus:outline-none focus:border-indigo-500"
              />
              <span className="text-[10px] text-slate-400 block">
                {formatTime12h(bedTime)} (Schedule sleep)
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                Wake Time (Morning)
              </label>
              <input
                type="time"
                value={wakeTime}
                onChange={(e) => setWakeTime(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm font-mono focus:outline-none focus:border-indigo-500"
              />
              <span className="text-[10px] text-slate-400 block">
                {formatTime12h(wakeTime)} (Waking hour)
              </span>
            </div>
          </div>

          {/* Real-Time Capacity Calculation Display */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-indigo-950/40 via-slate-950 to-slate-950 border border-indigo-500/30 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="text-indigo-300 flex items-center gap-1.5">
                <Bed className="w-4 h-4 text-indigo-400" />
                Nightly Rest Protected:
              </span>
              <span className="font-mono text-white text-sm font-bold">
                {formatDuration(sleepDurationMinutes)} ({((sleepDurationMinutes / 1440) * 100).toFixed(1)}% of 24h)
              </span>
            </div>

            <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden flex border border-slate-800">
              <div
                className="bg-indigo-500 h-full"
                style={{ width: `${(sleepDurationMinutes / 1440) * 100}%` }}
                title="Sleep Window"
              />
              <div
                className="bg-emerald-500 h-full"
                style={{ width: `${(wakingDurationMinutes / 1440) * 100}%` }}
                title="Waking Daylight"
              />
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-0.5">
              <span className="text-indigo-300 font-medium">
                🌙 {formatTime12h(bedTime)} to {formatTime12h(wakeTime)}
              </span>
              <span className="text-emerald-400 font-medium">
                ☀️ {formatDuration(wakingDurationMinutes)} active daylight remaining
              </span>
            </div>
          </div>

          {/* Bedtime Wind-Down Reminder Section */}
          <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-indigo-400" />
                <div>
                  <div className="text-xs font-semibold text-white">
                    Bedtime Wind-Down Chime & Alert
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Notifies at <strong className="text-indigo-300 font-mono">{formatTime12h(windDownTimeStr)}</strong> ({windDownReminderMinutes}m before sleep)
                  </div>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={windDownEnabled}
                  onChange={(e) => setWindDownEnabled(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
              </label>
            </div>

            {windDownEnabled && (
              <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400">Advance notice:</span>
                  <select
                    value={windDownReminderMinutes}
                    onChange={(e) => setWindDownReminderMinutes(Number(e.target.value))}
                    className="px-2 py-1 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs font-semibold focus:outline-none focus:border-indigo-500"
                  >
                    <option value={15}>15 minutes before (10:15 PM)</option>
                    <option value={30}>30 minutes before (10:00 PM)</option>
                    <option value={45}>45 minutes before (9:45 PM)</option>
                    <option value={60}>60 minutes before (9:30 PM)</option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handleTestChime}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-950/80 border border-indigo-500/40 hover:border-indigo-400 text-indigo-300 text-xs font-medium transition-colors"
                  title="Play relaxing nocturnal wind-down chime"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Test Chime</span>
                </button>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all hover:scale-[1.02]"
            >
              <Check className="w-4 h-4" />
              <span>Save Sleep Schedule</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
