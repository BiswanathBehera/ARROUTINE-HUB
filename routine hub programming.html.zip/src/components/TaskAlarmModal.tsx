import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  Bell,
  Clock,
  Target,
  X,
  Volume2,
  VolumeX,
  BookOpen,
  ArrowRight,
  Music,
} from 'lucide-react';
import { Task } from '../types/routine';
import { CATEGORIES } from '../utils/categories';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTime12h,
} from '../utils/dateUtils';
import { sounds, AlarmTuneId, ChimeVolumeLevel } from '../utils/audio';

interface TaskAlarmModalProps {
  task: Task | null;
  onDismiss: () => void;
  onOpenFocusMode: (task: Task) => void;
  onSnooze: (task: Task) => void;
}

const ALARM_TUNES: { id: AlarmTuneId; label: string }[] = [
  { id: 'aurora-melody', label: 'Zen Chime' },
  { id: 'royal-harp', label: 'Warm Harp' },
  { id: 'energetic-chime', label: 'Soft Bell' },
];

const VOLUME_LEVELS: { id: ChimeVolumeLevel; label: string }[] = [
  { id: 'soft', label: 'Soft' },
  { id: 'balanced', label: 'Mobile Balanced' },
  { id: 'clear', label: 'Clear' },
];

export const TaskAlarmModal: React.FC<TaskAlarmModalProps> = ({
  task,
  onDismiss,
  onOpenFocusMode,
  onSnooze,
}) => {
  const [selectedTune, setSelectedTune] = useState<AlarmTuneId>(() =>
    sounds.getAlarmTune()
  );
  const [volumeLevel, setVolumeLevel] = useState<ChimeVolumeLevel>(() =>
    sounds.getVolumeLevel()
  );

  useEffect(() => {
    if (task) {
      // Start gentle mobile-calibrated chime alert when modal opens
      sounds.startTaskAlarm(8, selectedTune);
    }
    return () => {
      sounds.stopAlarm();
    };
  }, [task]);

  if (!task) return null;

  const cat = CATEGORIES[task.category] || CATEGORIES.study;
  const CatIcon = cat.icon;
  const durationMin = calculateDurationMinutes(task.startTime, task.endTime);

  const handleSelectTune = (tuneId: AlarmTuneId) => {
    setSelectedTune(tuneId);
    sounds.setAlarmTune(tuneId);
    sounds.startTaskAlarm(6, tuneId);
  };

  const handleSelectVolume = (level: ChimeVolumeLevel) => {
    setVolumeLevel(level);
    sounds.setVolumeLevel(level);
    sounds.playAlarmPreview(selectedTune);
  };

  const handleDismiss = () => {
    sounds.stopAlarm();
    onDismiss();
  };

  const handleFocus = () => {
    sounds.stopAlarm();
    onOpenFocusMode(task);
  };

  const handleSnooze = () => {
    sounds.stopAlarm();
    onSnooze(task);
  };

  const [isMuted, setIsMuted] = useState(false);

  const handleToggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      sounds.startTaskAlarm(6, selectedTune);
    } else {
      sounds.stopAlarm();
      setIsMuted(true);
    }
  };

  const modalContent = (
    <div
      onClick={handleDismiss}
      className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn"
    >
      {/* Subtle ambient background glow */}
      <div className="absolute w-64 h-64 rounded-full bg-rose-500/15 blur-3xl animate-pulse pointer-events-none" />

      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-[90vw] sm:w-[400px] sm:max-w-[400px] max-h-[85dvh] overflow-y-auto box-border bg-slate-900/95 border border-rose-500/50 rounded-2xl p-4 sm:p-5 shadow-2xl shadow-rose-950/60 text-left space-y-3"
      >
        {/* Compact Header Row: Icon + Title + Mute/Close Controls */}
        <div className="flex items-start justify-between gap-2.5">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="relative shrink-0 w-10 h-10">
              <div className="absolute inset-0 rounded-xl bg-rose-500/30 animate-ping opacity-75" />
              <div className="relative w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-500 flex items-center justify-center text-white shadow-md shadow-rose-600/30">
                <Bell className="w-5 h-5 animate-bounce" />
              </div>
            </div>

            <div className="min-w-0">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/35">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping" />
                Task Alarm
              </span>
              <h2 className="text-sm sm:text-base font-extrabold text-white tracking-tight truncate mt-0.5">
                {task.title}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={handleToggleMute}
              title={isMuted ? 'Unmute Chime' : 'Mute Chime'}
              className={`px-2 py-1.5 rounded-lg border text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                isMuted
                  ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-200'
                  : 'bg-rose-500/20 border-rose-500/40 text-rose-200 hover:bg-rose-500/30'
              }`}
            >
              {isMuted ? (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Unmute</span>
                </>
              ) : (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-rose-400" />
                  <span>Mute</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleDismiss}
              aria-label="Close Alarm"
              className="p-1.5 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Task Details Strip */}
        <div className="p-2.5 rounded-xl bg-slate-950/85 border border-slate-800/90 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-1.5">
            <span
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold border ${cat.badgeBg} ${cat.badgeText} ${cat.badgeBorder}`}
            >
              <CatIcon className="w-3 h-3" />
              {cat.label}
            </span>

            <span className="text-[11px] font-mono text-slate-200 flex items-center gap-1 font-semibold">
              <Clock className="w-3 h-3 text-indigo-400 shrink-0" />
              {formatTime12h(task.startTime)} – {formatTime12h(task.endTime)} ({formatDuration(durationMin)})
            </span>
          </div>

          {task.topic && (
            <div className="text-[11px] bg-slate-900/90 px-2.5 py-1.5 rounded-lg border border-slate-800 text-slate-200 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <span className="text-slate-400 font-semibold shrink-0">Topic:</span>
              <span className="font-semibold text-white truncate">{task.topic}</span>
            </div>
          )}

          {task.notes && (
            <p className="text-[11px] text-slate-400 italic line-clamp-1">
              "{task.notes}"
            </p>
          )}
        </div>

        {/* Compact Chime Tune & Volume Selector */}
        <div className="p-2.5 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-[11px]">
            <span className="flex items-center gap-1 font-semibold text-amber-300">
              <Music className="w-3 h-3 text-amber-400" />
              Alarm Chime Tune
            </span>
            <button
              type="button"
              onClick={() => {
                setIsMuted(false);
                sounds.playAlarmPreview(selectedTune);
              }}
              className="inline-flex items-center gap-1 text-cyan-300 hover:text-cyan-200 font-semibold cursor-pointer"
            >
              <Volume2 className="w-3 h-3" />
              <span>Preview</span>
            </button>
          </div>

          <div className="grid grid-cols-3 gap-1.5">
            {ALARM_TUNES.map((tune) => {
              const isSelected = selectedTune === tune.id;
              return (
                <button
                  key={tune.id}
                  type="button"
                  onClick={() => {
                    setIsMuted(false);
                    handleSelectTune(tune.id);
                  }}
                  className={`px-2 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-gradient-to-r from-amber-500/30 to-rose-500/30 border border-amber-400/60 text-white'
                      : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {tune.label}
                </button>
              );
            })}
          </div>

          <div className="flex items-center justify-between pt-1.5 border-t border-slate-800/80 gap-1.5">
            <span className="text-[10px] font-semibold text-slate-400">
              Volume:
            </span>
            <div className="flex items-center gap-1">
              {VOLUME_LEVELS.map((vol) => {
                const active = volumeLevel === vol.id;
                return (
                  <button
                    key={vol.id}
                    type="button"
                    onClick={() => {
                      setIsMuted(false);
                      handleSelectVolume(vol.id);
                    }}
                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-colors cursor-pointer ${
                      active
                        ? 'bg-cyan-500/25 border border-cyan-400/60 text-cyan-200'
                        : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {vol.id === 'balanced' ? 'Balanced' : vol.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Compact Action Buttons */}
        <div className="space-y-1.5 pt-0.5">
          <button
            type="button"
            onClick={handleFocus}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-rose-600 via-indigo-600 to-blue-600 hover:from-rose-500 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-indigo-600/25 flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] cursor-pointer"
          >
            <Target className="w-3.5 h-3.5" />
            <span>Open in Focus Mode</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={handleSnooze}
              className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
            >
              Snooze 5m
            </button>

            <button
              type="button"
              onClick={handleDismiss}
              className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-semibold border border-slate-700 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <VolumeX className="w-3.5 h-3.5 text-rose-400" />
              <span>Dismiss</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined'
    ? createPortal(modalContent, document.body)
    : modalContent;
};
