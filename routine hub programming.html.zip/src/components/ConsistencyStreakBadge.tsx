import React, { useState, useEffect, useRef } from 'react';
import { Flame, Sparkles, Check, Clock, Snowflake } from 'lucide-react';
import { Task } from '../types/routine';
import {
  calculate80PercentStreak,
  getRecentStreakHistory,
  STREAK_TIERS,
} from '../utils/streakUtils';
import { ConsistencyStreakModal } from './ConsistencyStreakModal';
import { sounds } from '../utils/audio';

interface ConsistencyStreakBadgeProps {
  tasks: Task[];
  selectedDate: string;
  onSelectDate?: (dateStr: string) => void;
  soundEnabled?: boolean;
}

export const ConsistencyStreakBadge: React.FC<ConsistencyStreakBadgeProps> = ({
  tasks,
  selectedDate,
  onSelectDate,
  soundEnabled = true,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Compute live streak state
  const streakData = calculate80PercentStreak(tasks);
  const history = getRecentStreakHistory(tasks, 7);

  // Milestone celebration audio trigger
  const prevStreakRef = useRef(streakData.currentStreak);
  const prevMetGoalRef = useRef(streakData.todayMetGoal);

  useEffect(() => {
    // If user hits today's 80% goal or streak increments, play triumphant chime
    if (!prevMetGoalRef.current && streakData.todayMetGoal && soundEnabled) {
      sounds.playStreakMilestoneChime();
    } else if (
      streakData.currentStreak > prevStreakRef.current &&
      streakData.currentStreak >= 3 &&
      soundEnabled
    ) {
      sounds.playStreakMilestoneChime();
    }

    prevStreakRef.current = streakData.currentStreak;
    prevMetGoalRef.current = streakData.todayMetGoal;
  }, [streakData.currentStreak, streakData.todayMetGoal, soundEnabled]);

  const {
    currentStreak,
    todayMetGoal,
    todayIsRestDay,
    todayCompletionRate,
    tier,
    tierInfo,
  } = streakData;

  // Render animated flame according to tier
  const getFlameClass = () => {
    switch (tier) {
      case 'legendary':
        return 'w-4 h-4 text-yellow-300 fill-yellow-400 drop-shadow-[0_0_8px_rgba(250,204,21,0.8)] animate-pulse';
      case 'unstoppable':
        return 'w-4 h-4 text-violet-400 fill-violet-400 drop-shadow-[0_0_6px_rgba(168,85,247,0.7)] animate-bounce';
      case 'blazing':
        return 'w-4 h-4 text-rose-500 fill-rose-500 drop-shadow-[0_0_6px_rgba(244,63,94,0.6)] animate-pulse';
      case 'ignited':
        return 'w-4 h-4 text-orange-400 fill-orange-400';
      case 'spark':
        return 'w-4 h-4 text-amber-400 fill-amber-400/50';
      default:
        return 'w-4 h-4 text-slate-500';
    }
  };

  const getContainerStyles = () => {
    if (currentStreak === 0) {
      return 'bg-slate-800/80 hover:bg-slate-750 border-slate-700/80 text-slate-400 hover:text-slate-200';
    }

    switch (tier) {
      case 'legendary':
        return 'bg-gradient-to-r from-yellow-950/80 via-amber-950/70 to-slate-900 border-yellow-500/60 text-yellow-200 hover:border-yellow-400 shadow-sm shadow-yellow-500/20';
      case 'unstoppable':
        return 'bg-gradient-to-r from-violet-950/80 via-purple-950/70 to-slate-900 border-violet-500/60 text-violet-200 hover:border-violet-400 shadow-sm shadow-violet-500/20';
      case 'blazing':
        return 'bg-gradient-to-r from-rose-950/80 via-slate-900 to-orange-950/60 border-rose-500/60 text-rose-200 hover:border-rose-400 shadow-sm shadow-rose-500/20';
      case 'ignited':
        return 'bg-gradient-to-r from-orange-950/70 via-slate-900 to-amber-950/50 border-orange-500/50 text-orange-200 hover:border-orange-400';
      case 'spark':
      default:
        return 'bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-900 border-amber-500/40 text-amber-200 hover:border-amber-400';
    }
  };

  const [isPointerPressed, setIsPointerPressed] = useState(false);

  const handlePointerDown = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    setIsPointerPressed(true);
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      try {
        navigator.vibrate(8);
      } catch {
        // Ignore vibration errors
      }
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    if (isPointerPressed) {
      setIsPointerPressed(false);
      setIsModalOpen(true);
    }
  };

  const handlePointerCancelOrLeave = () => {
    setIsPointerPressed(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      setIsModalOpen(true);
    }
  };

  return (
    <>
      <button
        type="button"
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerCancelOrLeave}
        onPointerCancel={handlePointerCancelOrLeave}
        onKeyDown={handleKeyDown}
        style={{ touchAction: 'manipulation' }}
        className={`group relative flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all duration-200 shadow-sm cursor-pointer select-none ${
          isPointerPressed
            ? 'scale-95 ring-2 ring-amber-400/70 shadow-[0_0_18px_rgba(251,191,36,0.45)]'
            : 'hover:scale-[1.02]'
        } ${getContainerStyles()}`}
        title={`80% Consistency Streak: ${currentStreak} consecutive days. Click to view breakdown.`}
        aria-label="View Consistency Streak Details"
      >
        {/* Animated Flame Icon */}
        <div className="relative flex items-center justify-center shrink-0">
          <Flame className={`${getFlameClass()} ${isPointerPressed ? 'scale-115' : ''}`} />
          {tier === 'legendary' && (
            <Sparkles className="w-2.5 h-2.5 text-yellow-300 absolute -top-1 -right-1" />
          )}
        </div>

        {/* Counter and Label */}
        <div className="flex items-baseline gap-1">
          <span className="font-mono font-black text-sm text-white drop-shadow-sm tabular-nums">
            {currentStreak}
          </span>
          <span className="text-[11px] font-bold text-slate-300 hidden sm:inline">
            {currentStreak === 1 ? 'day' : 'days'}
          </span>
        </div>

        {/* Today Status Indicator Dot */}
        <div className="ml-0.5">
          {todayIsRestDay ? (
            <span
              className="w-2 h-2 rounded-full bg-sky-400 inline-block"
              title="Rest Day (Streak Frozen Safe)"
            />
          ) : todayMetGoal ? (
            <span
              className="w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-emerald-500/50 inline-block animate-pulse"
              title="Today: 80% Target Met! (+1 to Streak)"
            />
          ) : (
            <span
              className="w-2 h-2 rounded-full bg-amber-400 inline-block opacity-80"
              title={`Today in progress: ${todayCompletionRate}% (80% needed)`}
            />
          )}
        </div>
      </button>

      {/* Streak Inspection Modal */}
      <ConsistencyStreakModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        streakData={streakData}
        history={history}
        onSelectDate={onSelectDate}
      />
    </>
  );
};
