import React, { useState } from 'react';
import {
  Clock,
  Plus,
  Sparkles,
  Zap,
  Moon,
  GraduationCap,
  Briefcase,
  CheckCircle2,
  Circle,
  Edit3,
  Trash2,
  SlidersHorizontal,
  ArrowRight,
  Layers,
  Check,
  X,
  Calendar,
  Lock,
  User,
} from 'lucide-react';
import {
  CollegeConfig,
  Priority,
  SleepConfig,
  Task,
  TaskCategory,
} from '../types/routine';
import {
  calculateDurationMinutes,
  calculateFreeTimeSlots,
  formatDateLabel,
  formatDuration,
  formatTime12h,
  minutesToTime,
  timeToMinutes,
} from '../utils/dateUtils';

interface RemainingTimePlannerProps {
  tasks: Task[];
  collegeConfig: CollegeConfig;
  sleepConfig: SleepConfig;
  selectedDate: string;
  onSaveTask: (taskData: Omit<Task, 'id'>, existingId?: string) => void;
  onAssignFreeSlotModal: (startTime: string, endTime: string) => void;
  onEditTask: (task: Task) => void;
  onDeleteTask: (taskId: string) => void;
  onToggleComplete: (taskId: string) => void;
  onOpenCollegeTab: () => void;
  onOpenSleepModal: () => void;
  activeUser?: UserAccount | null;
  onOpenAuthModal?: (reason?: string) => void;
}

const CATEGORY_OPTIONS: { value: TaskCategory; label: string; badgeClass: string }[] = [
  { value: 'study', label: 'Study & Academics', badgeClass: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30' },
  { value: 'programming', label: 'Programming / DSA', badgeClass: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' },
  { value: 'trading', label: 'Trading & Markets', badgeClass: 'bg-amber-500/15 text-amber-300 border-amber-500/30' },
  { value: 'video_editing', label: 'Video Editing', badgeClass: 'bg-purple-500/15 text-purple-300 border-purple-500/30' },
  { value: 'exercise', label: 'Exercise & Fitness', badgeClass: 'bg-rose-500/15 text-rose-300 border-rose-500/30' },
  { value: 'personal', label: 'Personal Growth', badgeClass: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30' },
  { value: 'break', label: 'Rest / Refresh Break', badgeClass: 'bg-slate-500/15 text-slate-300 border-slate-500/30' },
];

const QUICK_PRESETS: { title: string; category: TaskCategory; topic: string; defaultMin: number }[] = [
  { title: 'DSA & LeetCode Practice', category: 'programming', topic: 'Problem Solving & Algorithms', defaultMin: 60 },
  { title: 'Core Subject Revision', category: 'study', topic: 'Lecture Notes & Exam Prep', defaultMin: 60 },
  { title: 'Price Action & Chart Analysis', category: 'trading', topic: 'Market Structure & Setups', defaultMin: 45 },
  { title: 'Video Timeline & Color Grading', category: 'video_editing', topic: 'Content Production', defaultMin: 60 },
  { title: 'Strength Training & Mobility', category: 'exercise', topic: 'Physical Conditioning', defaultMin: 45 },
  { title: 'Power Recharge Break', category: 'break', topic: 'Hydration & Walk', defaultMin: 30 },
];

const DURATION_PRESETS = [
  { label: '30m', minutes: 30 },
  { label: '45m', minutes: 45 },
  { label: '1h', minutes: 60 },
  { label: '1h 30m', minutes: 90 },
  { label: '2h', minutes: 120 },
];

export const RemainingTimePlanner: React.FC<RemainingTimePlannerProps> = ({
  tasks,
  collegeConfig,
  sleepConfig,
  selectedDate,
  onSaveTask,
  onAssignFreeSlotModal,
  onEditTask,
  onDeleteTask,
  onToggleComplete,
  onOpenCollegeTab,
  onOpenSleepModal,
  activeUser,
  onOpenAuthModal,
}) => {
  const occupancy = calculateFreeTimeSlots(tasks, collegeConfig, selectedDate, sleepConfig);
  const isJob = collegeConfig.commitmentType === 'job';

  const collegePct =
    occupancy.wakingMinutes > 0
      ? Math.round((occupancy.collegeMinutes / occupancy.wakingMinutes) * 100)
      : 0;

  const routinePct =
    occupancy.wakingMinutes > 0
      ? Math.round((occupancy.routineMinutes / occupancy.wakingMinutes) * 100)
      : 0;

  const freePct = Math.max(0, 100 - collegePct - routinePct);

  // Inline Quick Assign State
  const [activeSlotId, setActiveSlotId] = useState<string | null>(null);
  const [inlineTitle, setInlineTitle] = useState('');
  const [inlineTopic, setInlineTopic] = useState('');
  const [inlineCategory, setInlineCategory] = useState<TaskCategory>('study');
  const [inlinePriority, setInlinePriority] = useState<Priority>('high');
  const [inlineStart, setInlineStart] = useState('09:00');
  const [inlineEnd, setInlineEnd] = useState('10:00');
  const [selectedDurationMode, setSelectedDurationMode] = useState<number | 'full' | 'custom'>('full');

  const handleOpenInlineAssign = (slot: {
    id: string;
    startTime: string;
    endTime: string;
    durationMinutes: number;
  }) => {
    if (!activeUser && onOpenAuthModal) {
      onOpenAuthModal('Assign Task');
      return;
    }
    if (activeSlotId === slot.id) {
      setActiveSlotId(null);
      return;
    }
    setActiveSlotId(slot.id);
    setInlineTitle('');
    setInlineTopic('');
    setInlineCategory('study');
    setInlinePriority('high');
    setInlineStart(slot.startTime);
    // Default to 60m if slot is larger than 90m, otherwise full slot
    if (slot.durationMinutes > 90) {
      const startMin = timeToMinutes(slot.startTime);
      setInlineEnd(minutesToTime(startMin + 60));
      setSelectedDurationMode(60);
    } else {
      setInlineEnd(slot.endTime);
      setSelectedDurationMode('full');
    }
  };

  const handleSelectDurationPreset = (
    minutes: number | 'full',
    slotStart: string,
    slotEnd: string
  ) => {
    setSelectedDurationMode(minutes);
    if (minutes === 'full') {
      setInlineStart(slotStart);
      setInlineEnd(slotEnd);
    } else {
      const startMin = timeToMinutes(inlineStart || slotStart);
      const slotEndMin = timeToMinutes(slotEnd);
      const targetEndMin = Math.min(slotEndMin, startMin + minutes);
      setInlineEnd(minutesToTime(targetEndMin));
    }
  };

  const handleApplyQuickPreset = (
    preset: (typeof QUICK_PRESETS)[number],
    slotStart: string,
    slotEnd: string,
    slotDuration: number
  ) => {
    setInlineTitle(preset.title);
    setInlineCategory(preset.category);
    setInlineTopic(preset.topic);
    if (preset.defaultMin <= slotDuration) {
      const startMin = timeToMinutes(inlineStart || slotStart);
      const slotEndMin = timeToMinutes(slotEnd);
      const targetEndMin = Math.min(slotEndMin, startMin + preset.defaultMin);
      setInlineEnd(minutesToTime(targetEndMin));
      setSelectedDurationMode(preset.defaultMin);
    } else {
      setInlineStart(slotStart);
      setInlineEnd(slotEnd);
      setSelectedDurationMode('full');
    }
  };

  const handleCreateInlineTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeUser && onOpenAuthModal) {
      onOpenAuthModal('Assign Task');
      return;
    }
    if (!inlineTitle.trim()) return;

    const startMin = timeToMinutes(inlineStart);
    const endMin = timeToMinutes(inlineEnd);
    if (endMin <= startMin) return;

    onSaveTask({
      title: inlineTitle.trim(),
      topic: inlineTopic.trim() || undefined,
      category: inlineCategory,
      startTime: inlineStart,
      endTime: inlineEnd,
      priority: inlinePriority,
      completed: false,
      notes: `Assigned from open free slot (${formatTime12h(inlineStart)} – ${formatTime12h(inlineEnd)})`,
      subtasks: [],
      date: selectedDate,
    });

    setActiveSlotId(null);
    setInlineTitle('');
    setInlineTopic('');
  };

  const sortedTasks = [...tasks].sort((a, b) => a.startTime.localeCompare(b.startTime));

  const getCategoryMeta = (cat: TaskCategory) => {
    return (
      CATEGORY_OPTIONS.find((c) => c.value === cat) || {
        value: cat,
        label: cat,
        badgeClass: 'bg-slate-800 text-slate-300 border-slate-700',
      }
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Hero Card: Remaining Free Time & 24-Hour Day Capacity Split */}
      <div className="bg-slate-900/60 backdrop-blur-xl rounded-2xl border border-slate-800/80 p-4 sm:p-6 shadow-2xl space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">
                  Remaining Free Time & Slot Assignment
                </h2>
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2.5 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700 font-mono tabular-nums">
                  <Calendar className="w-3 h-3 text-emerald-400" />
                  {formatDateLabel(selectedDate)}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                See exact unscheduled time remaining after your fixed {isJob ? 'workplace hours' : 'college timetable'} and assigned routine tasks. Assign full or partial slots below.
              </p>
            </div>
          </div>

          {/* Primary Action + Hero Free Time Counter */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-3 bg-slate-950/90 border border-emerald-500/30 px-4 py-2.5 rounded-2xl">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                  Remaining Free Time Left
                </span>
                <div className="flex items-baseline gap-2">
                  <span className="text-xl font-black text-emerald-300 font-mono tabular-nums">
                    {formatDuration(occupancy.freeMinutes)}
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono tabular-nums">
                    ({occupancy.freeSlots.length} {occupancy.freeSlots.length === 1 ? 'window' : 'windows'})
                  </span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                if (!activeUser && onOpenAuthModal) {
                  onOpenAuthModal('Assign Task');
                  return;
                }
                const firstSlot = occupancy.freeSlots[0];
                if (firstSlot) {
                  onAssignFreeSlotModal(firstSlot.startTime, firstSlot.endTime);
                } else {
                  onAssignFreeSlotModal('18:00', '19:00');
                }
              }}
              className="flex items-center gap-1.5 px-4 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white text-xs font-bold shadow-lg shadow-emerald-600/25 transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Assign New Task</span>
            </button>

            {onOpenAuthModal && (
              <button
                type="button"
                onClick={() => onOpenAuthModal('Assign Task')}
                className={`flex items-center gap-1.5 px-3 py-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                  activeUser
                    ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-300 hover:bg-emerald-500/25'
                    : 'bg-amber-400/15 border-amber-400/45 text-amber-200 hover:bg-amber-400/25 shadow-sm'
                }`}
                title="Open Login / Account Interface"
              >
                <Lock className="w-3.5 h-3.5 text-amber-300" />
                <span>{activeUser ? `Synced: ${activeUser.name}` : 'Login to Assign'}</span>
              </button>
            )}
          </div>
        </div>

        {/* 4-Card KPI Breakdown */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Card 1: Free Time */}
          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-emerald-500/30 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold text-emerald-300">Unassigned Free Time</span>
              <span className="font-mono tabular-nums text-[11px] px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-300">
                {freePct}% of waking
              </span>
            </div>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-bold text-white font-mono tabular-nums">
                {formatDuration(occupancy.freeMinutes)}
              </span>
              <span className="text-[11px] text-slate-400 font-mono tabular-nums">
                {occupancy.freeSlots.length} open {occupancy.freeSlots.length === 1 ? 'gap' : 'gaps'}
              </span>
            </div>
          </div>

          {/* Card 2: Assigned Routine */}
          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold text-indigo-300">Assigned Routine Tasks</span>
              <span className="font-mono tabular-nums text-[11px] px-1.5 py-0.5 rounded bg-indigo-500/15 text-indigo-300">
                {routinePct}% of waking
              </span>
            </div>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-bold text-white font-mono tabular-nums">
                {formatDuration(occupancy.routineMinutes)}
              </span>
              <span className="text-[11px] text-slate-400 font-mono tabular-nums">
                {tasks.length} {tasks.length === 1 ? 'task' : 'tasks'} scheduled
              </span>
            </div>
          </div>

          {/* Card 3: Fixed College / Job */}
          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold text-sky-300">
                {isJob ? 'Fixed Work Shift' : 'Fixed College Hours'}
              </span>
              <button
                type="button"
                onClick={onOpenCollegeTab}
                className="text-[11px] text-sky-400 hover:text-sky-300 underline whitespace-nowrap shrink-0"
              >
                Edit Timetable
              </button>
            </div>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-bold text-white font-mono tabular-nums">
                {formatDuration(occupancy.collegeMinutes)}
              </span>
              <span className="text-[11px] text-slate-400 font-mono tabular-nums">
                {collegeConfig.enabled
                  ? `${formatTime12h(collegeConfig.startTime)} – ${formatTime12h(collegeConfig.endTime)}`
                  : 'Off Today'}
              </span>
            </div>
          </div>

          {/* Card 4: Sleep & Recovery */}
          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold text-purple-300">Protected Sleep Window</span>
              <button
                type="button"
                onClick={onOpenSleepModal}
                className="text-[11px] text-purple-400 hover:text-purple-300 underline whitespace-nowrap shrink-0"
              >
                Configure
              </button>
            </div>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="text-2xl font-bold text-white font-mono tabular-nums">
                {formatDuration(occupancy.sleepMinutes || 420)}
              </span>
              <span className="text-[11px] text-slate-400 font-mono tabular-nums">
                {formatTime12h(sleepConfig?.enabled ? sleepConfig.bedTime : '22:30')} –{' '}
                {formatTime12h(sleepConfig?.enabled ? sleepConfig.wakeTime : '05:30')}
              </span>
            </div>
          </div>
        </div>

        {/* Visual Multi-Segment Day Occupancy Gauge */}
        <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <span className="text-slate-300 font-semibold flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>
                24-Hour Waking Capacity Split ({formatTime12h(sleepConfig?.enabled ? sleepConfig.wakeTime : '05:30')} –{' '}
                {formatTime12h(sleepConfig?.enabled ? sleepConfig.bedTime : '22:30')})
              </span>
            </span>
            <span className="text-indigo-400 font-mono tabular-nums text-[11px] flex items-center gap-1">
              <Moon className="w-3 h-3" />
              {formatDuration(occupancy.sleepMinutes || 420)} Sleep Protected · {formatDuration(occupancy.wakingMinutes)} Total Waking Time
            </span>
          </div>

          {/* 3-Color Segmented Bar */}
          <div className="w-full bg-slate-900 h-4 rounded-full overflow-hidden p-0.5 border border-slate-800 flex shadow-inner">
            <div
              className="h-full bg-sky-500 first:rounded-l-full transition-all duration-500"
              style={{ width: `${collegePct}%` }}
              title={`Fixed ${isJob ? 'Work' : 'College'}: ${formatDuration(occupancy.collegeMinutes)} (${collegePct}%)`}
            />
            <div
              className="h-full bg-indigo-500 transition-all duration-500"
              style={{ width: `${routinePct}%` }}
              title={`Assigned Routine Tasks: ${formatDuration(occupancy.routineMinutes)} (${routinePct}%)`}
            />
            <div
              className="h-full bg-emerald-500 last:rounded-r-full transition-all duration-500"
              style={{ width: `${freePct}%` }}
              title={`Remaining Free Time Left: ${formatDuration(occupancy.freeMinutes)} (${freePct}%)`}
            />
          </div>

          {/* Legend */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs pt-1">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded bg-sky-500 shrink-0" />
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-slate-200">
                  {isJob ? 'Workplace Hours:' : 'College Classes:'}
                </span>
                <span className="text-slate-400 font-mono tabular-nums">
                  {formatDuration(occupancy.collegeMinutes)} ({collegePct}%)
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded bg-indigo-500 shrink-0" />
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-slate-200">Assigned Routine:</span>
                <span className="text-slate-400 font-mono tabular-nums">
                  {formatDuration(occupancy.routineMinutes)} ({routinePct}%)
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded bg-emerald-500 shrink-0" />
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-emerald-400">Remaining Free Time:</span>
                <span className="text-emerald-300 font-mono tabular-nums font-bold">
                  {formatDuration(occupancy.freeMinutes)} ({freePct}%)
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Two-Column Grid: Open Free Time Windows (Left/Main) & Assigned Tasks Manager (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Column 1: Available Free Time Windows (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/60 backdrop-blur-xl rounded-2xl border border-slate-800/80 p-4 sm:p-5 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Open Free Time Windows ({occupancy.freeSlots.length})</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Assign a task to the full gap or pick a custom partial duration so leftover time stays open.
              </p>
            </div>
            <span className="text-xs font-mono tabular-nums font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-lg self-start sm:self-auto whitespace-nowrap shrink-0">
              {formatDuration(occupancy.freeMinutes)} Total Open
            </span>
          </div>

          {occupancy.freeSlots.length === 0 ? (
            <div className="p-8 rounded-2xl bg-slate-950/70 border border-slate-800 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-white">
                  100% of Waking Time Assigned!
                </h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Every waking window between {formatTime12h(sleepConfig?.wakeTime || '05:30')} and{' '}
                  {formatTime12h(sleepConfig?.bedTime || '22:30')} is scheduled. Remove or shorten a task on the right to free up time.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {occupancy.freeSlots.map((slot) => {
                const isExpanded = activeSlotId === slot.id;
                const allocatedDuration = calculateDurationMinutes(inlineStart, inlineEnd);
                const leftoverMinutes = Math.max(0, slot.durationMinutes - allocatedDuration);

                return (
                  <div
                    key={slot.id}
                    className={`rounded-2xl border transition-all ${
                      isExpanded
                        ? 'bg-slate-950 border-emerald-500/60 shadow-lg shadow-emerald-950/30'
                        : 'bg-slate-950/70 hover:bg-slate-950 border-slate-800 hover:border-emerald-500/40'
                    }`}
                  >
                    {/* Slot Header Row */}
                    <div className="p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm font-bold text-white font-mono tabular-nums">
                            {formatTime12h(slot.startTime)} – {formatTime12h(slot.endTime)}
                          </span>
                          <span className="text-xs font-bold font-mono tabular-nums px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                            {formatDuration(slot.durationMinutes)} free
                          </span>
                          <span className="text-[11px] capitalize px-2 py-0.5 rounded-md bg-slate-900 text-slate-400 border border-slate-800">
                            {slot.period}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400">
                          Available for full {formatDuration(slot.durationMinutes)} block or partial slice
                        </p>
                      </div>

                      <div className="flex items-center gap-2 self-end sm:self-auto">
                        <button
                          type="button"
                          onClick={() => handleOpenInlineAssign(slot)}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all whitespace-nowrap shrink-0 ${
                            isExpanded
                              ? 'bg-slate-800 text-slate-200 border border-slate-700'
                              : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm shadow-emerald-600/20'
                          }`}
                        >
                          {isExpanded ? (
                            <>
                              <X className="w-3.5 h-3.5" />
                              <span>Close</span>
                            </>
                          ) : (
                            <>
                              <Plus className="w-3.5 h-3.5" />
                              <span>Quick Assign</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => onAssignFreeSlotModal(slot.startTime, slot.endTime)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 text-xs font-medium transition-colors whitespace-nowrap shrink-0"
                          title="Open full task modal with subtasks and notes"
                        >
                          <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-400" />
                          <span>Full Modal</span>
                        </button>
                      </div>
                    </div>

                    {/* Inline Task Creator (Partial or Full Slot) */}
                    {isExpanded && (
                      <form
                        onSubmit={handleCreateInlineTask}
                        className="px-4 pb-4 pt-3 border-t border-slate-800/90 space-y-3.5 animate-fadeIn"
                      >
                        {/* Quick Presets Row */}
                        <div>
                          <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                            1. Instant Routine Templates (Optional):
                          </label>
                          <div className="flex flex-wrap gap-1.5">
                            {QUICK_PRESETS.map((preset) => (
                              <button
                                key={preset.title}
                                type="button"
                                onClick={() =>
                                  handleApplyQuickPreset(
                                    preset,
                                    slot.startTime,
                                    slot.endTime,
                                    slot.durationMinutes
                                  )
                                }
                                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors border ${
                                  inlineTitle === preset.title
                                    ? 'bg-emerald-600/20 border-emerald-500 text-emerald-200'
                                    : 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-300'
                                }`}
                              >
                                {preset.title} ({preset.defaultMin}m)
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Partial Duration or Full Slot Selector */}
                        <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2.5">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                              2. Choose Slot Duration (Partial or Full):
                            </span>
                            <span className="text-[11px] font-mono tabular-nums text-slate-300">
                              Allocating{' '}
                              <strong className="text-emerald-300">
                                {formatDuration(Math.max(0, allocatedDuration))}
                              </strong>
                              {leftoverMinutes > 0 && (
                                <span className="text-slate-400">
                                  {' '}
                                  · {formatDuration(leftoverMinutes)} stays free
                                </span>
                              )}
                            </span>
                          </div>

                          {/* Duration Pills */}
                          <div className="flex flex-wrap items-center gap-1.5">
                            {DURATION_PRESETS.filter((d) => d.minutes < slot.durationMinutes).map(
                              (d) => (
                                <button
                                  key={d.label}
                                  type="button"
                                  onClick={() =>
                                    handleSelectDurationPreset(
                                      d.minutes,
                                      slot.startTime,
                                      slot.endTime
                                    )
                                  }
                                  className={`px-2.5 py-1 rounded-lg text-xs font-mono tabular-nums font-semibold transition-all ${
                                    selectedDurationMode === d.minutes
                                      ? 'bg-emerald-600 text-white shadow-sm'
                                      : 'bg-slate-950 text-slate-300 hover:text-white border border-slate-800'
                                  }`}
                                >
                                  {d.label}
                                </button>
                              )
                            )}
                            <button
                              type="button"
                              onClick={() =>
                                handleSelectDurationPreset('full', slot.startTime, slot.endTime)
                              }
                              className={`px-2.5 py-1 rounded-lg text-xs font-mono tabular-nums font-semibold transition-all ${
                                selectedDurationMode === 'full'
                                  ? 'bg-emerald-600 text-white shadow-sm'
                                  : 'bg-slate-950 text-slate-300 hover:text-white border border-slate-800'
                              }`}
                            >
                              Full Slot ({formatDuration(slot.durationMinutes)})
                            </button>
                          </div>

                          {/* Custom Start & End Time Inputs within Slot */}
                          <div className="grid grid-cols-2 gap-3 pt-1">
                            <div>
                              <label className="block text-[10px] text-slate-400 mb-1">
                                Start Time (within slot)
                              </label>
                              <input
                                type="time"
                                required
                                value={inlineStart}
                                min={slot.startTime}
                                max={slot.endTime}
                                onChange={(e) => {
                                  setInlineStart(e.target.value);
                                  setSelectedDurationMode('custom');
                                }}
                                className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs font-mono tabular-nums focus:outline-none focus:border-emerald-500"
                              />
                            </div>
                            <div>
                              <label className="block text-[10px] text-slate-400 mb-1">
                                End Time (within slot)
                              </label>
                              <input
                                type="time"
                                required
                                value={inlineEnd}
                                min={inlineStart}
                                max={slot.endTime}
                                onChange={(e) => {
                                  setInlineEnd(e.target.value);
                                  setSelectedDurationMode('custom');
                                }}
                                className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs font-mono tabular-nums focus:outline-none focus:border-emerald-500"
                              />
                            </div>
                          </div>
                        </div>

                        {/* Task Title, Category, Priority */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[11px] text-slate-400 mb-1">
                              Task Title *
                            </label>
                            <input
                              type="text"
                              required
                              value={inlineTitle}
                              onChange={(e) => setInlineTitle(e.target.value)}
                              placeholder="e.g. Solve 3 LeetCode Mediums"
                              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-emerald-500"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] text-slate-400 mb-1">
                              Specific Topic / Goal (Optional)
                            </label>
                            <input
                              type="text"
                              value={inlineTopic}
                              onChange={(e) => setInlineTopic(e.target.value)}
                              placeholder="e.g. Graphs, Trees, Backtesting"
                              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-emerald-500"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[11px] text-slate-400 mb-1">
                              Category
                            </label>
                            <select
                              value={inlineCategory}
                              onChange={(e) => setInlineCategory(e.target.value as TaskCategory)}
                              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-emerald-500"
                            >
                              {CATEGORY_OPTIONS.map((c) => (
                                <option key={c.value} value={c.value}>
                                  {c.label}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label className="block text-[11px] text-slate-400 mb-1">
                              Priority
                            </label>
                            <select
                              value={inlinePriority}
                              onChange={(e) => setInlinePriority(e.target.value as Priority)}
                              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-emerald-500"
                            >
                              <option value="high">High Priority</option>
                              <option value="medium">Medium Priority</option>
                              <option value="low">Low Priority</option>
                            </select>
                          </div>
                        </div>

                        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                          <button
                            type="button"
                            onClick={() => onAssignFreeSlotModal(inlineStart, inlineEnd)}
                            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1"
                          >
                            <span>Need subtasks or detailed notes? Open Full Modal</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>

                          <div className="flex items-center gap-2 ml-auto">
                            <button
                              type="button"
                              onClick={() => setActiveSlotId(null)}
                              className="px-3 py-1.5 rounded-xl text-xs text-slate-400 hover:text-white"
                            >
                              Cancel
                            </button>
                            <button
                              type="submit"
                              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-600/25 transition-all whitespace-nowrap shrink-0"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Assign Task ({formatDuration(Math.max(0, allocatedDuration))})</span>
                            </button>
                          </div>
                        </div>
                      </form>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Column 2: Assigned Routine Tasks for Selected Day (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/60 backdrop-blur-xl rounded-2xl border border-slate-800/80 p-4 sm:p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-400" />
                <span>Assigned Tasks ({sortedTasks.length})</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Edit times or remove tasks to immediately reclaim free time.
              </p>
            </div>
            <span className="text-xs font-mono tabular-nums font-semibold text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-1 rounded-lg whitespace-nowrap shrink-0">
              {formatDuration(occupancy.routineMinutes)} Assigned
            </span>
          </div>

          {sortedTasks.length === 0 ? (
            <div className="p-6 rounded-2xl bg-slate-950/70 border border-slate-800 text-center space-y-2">
              <p className="text-xs text-slate-400">
                No routine tasks assigned for this date yet. Select any open free window on the left to assign your first task.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[620px] overflow-y-auto pr-1">
              {sortedTasks.map((task) => {
                const dur = calculateDurationMinutes(task.startTime, task.endTime);
                const catMeta = getCategoryMeta(task.category);

                return (
                  <div
                    key={task.id}
                    className={`p-3 rounded-xl border transition-all flex items-start justify-between gap-3 ${
                      task.completed
                        ? 'bg-slate-950/40 border-slate-800/60 opacity-75'
                        : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start gap-2.5 min-w-0">
                      <button
                        type="button"
                        onClick={() => onToggleComplete(task.id)}
                        className="mt-0.5 text-slate-400 hover:text-emerald-400 transition-colors shrink-0"
                        title={task.completed ? 'Mark as incomplete' : 'Mark as completed'}
                      >
                        {task.completed ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <Circle className="w-4 h-4" />
                        )}
                      </button>

                      <div className="min-w-0 space-y-1">
                        <div
                          className={`text-xs font-bold truncate ${
                            task.completed ? 'line-through text-slate-400' : 'text-white'
                          }`}
                        >
                          {task.title}
                        </div>

                        <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                          <span className="font-mono tabular-nums text-indigo-300 font-semibold">
                            {formatTime12h(task.startTime)} – {formatTime12h(task.endTime)}
                          </span>
                          <span className="text-slate-600">•</span>
                          <span className="font-mono tabular-nums text-slate-400">
                            {formatDuration(dur)}
                          </span>
                          <span
                            className={`text-[10px] px-1.5 py-0.2 rounded border font-medium ${catMeta.badgeClass}`}
                          >
                            {catMeta.label}
                          </span>
                        </div>

                        {task.topic && (
                          <div className="text-[11px] text-slate-400 truncate">
                            Topic: <span className="text-slate-300">{task.topic}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => onEditTask(task)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-300 hover:bg-indigo-950/50 transition-colors"
                        title="Edit task or adjust time slot"
                        aria-label="Edit task"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteTask(task.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-950/50 transition-colors"
                        title="Remove task and return time to Free Slots"
                        aria-label="Remove task"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
