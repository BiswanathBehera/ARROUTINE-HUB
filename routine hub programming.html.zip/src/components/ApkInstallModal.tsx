import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import {
  Smartphone,
  Download,
  Check,
  Copy,
  X,
  ShieldCheck,
  Terminal,
  Package,
  Sparkles,
  CheckCircle2,
  Image as ImageIcon,
  FileArchive,
  ArrowLeft,
  ExternalLink,
} from 'lucide-react';
import { usePWAInstall, SHARED_APP_URL } from '../hooks/usePWAInstall';
import { sounds } from '../utils/audio';

interface ApkInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkInstallModal: React.FC<ApkInstallModalProps> = ({ isOpen, onClose }) => {
  const {
    isInstallable,
    isInstalled,
    isAndroid,
    isInIframe,
    swReady,
    manifestReady,
    promptInstall,
    downloadOfficialApkIcon,
    topLevelInstallUrl,
    refreshPwaStatus,
  } = usePWAInstall();

  const [activeTab, setActiveTab] = useState<'instant' | 'apk-builder' | 'cli'>('instant');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedCli, setCopiedCli] = useState(false);
  const [statusBanner, setStatusBanner] = useState<string | null>(null);
  const [downloadingItem, setDownloadingItem] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      refreshPwaStatus();
    }
  }, [isOpen, refreshPwaStatus]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setStatusBanner(msg);
    sounds.playComplete();
    setTimeout(() => {
      setStatusBanner(null);
    }, 5000);
  };

  // Universal Blob downloader that works inside AI Studio sandboxed iframes, Android WebViews & Desktop
  const downloadBlobFile = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      if (document.body.contains(link)) {
        document.body.removeChild(link);
      }
      URL.revokeObjectURL(url);
    }, 450);
  };

  // 1. Direct Download of User's Official "AR BISWANATH BEHERA" APK Icon (512x512 or 192x192 PNG)
  const handleDownloadApkIcon = async (size: '512' | '192' = '512') => {
    try {
      setDownloadingItem(`icon-${size}`);
      await downloadOfficialApkIcon(size);
      const filename = `AR-BISWANATH-BEHERA-APK-Icon-${size}x${size}.png`;
      showToast(`Downloaded ${filename}`);
    } finally {
      setDownloadingItem(null);
    }
  };

  // 2. Direct Download of Pre-Packaged Android APK Project Bundle (.ZIP with Icon + TWA + Scripts)
  const handleDownloadApkPackageZip = async () => {
    try {
      setDownloadingItem('apk-zip');
      const response = await fetch('/RoutineHub-Android-APK-Package.zip', { cache: 'no-cache' });
      if (!response.ok) throw new Error('Fallback to API');
      const blob = await response.blob();
      const filename = 'RoutineHub-AR-BISWANATH-BEHERA-Android-APK-Package.zip';
      downloadBlobFile(blob, filename);
      showToast(`Downloaded ${filename}`);
    } catch {
      const link = document.createElement('a');
      link.href = '/api/download-apk-package';
      link.download = 'RoutineHub-AR-BISWANATH-BEHERA-Android-APK-Package.zip';
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) document.body.removeChild(link);
      }, 450);
      showToast('Downloading RoutineHub-AR-BISWANATH-BEHERA-Android-APK-Package.zip...');
    } finally {
      setDownloadingItem(null);
    }
  };

  // 3. Direct Download of Standalone Installable Mobile App Launcher (.HTML with Embedded AR Icon)
  const handleDownloadStandaloneApp = async () => {
    try {
      setDownloadingItem('standalone-app');
      const response = await fetch('/RoutineHub-AR-BISWANATH-BEHERA-MobileApp.html', {
        cache: 'no-cache',
      });
      if (response.ok) {
        const blob = await response.blob();
        const filename = 'RoutineHub-AR-BISWANATH-BEHERA-MobileApp.html';
        downloadBlobFile(blob, filename);
        showToast(`Downloaded ${filename} — Open on your phone or PC!`);
        return;
      }
      throw new Error('Fallback to API endpoint');
    } catch {
      const link = document.createElement('a');
      link.href = '/api/download-mobile-launcher';
      link.download = 'RoutineHub-AR-BISWANATH-BEHERA-MobileApp.html';
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) document.body.removeChild(link);
      }, 450);
      showToast('Downloaded RoutineHub-AR-BISWANATH-BEHERA-MobileApp.html');
    } finally {
      setDownloadingItem(null);
    }
  };

  // 4. Combined One-Tap Native PWA Install Prompt + Official AR BISWANATH BEHERA Icon Download
  const handleSmartInstallOrDownload = async () => {
    setDownloadingItem('smart-install');
    try {
      // Step A: Always download the official 512x512 AR BISWANATH BEHERA APK Icon first
      await downloadOfficialApkIcon('512');

      // Step B: Trigger native browser PWA installation dialog if available in current window
      if (isInstallable) {
        const accepted = await promptInstall();
        if (accepted) {
          showToast(
            'RoutineHub — AR BISWANATH BEHERA installed & 512×512 APK Icon downloaded!'
          );
        } else {
          showToast(
            'Downloaded AR-BISWANATH-BEHERA-APK-Icon-512x512.png! Tap Install App anytime.'
          );
        }
        return;
      }

      // Step C: On Android devices, launch directly in Android Chrome so Android compiles the WebAPK
      if (isAndroid) {
        const hostAndPath = SHARED_APP_URL.replace(/^https?:\/\//, '');
        const chromeIntentUrl = `intent://${hostAndPath}/?install=1#Intent;scheme=https;package=com.android.chrome;S.browser_fallback_url=${encodeURIComponent(
          `${SHARED_APP_URL}/?install=1`
        )};end`;
        window.location.href = chromeIntentUrl;
        showToast(
          'Downloaded AR Icon & opening Android Chrome to install RoutineHub APK...'
        );
        return;
      }

      // Step D: Inside preview iframe or desktop where beforeinstallprompt was restricted by iframe:
      // Also download the Standalone Mobile App Launcher so both Icon + App download together!
      await handleDownloadStandaloneApp();
      showToast(
        'Downloaded AR BISWANATH BEHERA Icon (512px) + Mobile App! Use "Open Top-Level Native Prompt" below for Chrome PWA dialog.'
      );
    } finally {
      setDownloadingItem(null);
    }
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(`${SHARED_APP_URL}/?install=1`);
      setCopiedUrl(true);
      showToast('Live Install URL copied! Open in Android Chrome or Edge/Chrome tab to install.');
      setTimeout(() => setCopiedUrl(false), 2500);
    } catch {
      const input = document.createElement('input');
      input.value = `${SHARED_APP_URL}/?install=1`;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      setCopiedUrl(true);
      showToast('Live Install URL copied! Open in Android Chrome or Edge/Chrome tab to install.');
      setTimeout(() => setCopiedUrl(false), 2500);
    }
  };

  const bubblewrapCommands = `# 1. Install Google Bubblewrap Android APK Packager
npm i -g @bubblewrap/cli

# 2. Initialize Android APK project with AR BISWANATH BEHERA Icon
bubblewrap init --manifest="${SHARED_APP_URL}/manifest.webmanifest"

# 3. Build signed Android .APK (app-release-signed.apk)
bubblewrap build`;

  const handleCopyCli = async () => {
    try {
      await navigator.clipboard.writeText(bubblewrapCommands);
      setCopiedCli(true);
      showToast('Bubblewrap APK build commands copied!');
      setTimeout(() => setCopiedCli(false), 2500);
    } catch {
      // Fallback
    }
  };

  const handleDownloadTwaManifest = () => {
    const twaManifest = {
      packageId: 'com.biswanath.routinehub',
      host: new URL(SHARED_APP_URL).host,
      name: 'RoutineHub — AR BISWANATH BEHERA',
      launcherName: 'RoutineHub',
      display: 'standalone',
      themeColor: '#0F172A',
      navigationColor: '#0F172A',
      navigationColorDark: '#0F172A',
      navigationDividerColor: '#0F172A',
      navigationDividerColorDark: '#0F172A',
      backgroundColor: '#0F172A',
      enableNotifications: true,
      startUrl: '/',
      iconUrl: `${SHARED_APP_URL}/pwa-512x512.png`,
      maskableIconUrl: `${SHARED_APP_URL}/pwa-maskable-512x512.png`,
      appVersionName: '1.0.0',
      appVersionCode: 1,
      shortcuts: [],
      generatorApp: 'bubblewrap-cli',
      webManifestUrl: `${SHARED_APP_URL}/manifest.webmanifest`,
      fallbackType: 'customtabs',
      minSdkVersion: 21,
      orientation: 'portrait',
    };

    const blob = new Blob([JSON.stringify(twaManifest, null, 2)], {
      type: 'application/json',
    });
    downloadBlobFile(blob, 'twa-manifest-routinehub.json');
    showToast('Downloaded twa-manifest-routinehub.json');
  };

  const handleDownloadCapacitorConfig = () => {
    const capConfig = {
      appId: 'com.biswanath.routinehub',
      appName: 'RoutineHub - AR BISWANATH BEHERA',
      webDir: 'dist',
      server: {
        url: SHARED_APP_URL,
        androidScheme: 'https',
      },
      plugins: {
        LocalNotifications: {
          smallIcon: 'ic_stat_icon_config_sample',
          iconColor: '#D4AF77',
        },
      },
    };

    const blob = new Blob([JSON.stringify(capConfig, null, 2)], {
      type: 'application/json',
    });
    downloadBlobFile(blob, 'capacitor.config.json');
    showToast('Downloaded capacitor.config.json');
  };

  const modalUI = (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-2xl rounded-[28px] bg-[#0F172A] border border-[#D4AF77]/40 shadow-[0_0_60px_rgba(212,175,119,0.2)] overflow-hidden max-h-[92vh] flex flex-col">
        {/* Top Header */}
        <div className="relative px-5 sm:px-6 py-4 sm:py-5 border-b border-white/10 bg-gradient-to-r from-[#D4AF77]/15 via-cyan-500/15 to-emerald-500/10 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src="/pwa-192x192.png"
              alt="AR BISWANATH BEHERA Icon"
              className="w-12 h-12 rounded-2xl border-2 border-[#D4AF77] shadow-[0_0_18px_rgba(212,175,119,0.4)] object-cover shrink-0"
            />
            <div>
              <div className="flex flex-wrap items-center gap-1.5">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  APK &amp; App Icon Installer
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-emerald-500/20 border border-emerald-400/40 text-emerald-300">
                  {swReady ? 'SW Active' : 'SW Ready'}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-cyan-500/20 border border-cyan-400/40 text-cyan-200">
                  {manifestReady ? 'Manifest Verified' : 'Manifest Active'}
                </span>
              </div>
              <p className="text-xs font-mono font-semibold tracking-wider text-[#D4AF77] mt-0.5">
                RoutineHub · AR BISWANATH BEHERA
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-slate-200 hover:text-white flex items-center gap-1.5 text-xs font-semibold transition-colors cursor-pointer shrink-0"
            aria-label="Close APK modal"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>
        </div>

        {/* Status Toast Banner */}
        {statusBanner && (
          <div className="px-5 py-2.5 bg-emerald-500/20 border-b border-emerald-400/40 text-emerald-200 text-xs font-semibold flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{statusBanner}</span>
            </div>
            <button
              onClick={() => setStatusBanner(null)}
              className="text-emerald-300 hover:text-white text-xs cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Mode Switcher Tabs */}
        <div className="px-5 sm:px-6 pt-3 pb-2 border-b border-white/10 bg-slate-900/60 flex items-center gap-1.5 overflow-x-auto">
          <button
            onClick={() => setActiveTab('instant')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'instant'
                ? 'bg-gradient-to-r from-[#D4AF77]/25 to-cyan-500/25 border border-[#D4AF77]/60 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 border border-transparent'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-[#D4AF77]" />
            <span>1. Install PWA &amp; Download Icon</span>
          </button>

          <button
            onClick={() => setActiveTab('apk-builder')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'apk-builder'
                ? 'bg-gradient-to-r from-[#D4AF77]/25 to-cyan-500/25 border border-[#D4AF77]/60 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 border border-transparent'
            }`}
          >
            <Package className="w-3.5 h-3.5 text-emerald-300" />
            <span>2. Android APK Package (.ZIP)</span>
          </button>

          <button
            onClick={() => setActiveTab('cli')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'cli'
                ? 'bg-gradient-to-r from-[#D4AF77]/25 to-cyan-500/25 border border-[#D4AF77]/60 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200 border border-transparent'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-violet-300" />
            <span>3. Build Signed .APK</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 text-sm">
          {activeTab === 'instant' && (
            <div className="space-y-4">
              {/* Official AR BISWANATH BEHERA Play Store Icon Showcase + Direct Icon Download */}
              <div className="rounded-2xl bg-slate-900/95 border border-[#D4AF77]/35 p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <img
                    src="/pwa-512x512.png"
                    alt="AR BISWANATH BEHERA Play Store APK Icon"
                    className="w-20 h-20 rounded-2xl border-2 border-[#D4AF77] shadow-[0_0_25px_rgba(212,175,119,0.35)] object-cover shrink-0"
                  />
                  <div>
                    <span className="px-2 py-0.5 rounded-md bg-[#D4AF77]/20 border border-[#D4AF77]/40 text-[#D4AF77] text-[10px] font-mono font-bold uppercase tracking-wider">
                      Official Play Store &amp; APK Icon
                    </span>
                    <h3 className="text-base font-bold text-white mt-1">
                      AR BISWANATH BEHERA
                    </h3>
                    <p className="text-xs text-slate-300 mt-0.5">
                      512×512 HD PNG &amp; 192×192 Android Home Screen Icon active in Service Worker &amp; Manifest
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap sm:flex-col gap-2 w-full sm:w-auto shrink-0">
                  <button
                    onClick={() => handleDownloadApkIcon('512')}
                    disabled={downloadingItem === 'icon-512'}
                    className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#D4AF77] via-amber-400 to-yellow-500 text-slate-950 font-extrabold text-xs flex items-center justify-center gap-2 shadow-[0_0_18px_rgba(212,175,119,0.4)] hover:brightness-110 transition-all cursor-pointer"
                  >
                    <ImageIcon className="w-4 h-4 stroke-[2.5]" />
                    <span>
                      {downloadingItem === 'icon-512'
                        ? 'Downloading Icon...'
                        : 'Download APK Icon (512px)'}
                    </span>
                  </button>

                  <button
                    onClick={() => handleDownloadApkIcon('192')}
                    disabled={downloadingItem === 'icon-192'}
                    className="flex-1 sm:flex-initial px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-[#D4AF77]" />
                    <span>Download 192×192 Icon</span>
                  </button>
                </div>
              </div>

              {/* Direct 1-Click Combined Native PWA Prompt + Icon/APK Download Card */}
              <div className="rounded-2xl bg-gradient-to-br from-cyan-500/15 via-slate-900 to-emerald-500/10 border border-cyan-400/35 p-4 space-y-3.5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-cyan-200 font-bold text-xs uppercase tracking-wider">
                    <Sparkles className="w-4 h-4 text-cyan-300" />
                    <span>One-Tap PWA Install Prompt + APK Icon Download</span>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-300 bg-emerald-500/15 border border-emerald-400/30 px-2 py-0.5 rounded-md">
                    com.biswanath.routinehub
                  </span>
                </div>

                <p className="text-xs text-slate-200 leading-relaxed">
                  Tap <strong className="text-white">Install App &amp; Download Icon</strong> below to trigger the browser&apos;s native PWA installation dialog and automatically save your <strong className="text-[#D4AF77]">AR BISWANATH BEHERA</strong> APK icon:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {/* Button 1: Combined Native Install + Official Icon Download */}
                  {isInstalled ? (
                    <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 text-xs font-bold flex items-center justify-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>App Installed</span>
                    </div>
                  ) : (
                    <button
                      onClick={handleSmartInstallOrDownload}
                      disabled={downloadingItem === 'smart-install'}
                      className="p-3 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-500 to-indigo-600 text-slate-950 font-extrabold text-xs flex flex-col items-center justify-center gap-1 shadow-[0_0_20px_rgba(34,211,238,0.35)] hover:brightness-110 transition-all cursor-pointer text-center"
                    >
                      <div className="flex items-center gap-1.5">
                        <Smartphone className="w-4 h-4 stroke-[2.5]" />
                        <span>
                          {downloadingItem === 'smart-install'
                            ? 'Installing & Saving...'
                            : 'Install App & Icon'}
                        </span>
                      </div>
                      <span className="text-[10px] font-semibold text-slate-900/80">
                        {isInstallable
                          ? 'Triggers Native PWA Dialog + Icon'
                          : 'Saves AR Icon + Mobile App'}
                      </span>
                    </button>
                  )}

                  {/* Button 2: Direct Download Android APK Package (.ZIP) */}
                  <button
                    onClick={handleDownloadApkPackageZip}
                    disabled={downloadingItem === 'apk-zip'}
                    className="p-3 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/50 text-emerald-200 font-bold text-xs flex flex-col items-center justify-center gap-1 transition-all cursor-pointer text-center"
                  >
                    <div className="flex items-center gap-1.5">
                      <FileArchive className="w-4 h-4 text-emerald-300" />
                      <span>
                        {downloadingItem === 'apk-zip'
                          ? 'Downloading ZIP...'
                          : 'Download APK Kit (.ZIP)'}
                      </span>
                    </div>
                    <span className="text-[10px] font-normal text-emerald-300/80">
                      Icon + Manifest + APK Builder
                    </span>
                  </button>

                  {/* Button 3: Direct Download Standalone App File (.HTML) */}
                  <button
                    onClick={handleDownloadStandaloneApp}
                    disabled={downloadingItem === 'standalone-app'}
                    className="p-3 rounded-xl bg-violet-500/20 hover:bg-violet-500/30 border border-violet-400/50 text-violet-200 font-bold text-xs flex flex-col items-center justify-center gap-1 transition-all cursor-pointer text-center"
                  >
                    <div className="flex items-center gap-1.5">
                      <Download className="w-4 h-4 text-violet-300" />
                      <span>
                        {downloadingItem === 'standalone-app'
                          ? 'Saving App...'
                          : 'Save App Launcher'}
                      </span>
                    </div>
                    <span className="text-[10px] font-normal text-violet-300/80">
                      RoutineHub-MobileApp.html
                    </span>
                  </button>
                </div>

                {/* Top-Level Browser Native Install Trigger when inside Preview iFrame */}
                {isInIframe && !isInstallable && (
                  <div className="rounded-xl bg-[#D4AF77]/15 border border-[#D4AF77]/45 p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
                    <div className="text-xs text-slate-200">
                      <strong className="text-[#D4AF77] block">
                        Want the native Chrome &quot;Install RoutineHub&quot; popup dialog right now?
                      </strong>
                      <span>
                        Browsers restrict native install dialogs inside preview frames. Click to open in a full tab where the native PWA install dialog fires directly:
                      </span>
                    </div>
                    <a
                      href={topLevelInstallUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => downloadOfficialApkIcon('512')}
                      className="px-3.5 py-2 rounded-xl bg-[#D4AF77] hover:brightness-110 text-slate-950 font-extrabold text-xs flex items-center gap-1.5 shrink-0 shadow-sm"
                    >
                      <ExternalLink className="w-3.5 h-3.5 stroke-[2.5]" />
                      <span>Open Top-Level Install Prompt</span>
                    </a>
                  </div>
                )}

                {/* Clear Step-by-Step Instructions for Android Phone Installation */}
                <div className="rounded-xl bg-slate-950/80 border border-white/10 p-3.5 space-y-2">
                  <p className="text-xs font-bold text-[#D4AF77]">
                    How to Install Directly on Your Android Phone (with AR BISWANATH BEHERA Icon):
                  </p>
                  <ol className="space-y-1.5 text-xs text-slate-200 list-decimal list-inside">
                    <li>
                      Copy the live link below and open it in <strong className="text-cyan-300">Google Chrome</strong> on your Android phone (outside the preview frame).
                    </li>
                    <li>
                      Tap <strong className="text-emerald-300">&quot;Install App &amp; Download Icon&quot;</strong> on the top banner or tap Chrome&apos;s menu{' '}
                      <span className="px-1.5 py-0.5 rounded bg-slate-800 font-mono text-cyan-200">⋮</span>{' '}
                      → <strong className="text-emerald-300">&quot;Install app&quot;</strong>.
                    </li>
                    <li>
                      Android will automatically install <strong className="text-white">RoutineHub — AR BISWANATH BEHERA</strong> with your gold &amp; brushed-steel <strong className="text-[#D4AF77]">AR</strong> icon!
                    </li>
                  </ol>
                </div>
              </div>

              {/* Copyable Live Install URL */}
              <div className="rounded-2xl bg-slate-900/90 border border-white/10 p-3.5 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
                <div className="min-w-0 flex-1">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
                    Direct Android Chrome Install Link (Copy &amp; Open in Chrome)
                  </span>
                  <span className="text-xs font-mono text-cyan-300 truncate block mt-0.5 select-all">
                    {`${SHARED_APP_URL}/?install=1`}
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={handleCopyUrl}
                    className="px-4 py-2 rounded-xl bg-[#D4AF77] hover:brightness-110 text-slate-950 text-xs font-extrabold flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    {copiedUrl ? (
                      <>
                        <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                        <span>Copied Link!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 stroke-[2.5]" />
                        <span>Copy Install Link</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'apk-builder' && (
            <div className="space-y-4">
              <div className="rounded-2xl bg-emerald-500/10 border border-emerald-400/30 p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-300 flex items-center gap-1.5">
                    <Package className="w-4 h-4" />
                    Download Complete Android APK Package (.ZIP)
                  </span>
                  <span className="text-[11px] font-mono text-emerald-200/90 bg-emerald-500/20 px-2 py-0.5 rounded-md">
                    Includes AR Icon + Manifests
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  Click below to immediately download <code className="text-cyan-300">RoutineHub-AR-BISWANATH-BEHERA-Android-APK-Package.zip</code> containing your 512×512 &amp; 192×192 <strong className="text-[#D4AF77]">AR BISWANATH BEHERA</strong> icons, <code className="text-cyan-300">twa-manifest.json</code>, <code className="text-cyan-300">BUILD-ANDROID-APK.bat</code>, and standalone mobile launcher:
                </p>

                <div className="pt-1 flex flex-wrap items-center gap-2.5">
                  <button
                    onClick={handleDownloadApkPackageZip}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-400 text-slate-950 font-extrabold text-xs flex items-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:brightness-110 transition-all cursor-pointer"
                  >
                    <Download className="w-4 h-4 stroke-[2.5]" />
                    <span>Download Android APK Package (.ZIP)</span>
                  </button>

                  <button
                    onClick={() => handleDownloadApkIcon('512')}
                    className="px-3.5 py-2.5 rounded-xl bg-slate-900 border border-[#D4AF77]/40 text-xs font-semibold text-[#D4AF77] hover:bg-slate-800 flex items-center gap-1.5 cursor-pointer"
                  >
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>Download 512×512 APK Icon</span>
                  </button>
                </div>
              </div>

              {/* Downloadable Individual Config Files */}
              <div className="rounded-2xl bg-slate-900/90 border border-white/10 p-4 space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Individual Android Configuration Files
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    onClick={handleDownloadTwaManifest}
                    className="p-3 rounded-xl bg-slate-950/80 hover:bg-slate-950 border border-cyan-400/30 text-left flex items-center justify-between gap-2 transition-colors cursor-pointer"
                  >
                    <div>
                      <span className="text-xs font-bold text-cyan-300 block">
                        twa-manifest-routinehub.json
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Google Bubblewrap Android APK config
                      </span>
                    </div>
                    <Download className="w-4 h-4 text-cyan-300 shrink-0" />
                  </button>

                  <button
                    onClick={handleDownloadCapacitorConfig}
                    className="p-3 rounded-xl bg-slate-950/80 hover:bg-slate-950 border border-violet-400/30 text-left flex items-center justify-between gap-2 transition-colors cursor-pointer"
                  >
                    <div>
                      <span className="text-xs font-bold text-violet-300 block">
                        capacitor.config.json
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Capacitor Native Android Studio config
                      </span>
                    </div>
                    <Download className="w-4 h-4 text-violet-300 shrink-0" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'cli' && (
            <div className="space-y-4">
              <div className="rounded-2xl bg-slate-900/90 border border-white/10 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-violet-300">
                    Build Signed .APK via Google Bubblewrap CLI
                  </span>
                  <button
                    onClick={handleCopyCli}
                    className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-semibold text-white flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedCli ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-300">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-cyan-300" />
                        <span>Copy Commands</span>
                      </>
                    )}
                  </button>
                </div>

                <pre className="p-3.5 rounded-xl bg-slate-950 border border-white/10 text-xs font-mono text-cyan-200 overflow-x-auto leading-relaxed">
                  {bubblewrapCommands}
                </pre>

                <p className="text-xs text-slate-400">
                  Or extract <code className="text-emerald-300">RoutineHub-AR-BISWANATH-BEHERA-Android-APK-Package.zip</code> and double-click <code className="text-[#D4AF77]">BUILD-ANDROID-APK.bat</code> on Windows to automatically generate <code className="text-emerald-300">app-release-signed.apk</code>.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 sm:px-6 py-3.5 border-t border-white/10 bg-slate-950/80 flex items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>AR BISWANATH BEHERA · Official APK Icon &amp; Manifest Active</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-semibold transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined' ? createPortal(modalUI, document.body) : modalUI;
};
