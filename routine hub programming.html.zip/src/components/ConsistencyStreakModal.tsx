import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  X,
  ArrowLeft,
  Flame,
  Award,
  CheckCircle2,
  Snowflake,
  Clock,
  AlertCircle,
  TrendingUp,
  ShieldCheck,
} from 'lucide-react';
import {
  StreakCalculationResult,
  DayStreakRecord,
} from '../utils/streakUtils';

interface ConsistencyStreakModalProps {
  isOpen: boolean;
  onClose: () => void;
  streakData: StreakCalculationResult;
  history: DayStreakRecord[];
  onSelectDate?: (dateStr: string) => void;
}

export const ConsistencyStreakModal: React.FC<ConsistencyStreakModalProps> = ({
  isOpen,
  onClose,
  streakData,
  history,
  onSelectDate,
}) => {
  const [pressedHistoryDate, setPressedHistoryDate] = useState<string | null>(null);

  // Allow Escape key to return to dashboard
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const {
    currentStreak,
    bestStreak,
    todayTasksCount,
    todayCompletedCount,
    todayCompletionRate,
    todayMetGoal,
    todayIsRestDay,
    tierInfo,
    nextMilestone,
    daysToNextMilestone,
  } = streakData;

  const progressToMilestone = Math.min(
    100,
    Math.round((currentStreak / nextMilestone) * 100)
  );

  const modalContent = (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg bg-slate-900 border border-amber-500/40 rounded-3xl shadow-2xl p-4 sm:p-6 space-y-4 sm:space-y-5 my-auto max-h-[92vh] overflow-y-auto"
      >
        {/* Top Navigation & Return Bar */}
        <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-3.5 sticky top-0 z-20 bg-slate-900/95 backdrop-blur-md -mx-4 px-4 sm:-mx-6 sm:px-6 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-bold text-cyan-300 hover:text-white transition-all active:scale-95 cursor-pointer shrink-0"
            aria-label="Return to Dashboard"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return</span>
          </button>

          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center shrink-0">
              <Flame className="w-4 h-4 fill-amber-400 text-amber-400" />
            </div>
            <div className="truncate">
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm sm:text-base font-bold text-white tracking-tight truncate">
                  80% Consistency Streak
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 shrink-0">
                  {tierInfo.label}
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors shrink-0 cursor-pointer"
            aria-label="Close Streak Modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Big Hero Streak Counter Banner */}
        <div
          className={`p-4 sm:p-5 rounded-2xl bg-gradient-to-br ${tierInfo.bgGradient} border ${tierInfo.borderColor} flex items-center justify-between shadow-lg relative overflow-hidden`}
        >
          <div className="relative z-10">
            <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block">
              Active Consecutive Streak
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-4xl sm:text-5xl font-black font-mono tracking-tight text-white drop-shadow-sm tabular-nums">
                {currentStreak}
              </span>
              <span className="text-sm sm:text-base font-bold text-amber-300">
                {currentStreak === 1 ? 'Day' : 'Days'}
              </span>
            </div>

            <div className="flex items-center gap-2 mt-2 text-xs">
              <span className="text-slate-300">All-Time Best:</span>
              <span className="font-bold font-mono text-amber-300 tabular-nums">
                {bestStreak} {bestStreak === 1 ? 'Day' : 'Days'}
              </span>
            </div>
          </div>

          {/* Flame Graphic Indicator */}
          <div className="relative z-10 text-right flex flex-col items-center justify-center bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <Flame className={`w-10 h-10 ${tierInfo.flameColor}`} />
            <span className="text-[10px] font-bold text-slate-300 mt-1 uppercase tracking-wider">
              {tierInfo.label}
            </span>
          </div>
        </div>

        {/* Today's 80% Target Status Box */}
        <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-300 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-sky-400" />
              Today's 80% Goal Status
            </span>
            <span className="font-mono font-bold text-white tabular-nums">
              {todayCompletedCount} / {todayTasksCount} completed ({todayCompletionRate}%)
            </span>
          </div>

          {/* Progress Bar with 80% Benchmark Marker */}
          <div className="relative w-full h-3 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                todayMetGoal
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                  : 'bg-gradient-to-r from-indigo-500 to-amber-500'
              }`}
              style={{ width: `${Math.min(100, todayCompletionRate)}%` }}
            />
            {/* 80% Threshold Guide Marker */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-amber-400/90 z-10"
              style={{ left: '80%' }}
              title="80% Completion Benchmark"
            />
          </div>

          {/* Dynamic Status Callout */}
          <div className="flex items-center justify-between text-[11px] pt-1">
            {todayIsRestDay ? (
              <span className="text-sky-300 flex items-center gap-1">
                <Snowflake className="w-3.5 h-3.5 text-sky-400" />
                Rest Day (No tasks scheduled — streak frozen safely)
              </span>
            ) : todayMetGoal ? (
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                80% Target Met! +1 day added to your streak.
              </span>
            ) : (
              <span className="text-amber-300 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                In Progress: Need{' '}
                {Math.max(1, Math.ceil(todayTasksCount * 0.8) - todayCompletedCount)} more task
                {Math.max(1, Math.ceil(todayTasksCount * 0.8) - todayCompletedCount) === 1
                  ? ''
                  : 's'}{' '}
                to hit 80%.
              </span>
            )}
            <span className="text-slate-500 text-[10px] font-mono">Benchmark: 80%</span>
          </div>
        </div>

        {/* Recent 7-Day History Breakdown */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-semibold text-slate-300">Past 7 Days History</span>
            <span className="text-[11px]">Tap any day to jump</span>
          </div>

          <div className="grid grid-cols-7 gap-1.5">
            {history.map((day) => {
              const isPressed = pressedHistoryDate === day.dateStr;
              return (
                <button
                  key={day.dateStr}
                  type="button"
                  onPointerDown={(e) => {
                    if (e.pointerType === 'mouse' && e.button !== 0) return;
                    setPressedHistoryDate(day.dateStr);
                    if (
                      typeof navigator !== 'undefined' &&
                      typeof navigator.vibrate === 'function'
                    ) {
                      try {
                        navigator.vibrate(8);
                      } catch {
                        // Ignore vibration errors
                      }
                    }
                  }}
                  onPointerUp={(e) => {
                    if (e.pointerType === 'mouse' && e.button !== 0) return;
                    if (pressedHistoryDate === day.dateStr) {
                      setPressedHistoryDate(null);
                      if (onSelectDate) {
                        onSelectDate(day.dateStr);
                        onClose();
                      }
                    }
                  }}
                  onPointerLeave={() => setPressedHistoryDate(null)}
                  onPointerCancel={() => setPressedHistoryDate(null)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      if (onSelectDate) {
                        onSelectDate(day.dateStr);
                        onClose();
                      }
                    }
                  }}
                  style={{ touchAction: 'manipulation' }}
                  className={`p-2 rounded-xl border flex flex-col items-center justify-between min-h-[64px] transition-all cursor-pointer select-none ${
                    isPressed
                      ? 'scale-95 ring-2 ring-cyan-400 border-cyan-400 bg-cyan-500/20 shadow-[0_0_16px_rgba(34,211,238,0.4)]'
                      : 'hover:scale-105'
                  } ${
                    day.isToday
                      ? 'ring-2 ring-indigo-400 border-indigo-500/50 bg-slate-900'
                      : day.status === 'met'
                      ? 'bg-emerald-950/40 border-emerald-800/50 text-emerald-300'
                      : day.status === 'frozen_rest'
                      ? 'bg-sky-950/30 border-sky-800/40 text-sky-300'
                      : day.status === 'in_progress'
                      ? 'bg-amber-950/30 border-amber-800/40 text-amber-300'
                      : 'bg-rose-950/20 border-rose-900/40 text-rose-400'
                  }`}
                  title={`${day.dayName} (${day.dateStr}): ${day.completedTasks}/${day.totalTasks} tasks (${day.rate}%)`}
                >
                  <span className="text-[10px] font-bold uppercase opacity-80">
                    {day.dayName}
                  </span>

                  <div className="my-0.5">
                    {day.status === 'met' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : day.status === 'frozen_rest' ? (
                      <Snowflake className="w-4 h-4 text-sky-400" />
                    ) : day.status === 'in_progress' ? (
                      <Clock className="w-4 h-4 text-amber-400" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-rose-400" />
                    )}
                  </div>

                  <span className="text-[10px] font-mono font-bold tabular-nums">
                    {day.totalTasks > 0 ? `${day.rate}%` : 'Rest'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Next Milestone Target */}
        <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <div className="font-bold text-white">
                Next Milestone: {nextMilestone} Days
              </div>
              <div className="text-[11px] text-slate-400">
                {daysToNextMilestone === 0
                  ? 'Milestone achieved!'
                  : `${daysToNextMilestone} more day${daysToNextMilestone === 1 ? '' : 's'} to advance`}
              </div>
            </div>
          </div>

          <div className="w-24 text-right">
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-amber-400 h-full rounded-full transition-all"
                style={{ width: `${progressToMilestone}%` }}
              />
            </div>
            <span className="text-[10px] text-slate-400 font-mono mt-0.5 block">
              {progressToMilestone}%
            </span>
          </div>
        </div>

        {/* Rest Day Safeguard Guarantee Footer Note */}
        <div className="flex items-center gap-2 text-[11px] text-slate-400 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800/80">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            <strong>Rest-Day Freeze Guarantee:</strong> Zero-task recovery days never penalize or reset your streak.
          </span>
        </div>

        {/* Prominent Return to Dashboard Action Button */}
        <div className="pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-cyan-500 via-sky-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-extrabold text-xs sm:text-sm tracking-wide flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all active:scale-[0.98] cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
            <span>Return to Dashboard</span>
          </button>
        </div>
      </div>
    </div>
  );

  return typeof document !== 'undefined'
    ? createPortal(modalContent, document.body)
    : modalContent;
};
