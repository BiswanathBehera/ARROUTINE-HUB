import React, { useEffect, useState } from 'react';
import {
  AlarmClock,
  Bell,
  BellOff,
  Volume2,
  VolumeX,
  GraduationCap,
  Briefcase,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Target,
  Download,
  Upload,
  Sun,
  Moon,
  ArrowUpRight,
  Plus,
  Smartphone,
  User,
} from 'lucide-react';
import {
  CollegeConfig,
  NotificationSettings,
  SleepConfig,
  Task,
  UserAccount,
} from '../types/routine';
import { formatDateLabel, formatTime12h, getTodayDateString } from '../utils/dateUtils';
import { requestNotificationPermission, showBrowserNotification } from '../utils/notifications';
import { sounds } from '../utils/audio';
import { useTheme } from '../context/ThemeContext';
import { ConsistencyStreakBadge } from './ConsistencyStreakBadge';

interface HeaderProps {
  tasks: Task[];
  selectedDate: string;
  onDateChange: (date: string) => void;
  collegeConfig: CollegeConfig;
  onOpenCollegeSettings: () => void;
  sleepConfig: SleepConfig;
  onOpenSleepSchedule: () => void;
  onOpenAddTask: () => void;
  onOpenFocusMode: () => void;
  onOpenExport: () => void;
  onOpenTimetableUpload?: () => void;
  onOpenLandingHero?: () => void;
  notificationSettings: NotificationSettings;
  onUpdateNotifications: (settings: NotificationSettings) => void;
  remainingCount: number;
  onTestClassAlarm?: () => void;
  onOpenApkModal?: () => void;
  activeUser?: UserAccount | null;
  onOpenAuthModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  tasks,
  selectedDate,
  onDateChange,
  collegeConfig,
  onOpenCollegeSettings,
  sleepConfig,
  onOpenSleepSchedule,
  onOpenAddTask,
  onOpenFocusMode,
  onOpenExport,
  onOpenTimetableUpload,
  onOpenLandingHero,
  notificationSettings,
  onUpdateNotifications,
  remainingCount,
  onTestClassAlarm,
  onOpenApkModal,
  activeUser,
  onOpenAuthModal,
}) => {
  const { isLight, toggleTheme } = useTheme();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [pressedCalendarDate, setPressedCalendarDate] = useState<string | null>(null);

  const handleToggleTheme = () => {
    toggleTheme();
    if (notificationSettings.soundEnabled) {
      sounds.playNotificationPing();
    }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const todayStr = getTodayDateString();

  const handlePrevDay = () => {
    const [y, m, d] = selectedDate.split('-').map(Number);
    const prev = new Date(y, m - 1, d - 1);
    const dateStr = `${prev.getFullYear()}-${String(prev.getMonth() + 1).padStart(2, '0')}-${String(prev.getDate()).padStart(2, '0')}`;
    onDateChange(dateStr);
  };

  const handleNextDay = () => {
    const [y, m, d] = selectedDate.split('-').map(Number);
    const next = new Date(y, m - 1, d + 1);
    const dateStr = `${next.getFullYear()}-${String(next.getMonth() + 1).padStart(2, '0')}-${String(next.getDate()).padStart(2, '0')}`;
    onDateChange(dateStr);
  };

  const handleToggleSound = () => {
    const updated = {
      ...notificationSettings,
      soundEnabled: !notificationSettings.soundEnabled,
    };
    onUpdateNotifications(updated);
    if (updated.soundEnabled) {
      sounds.playComplete();
    }
  };

  const classAlarmActive = notificationSettings.classEndAlarmEnabled !== false;

  const handleToggleClassAlarm = () => {
    const nextState = !classAlarmActive;
    const updated: NotificationSettings = {
      ...notificationSettings,
      classEndAlarmEnabled: nextState,
      classStartAlarmEnabled: nextState,
      soundEnabled: nextState ? true : notificationSettings.soundEnabled,
    };
    onUpdateNotifications(updated);
    if (nextState) {
      sounds.playComplete();
    }
  };

  const handleToggleBrowserNotifications = async () => {
    if (!notificationSettings.browserNotifications) {
      const granted = await requestNotificationPermission();
      if (granted) {
        onUpdateNotifications({
          ...notificationSettings,
          browserNotifications: true,
        });
        showBrowserNotification(
          'Daily Routine Alerts Enabled',
          `We will keep you notified! You currently have ${remainingCount} tasks left for today.`
        );
        sounds.playNotificationPing();
      }
    } else {
      onUpdateNotifications({
        ...notificationSettings,
        browserNotifications: false,
      });
    }
  };

  const formattedCurrentTime = currentTime.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [calendarViewDate, setCalendarViewDate] = useState(() => {
    const [y, m] = selectedDate.split('-').map(Number);
    return new Date(y, m - 1, 1);
  });

  useEffect(() => {
    const [y, m] = selectedDate.split('-').map(Number);
    if (y && m) {
      setCalendarViewDate(new Date(y, m - 1, 1));
    }
  }, [selectedDate]);

  const calendarDays = React.useMemo(() => {
    const year = calendarViewDate.getFullYear();
    const month = calendarViewDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startOffset = firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1; // Mon=0..Sun=6
    const totalDays = lastDay.getDate();

    const cells: {
      dateStr: string;
      dayNum: number;
      isCurrentMonth: boolean;
      isToday: boolean;
      isSelected: boolean;
      totalTasks: number;
      completedTasks: number;
      pct: number;
    }[] = [];

    const buildCell = (d: Date, inMonth: boolean) => {
      const yr = d.getFullYear();
      const mo = String(d.getMonth() + 1).padStart(2, '0');
      const da = String(d.getDate()).padStart(2, '0');
      const dStr = `${yr}-${mo}-${da}`;
      const dayTasks = tasks.filter((t) => t.date === dStr && !t.isCollegeFixed && t.category !== 'college');
      const total = dayTasks.length;
      const done = dayTasks.filter((t) => t.completed).length;
      return {
        dateStr: dStr,
        dayNum: d.getDate(),
        isCurrentMonth: inMonth,
        isToday: dStr === todayStr,
        isSelected: dStr === selectedDate,
        totalTasks: total,
        completedTasks: done,
        pct: total > 0 ? Math.round((done / total) * 100) : 0,
      };
    };

    for (let i = startOffset; i > 0; i--) {
      cells.push(buildCell(new Date(year, month, 1 - i), false));
    }
    for (let d = 1; d <= totalDays; d++) {
      cells.push(buildCell(new Date(year, month, d), true));
    }
    const rem = cells.length % 7;
    const trailing = rem === 0 ? 0 : 7 - rem;
    for (let i = 1; i <= trailing; i++) {
      cells.push(buildCell(new Date(year, month + 1, i), false));
    }
    return cells;
  }, [calendarViewDate, tasks, todayStr, selectedDate]);

  return (
    <header className="luxury-sticky-bar sticky top-0 z-40 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          {/* Zone 1: Clean Brand Wordmark & Mobile Quick Utilities */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 sm:gap-4">
              <button
                onClick={onOpenLandingHero}
                className="flex items-center gap-2.5 text-left group whitespace-nowrap shrink-0 cursor-pointer focus:outline-none"
                title="View Luxury Landing Hero"
              >
                <img
                  src="/pwa-192x192.png"
                  alt="AR BISWANATH BEHERA Icon"
                  className="w-9 h-9 rounded-xl border border-cyan-400/50 shadow-[0_0_12px_rgba(34,211,238,0.25)] object-cover shrink-0"
                />
                <div className="flex flex-col leading-none">
                  <span className="font-sans text-lg sm:text-xl font-bold tracking-tight text-white group-hover:text-cyan-300 transition-colors">
                    RoutineHub
                  </span>
                  <span className="mt-1 font-luxury-mono text-[9px] sm:text-[10px] font-semibold tracking-[0.18em] uppercase text-cyan-300/90">
                    AR BISWANATH BEHERA
                  </span>
                </div>
              </button>
              <span aria-hidden="true" className="text-slate-600 hidden sm:inline">
                ·
              </span>
              <span className="hidden sm:inline font-luxury-mono text-xs text-cyan-300 font-semibold tabular-nums whitespace-nowrap">
                {formattedCurrentTime}
              </span>
            </div>

            {/* Mobile Utility Triggers (All >= 40px touch targets, vibrant aurora accents) */}
            <div className="flex md:hidden items-center gap-1.5">
              <ConsistencyStreakBadge
                tasks={tasks}
                selectedDate={selectedDate}
                onSelectDate={onDateChange}
                soundEnabled={notificationSettings.soundEnabled}
              />

              <button
                onClick={handleToggleClassAlarm}
                onDoubleClick={onTestClassAlarm}
                className={`min-w-[38px] min-h-[38px] px-2 rounded-xl glass-layer-12 border flex items-center gap-1 justify-center transition-all ${
                  classAlarmActive
                    ? 'border-cyan-400/50 bg-cyan-500/15 text-cyan-200 shadow-[0_0_10px_rgba(34,211,238,0.2)]'
                    : 'border-white/10 text-slate-400'
                }`}
                title={
                  classAlarmActive
                    ? 'After-Every-Class Alarm: ON (Tap to toggle)'
                    : 'After-Every-Class Alarm: OFF (Tap to enable)'
                }
              >
                <AlarmClock
                  className={`w-4 h-4 ${
                    classAlarmActive ? 'text-cyan-300' : 'text-slate-500'
                  }`}
                />
                <span className="text-[10px] font-bold hidden xs:inline">
                  {classAlarmActive ? 'ON' : 'OFF'}
                </span>
              </button>

              <button
                onClick={handleToggleTheme}
                className="min-w-[38px] min-h-[38px] p-2 rounded-xl glass-layer-12 border border-white/10 text-slate-200 flex items-center justify-center transition-colors"
                title={isLight ? 'Switch to Slate Dark Mode' : 'Switch to Cream Light Mode'}
              >
                {isLight ? (
                  <Moon className="w-4 h-4 text-slate-700" />
                ) : (
                  <Sun className="w-4 h-4 text-amber-300" />
                )}
              </button>

              {onOpenTimetableUpload && (
                <button
                  onClick={onOpenTimetableUpload}
                  className="min-w-[38px] min-h-[38px] p-2 rounded-xl glass-layer-12 border border-cyan-500/25 text-slate-200 flex items-center justify-center"
                  title="Upload Timetable (Photo/PDF)"
                >
                  <Upload className="w-4 h-4 text-cyan-400" />
                </button>
              )}

              {onOpenApkModal && (
                <button
                  onClick={onOpenApkModal}
                  className="min-w-[38px] min-h-[38px] px-2 rounded-xl bg-emerald-500/15 border border-emerald-400/40 text-emerald-200 flex items-center gap-1 justify-center shadow-[0_0_10px_rgba(16,185,129,0.2)]"
                  title="Install Android APK / Mobile App"
                >
                  <Smartphone className="w-4 h-4 text-emerald-300" />
                  <span className="text-[10px] font-bold">APK</span>
                </button>
              )}

              <button
                onClick={onOpenExport}
                className="min-w-[38px] min-h-[38px] p-2 rounded-xl glass-layer-12 border border-amber-500/30 text-slate-200 flex items-center justify-center"
                title="Export PDF & Save Schedule File"
              >
                <Download className="w-4 h-4 text-amber-300" />
              </button>

              <button
                onClick={onOpenFocusMode}
                className="min-w-[38px] min-h-[38px] p-2 rounded-xl glass-layer-12 border border-emerald-500/25 text-slate-200 flex items-center justify-center"
                title="Enter Focus Mode"
              >
                <Target className="w-4 h-4 text-emerald-400" />
              </button>

              {onOpenAuthModal && (
                <button
                  onClick={onOpenAuthModal}
                  className={`min-w-[38px] min-h-[38px] px-2 rounded-xl border flex items-center gap-1 justify-center transition-all cursor-pointer ${
                    activeUser
                      ? 'bg-cyan-500/15 border-cyan-400/50 text-cyan-200'
                      : 'bg-amber-500/15 border-amber-400/45 text-amber-200'
                  }`}
                  title={
                    activeUser
                      ? `Account: ${activeUser.name} (${activeUser.email})`
                      : 'Initialize Login / Create Account'
                  }
                >
                  <User className="w-4 h-4 text-amber-300" />
                  <span className="text-[10px] font-bold max-w-[54px] truncate">
                    {activeUser ? activeUser.name.split(' ')[0] : 'Login'}
                  </span>
                </button>
              )}

              <button
                onClick={onOpenAddTask}
                className="min-w-[38px] min-h-[38px] px-2.5 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-500 to-indigo-600 text-slate-950 font-bold flex items-center justify-center shadow-[0_0_12px_rgba(34,211,238,0.3)]"
                title="Quick Add Task"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>
          </div>

          {/* Zone 2: Interactive Date Navigator & Consistency Streak */}
          <div className="flex flex-wrap items-center justify-center gap-2.5 relative">
            <div className="flex items-center justify-center gap-1 p-1 rounded-xl glass-layer-12 border border-cyan-500/25">
              <button
                type="button"
                onClick={handlePrevDay}
                className="p-1.5 hover:bg-cyan-500/15 text-slate-300 hover:text-cyan-300 rounded-lg transition-colors cursor-pointer"
                title="Previous Day"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => onDateChange(todayStr)}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedDate === todayStr
                    ? 'bg-gradient-to-r from-cyan-400 to-indigo-500 text-slate-950 font-bold shadow-[0_0_10px_rgba(34,211,238,0.3)]'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                Today
              </button>

              <button
                type="button"
                onPointerDown={(e) => {
                  if (e.pointerType === 'mouse' && e.button !== 0) return;
                  if (
                    typeof navigator !== 'undefined' &&
                    typeof navigator.vibrate === 'function'
                  ) {
                    try {
                      navigator.vibrate(8);
                    } catch {
                      // Ignore vibration errors
                    }
                  }
                  setIsCalendarOpen((prev) => !prev);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setIsCalendarOpen((prev) => !prev);
                  }
                }}
                style={{ touchAction: 'manipulation' }}
                className={`text-xs font-semibold px-2.5 py-1 rounded-lg flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer border select-none ${
                  isCalendarOpen
                    ? 'bg-cyan-500/20 border-cyan-400/60 text-cyan-200 shadow-[0_0_12px_rgba(34,211,238,0.25)]'
                    : 'border-transparent text-slate-100 hover:bg-cyan-500/15 hover:border-cyan-400/35 hover:text-cyan-200'
                }`}
                title="Click or tap to open interactive Calendar"
              >
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>{formatDateLabel(selectedDate)}</span>
              </button>

              <button
                type="button"
                onClick={handleNextDay}
                className="p-1.5 hover:bg-cyan-500/15 text-slate-300 hover:text-cyan-300 rounded-lg transition-colors cursor-pointer"
                title="Next Day"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Interactive Calendar Popover for Mobile, Tablet & Laptop */}
            {isCalendarOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onPointerDown={() => setIsCalendarOpen(false)}
                />
                <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 z-50 w-[300px] sm:w-[330px] rounded-2xl bg-slate-900/95 backdrop-blur-xl border border-cyan-400/40 shadow-[0_16px_40px_rgba(0,0,0,0.75),0_0_24px_rgba(34,211,238,0.2)] p-3.5 space-y-3 animate-fadeIn">
                  <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                    <button
                      type="button"
                      onClick={() =>
                        setCalendarViewDate(
                          new Date(calendarViewDate.getFullYear(), calendarViewDate.getMonth() - 1, 1)
                        )
                      }
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <span className="text-xs font-bold text-white tracking-wide">
                      {calendarViewDate.toLocaleDateString('en-US', {
                        month: 'long',
                        year: 'numeric',
                      })}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setCalendarViewDate(
                          new Date(calendarViewDate.getFullYear(), calendarViewDate.getMonth() + 1, 1)
                        )
                      }
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-cyan-500/20 text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-bold uppercase text-slate-400">
                    {['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'].map((d) => (
                      <span key={d}>{d}</span>
                    ))}
                  </div>

                  <div className="grid grid-cols-7 gap-1">
                    {calendarDays.map((cell) => {
                      const isPressed = pressedCalendarDate === cell.dateStr;
                      return (
                        <button
                          key={cell.dateStr}
                          type="button"
                          onPointerDown={(e) => {
                            if (e.pointerType === 'mouse' && e.button !== 0) return;
                            setPressedCalendarDate(cell.dateStr);
                            if (
                              typeof navigator !== 'undefined' &&
                              typeof navigator.vibrate === 'function'
                            ) {
                              try {
                                navigator.vibrate(8);
                              } catch {
                                // Ignore vibration errors
                              }
                            }
                          }}
                          onPointerUp={(e) => {
                            if (e.pointerType === 'mouse' && e.button !== 0) return;
                            if (pressedCalendarDate === cell.dateStr) {
                              setPressedCalendarDate(null);
                              onDateChange(cell.dateStr);
                              setIsCalendarOpen(false);
                            }
                          }}
                          onPointerLeave={() => setPressedCalendarDate(null)}
                          onPointerCancel={() => setPressedCalendarDate(null)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' || e.key === ' ') {
                              e.preventDefault();
                              onDateChange(cell.dateStr);
                              setIsCalendarOpen(false);
                            }
                          }}
                          style={{ touchAction: 'manipulation' }}
                          className={`h-9 rounded-xl flex flex-col items-center justify-center text-xs font-mono tabular-nums transition-all cursor-pointer border select-none ${
                            isPressed
                              ? 'scale-95 bg-cyan-400/40 border-cyan-300 text-white shadow-[0_0_16px_rgba(34,211,238,0.5)]'
                              : cell.isSelected
                              ? 'bg-gradient-to-b from-cyan-500/40 to-indigo-600/40 border-cyan-400 text-white font-extrabold shadow-[0_0_12px_rgba(34,211,238,0.35)] scale-105'
                              : cell.isToday
                              ? 'bg-cyan-500/15 border-cyan-400/40 text-cyan-300 font-bold'
                              : cell.isCurrentMonth
                              ? 'bg-slate-950/60 border-white/5 text-slate-200 hover:border-cyan-400/40 hover:bg-cyan-500/10'
                              : 'bg-transparent border-transparent text-slate-600 hover:text-slate-400'
                          }`}
                        >
                          <span className="leading-none">{cell.dayNum}</span>
                          {cell.totalTasks > 0 && (
                            <span
                              className={`mt-0.5 w-1.5 h-1.5 rounded-full ${
                                cell.pct === 100
                                  ? 'bg-emerald-400'
                                  : cell.pct >= 50
                                  ? 'bg-cyan-400'
                                  : 'bg-amber-400'
                              }`}
                            />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-white/10 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        onDateChange(todayStr);
                        setIsCalendarOpen(false);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-cyan-500/15 border border-cyan-400/35 text-cyan-300 hover:bg-cyan-500/25 text-[11px] font-bold transition-colors cursor-pointer"
                    >
                      Jump to Today
                    </button>
                    <input
                      type="date"
                      value={selectedDate}
                      onChange={(e) => {
                        if (e.target.value) {
                          onDateChange(e.target.value);
                          setIsCalendarOpen(false);
                        }
                      }}
                      className="px-2 py-1 rounded-lg bg-slate-950 border border-white/10 text-[11px] text-slate-200 cursor-pointer focus:outline-none"
                    />
                  </div>
                </div>
              </>
            )}

            <div className="hidden md:flex items-center">
              <ConsistencyStreakBadge
                tasks={tasks}
                selectedDate={selectedDate}
                onSelectDate={onDateChange}
                soundEnabled={notificationSettings.soundEnabled}
              />
            </div>
          </div>

          {/* Zone 3: Secondary Workspace Controls (Ghost / Glassmorphic 12px Layers) */}
          <div className="hidden md:flex items-center justify-end gap-2">
            {onOpenLandingHero && (
              <button
                onClick={onOpenLandingHero}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg glass-layer-12 hover:border-[#D4AF77]/50 text-xs font-medium text-slate-200 hover:text-[#D4AF77] transition-all whitespace-nowrap shrink-0 cursor-pointer"
                title="Return to Landing Hero"
              >
                <span>Overview</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#D4AF77]" />
              </button>
            )}

            {onOpenTimetableUpload && (
              <button
                onClick={onOpenTimetableUpload}
                className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 rounded-lg glass-layer-12 hover:border-white/20 text-xs font-medium text-slate-200 transition-all whitespace-nowrap shrink-0 cursor-pointer"
                title="Upload timetable photo or PDF"
              >
                <Upload className="w-3.5 h-3.5 text-sky-400" />
                <span>Scan Timetable</span>
              </button>
            )}

            <button
              onClick={onOpenFocusMode}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg glass-layer-12 hover:border-white/20 text-xs font-medium text-slate-200 transition-all whitespace-nowrap shrink-0 cursor-pointer"
              title="Minimize dashboard to show only the currently active task"
            >
              <Target className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden lg:inline">Focus Mode</span>
            </button>

            <button
              onClick={onOpenSleepSchedule}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg glass-layer-12 hover:border-white/20 text-xs font-medium text-slate-200 transition-all whitespace-nowrap shrink-0 cursor-pointer"
              title={`Protected Sleep Window: ${formatTime12h(sleepConfig.bedTime)} – ${formatTime12h(sleepConfig.wakeTime)}`}
            >
              <Moon className="w-3.5 h-3.5 text-[#D4AF77]" />
              <span className="hidden lg:inline font-luxury-mono tabular-nums">
                {sleepConfig.targetHours || 7}h Rest
              </span>
            </button>

            <div className="flex items-center rounded-lg glass-layer-12 border border-cyan-500/30 overflow-hidden">
              <button
                onClick={handleToggleClassAlarm}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  classAlarmActive
                    ? 'bg-cyan-500/15 text-cyan-200 hover:bg-cyan-500/25'
                    : 'text-slate-400 hover:text-white'
                }`}
                title="Toggle automatic alarm alert after every class finishes"
              >
                <AlarmClock
                  className={`w-3.5 h-3.5 ${
                    classAlarmActive ? 'text-cyan-400 animate-pulse' : 'text-slate-500'
                  }`}
                />
                <span>Class Alarm: {classAlarmActive ? 'ON' : 'OFF'}</span>
              </button>
              {onTestClassAlarm && (
                <button
                  onClick={onTestClassAlarm}
                  className="px-2 py-1.5 border-l border-white/10 text-[11px] font-bold text-amber-300 hover:bg-amber-500/20 transition-colors cursor-pointer"
                  title="Preview After-Class Alarm & Learned Notes Modal"
                >
                  Test
                </button>
              )}
            </div>

            <button
              onClick={onOpenCollegeSettings}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg glass-layer-12 hover:border-white/20 text-xs font-medium text-slate-200 transition-all whitespace-nowrap shrink-0 cursor-pointer"
              title={`Configure Mandatory ${collegeConfig.commitmentType === 'job' ? 'Workplace' : 'College'} Hours`}
            >
              {collegeConfig.commitmentType === 'job' ? (
                <Briefcase className="w-3.5 h-3.5 text-sky-400" />
              ) : (
                <GraduationCap className="w-3.5 h-3.5 text-sky-400" />
              )}
              <span className="hidden lg:inline">
                {collegeConfig.commitmentType === 'job' ? 'Work Hours' : 'College Hours'}
              </span>
            </button>

            <button
              onClick={handleToggleTheme}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg glass-layer-12 hover:border-[#D4AF77]/50 text-xs font-medium text-slate-200 transition-all whitespace-nowrap shrink-0 cursor-pointer"
              title={isLight ? 'Switch to Slate Dark (#0F172A)' : 'Switch to Cream Light (#FAFAFA)'}
              aria-label="Toggle Light or Dark Theme"
            >
              {isLight ? (
                <>
                  <Moon className="w-3.5 h-3.5 text-slate-700" />
                  <span className="hidden xl:inline">Slate</span>
                </>
              ) : (
                <>
                  <Sun className="w-3.5 h-3.5 text-[#D4AF77]" />
                  <span className="hidden xl:inline">Cream</span>
                </>
              )}
            </button>

            <button
              onClick={handleToggleSound}
              className="p-2 rounded-lg glass-layer-12 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title={notificationSettings.soundEnabled ? 'Sound alerts enabled' : 'Sound alerts muted'}
            >
              {notificationSettings.soundEnabled ? (
                <Volume2 className="w-4 h-4 text-emerald-400" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-500" />
              )}
            </button>

            <button
              onClick={handleToggleBrowserNotifications}
              className="p-2 rounded-lg glass-layer-12 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title={
                notificationSettings.browserNotifications
                  ? 'Desktop alerts active'
                  : 'Click to enable desktop notifications'
              }
            >
              {notificationSettings.browserNotifications ? (
                <Bell className="w-4 h-4 text-[#D4AF77]" />
              ) : (
                <BellOff className="w-4 h-4 text-slate-500" />
              )}
            </button>

            {onOpenApkModal && (
              <button
                onClick={onOpenApkModal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/15 border border-emerald-400/40 hover:bg-emerald-500/25 text-xs font-semibold text-emerald-200 transition-all whitespace-nowrap shrink-0 cursor-pointer"
                title="Convert & Install Android APK / Mobile App"
              >
                <Smartphone className="w-3.5 h-3.5 text-emerald-300" />
                <span>Install APK</span>
              </button>
            )}

            <button
              onClick={onOpenExport}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg glass-layer-12 hover:border-white/20 text-xs font-medium text-slate-200 transition-all whitespace-nowrap shrink-0 cursor-pointer"
              title="Export schedule & learning journal as PDF or JSON"
            >
              <Download className="w-3.5 h-3.5 text-[#D4AF77]" />
              <span className="hidden xl:inline">Export</span>
            </button>

            {onOpenAuthModal && (
              <button
                onClick={onOpenAuthModal}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-bold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  activeUser
                    ? 'bg-cyan-500/15 border-cyan-400/50 text-cyan-200 hover:bg-cyan-500/25'
                    : 'bg-amber-400/15 border-amber-400/50 text-amber-300 hover:bg-amber-400/25 shadow-[0_0_14px_rgba(251,191,36,0.2)]'
                }`}
                title={
                  activeUser
                    ? `Signed in as ${activeUser.name} (${activeUser.email}) — Click to switch or sign out`
                    : 'Open Initialize Login / Create Account'
                }
              >
                <User className="w-3.5 h-3.5 text-amber-300" />
                <span>{activeUser ? activeUser.name.split(' ')[0] : 'Login'}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

