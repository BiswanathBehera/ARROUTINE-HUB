import { useState, useEffect, useCallback } from 'react';

export interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

declare global {
  interface Window {
    __deferredPWAInstallPrompt?: BeforeInstallPromptEvent | null;
    __pwaAppInstalled?: boolean;
  }
}

export const SHARED_APP_URL =
  typeof window !== 'undefined' && window.location.origin.startsWith('http')
    ? window.location.origin
    : 'https://ais-dev-b5auu3e6gm3gfebk4tpjfq-514964904305.asia-east1.run.app';

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(() => {
    if (typeof window !== 'undefined' && window.__deferredPWAInstallPrompt) {
      return window.__deferredPWAInstallPrompt;
    }
    return null;
  });
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isInIframe, setIsInIframe] = useState(false);
  const [swReady, setSwReady] = useState(false);
  const [manifestReady, setManifestReady] = useState(false);

  const checkServiceWorkerAndManifest = useCallback(async () => {
    if (typeof window === 'undefined') return;

    // 1. Verify Service Worker registration & active controller
    if ('serviceWorker' in navigator) {
      try {
        let reg = await navigator.serviceWorker.getRegistration('/');
        if (!reg) {
          reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
        }
        if (reg && (reg.active || reg.installing || reg.waiting)) {
          setSwReady(true);
        }
        navigator.serviceWorker.ready
          .then(() => setSwReady(true))
          .catch(() => {});
      } catch {
        // Ignore SW errors in restricted environments
      }
    }

    // 2. Verify Web App Manifest & Icons are reachable
    try {
      const res = await fetch('/manifest.webmanifest', { cache: 'no-cache' });
      if (res.ok) {
        const data = await res.json();
        if (data && data.name && Array.isArray(data.icons) && data.icons.length > 0) {
          setManifestReady(true);
        }
      }
    } catch {
      // Ignore network errors
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Detect standalone mode (already installed as APK / PWA)
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as any).standalone === true ||
      Boolean(window.__pwaAppInstalled);
    setIsInstalled(isStandalone);

    // Detect platform
    const ua = window.navigator.userAgent.toLowerCase();
    const ios =
      /iphone|ipad|ipod/.test(ua) ||
      (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const android = /android/.test(ua);
    setIsIOS(ios);
    setIsAndroid(android);

    // Detect if running inside AI Studio preview iframe (browsers block beforeinstallprompt inside iframes)
    try {
      setIsInIframe(window.self !== window.top);
    } catch {
      setIsInIframe(true);
    }

    // Sync any globally captured beforeinstallprompt
    if (window.__deferredPWAInstallPrompt) {
      setDeferredPrompt(window.__deferredPWAInstallPrompt);
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      const promptEvent = e as BeforeInstallPromptEvent;
      window.__deferredPWAInstallPrompt = promptEvent;
      setDeferredPrompt(promptEvent);
    };

    const handleCustomInstallAvailable = () => {
      if (window.__deferredPWAInstallPrompt) {
        setDeferredPrompt(window.__deferredPWAInstallPrompt);
      }
    };

    const handleAppInstalled = () => {
      window.__deferredPWAInstallPrompt = null;
      window.__pwaAppInstalled = true;
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    const handleSwMessage = (event: MessageEvent) => {
      if (event.data && event.data.type === 'SW_READY') {
        setSwReady(true);
      }
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('pwa-install-available', handleCustomInstallAvailable);
    window.addEventListener('appinstalled', handleAppInstalled);
    window.addEventListener('pwa-app-installed', handleAppInstalled);
    window.addEventListener('pwa-sw-registered', checkServiceWorkerAndManifest);
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', handleSwMessage);
    }

    checkServiceWorkerAndManifest();

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('pwa-install-available', handleCustomInstallAvailable);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('pwa-app-installed', handleAppInstalled);
      window.removeEventListener('pwa-sw-registered', checkServiceWorkerAndManifest);
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.removeEventListener('message', handleSwMessage);
      }
    };
  }, [checkServiceWorkerAndManifest]);

  const promptInstall = useCallback(async (): Promise<boolean> => {
    const activePrompt =
      deferredPrompt ||
      (typeof window !== 'undefined' ? window.__deferredPWAInstallPrompt : null);
    if (!activePrompt) return false;

    try {
      await activePrompt.prompt();
      const { outcome } = await activePrompt.userChoice;
      if (outcome === 'accepted') {
        window.__deferredPWAInstallPrompt = null;
        setDeferredPrompt(null);
        setIsInstalled(true);
        return true;
      }
    } catch {
      // Prompt may only be called once per event instance
    }
    return false;
  }, [deferredPrompt]);

  // Helper to download the official AR BISWANATH BEHERA APK Icon (512x512 or 192x192 PNG)
  const downloadOfficialApkIcon = useCallback(async (size: '512' | '192' = '512') => {
    const filename = `AR-BISWANATH-BEHERA-APK-Icon-${size}x${size}.png`;
    try {
      const iconUrl = size === '512' ? '/pwa-512x512.png' : '/pwa-192x192.png';
      const response = await fetch(iconUrl, { cache: 'no-cache' });
      if (!response.ok) throw new Error('Icon fetch failed');
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) {
          document.body.removeChild(link);
        }
        URL.revokeObjectURL(blobUrl);
      }, 450);
      return true;
    } catch {
      const link = document.createElement('a');
      link.href = `/api/download-apk-icon?size=${size}`;
      link.download = filename;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) {
          document.body.removeChild(link);
        }
      }, 450);
      return true;
    }
  }, []);

  const topLevelInstallUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/?install=1`
      : `${SHARED_APP_URL}/?install=1`;

  return {
    isInstallable: !!deferredPrompt || (typeof window !== 'undefined' && !!window.__deferredPWAInstallPrompt),
    isInstalled,
    isIOS,
    isAndroid,
    isInIframe,
    swReady,
    manifestReady,
    promptInstall,
    downloadOfficialApkIcon,
    topLevelInstallUrl,
    refreshPwaStatus: checkServiceWorkerAndManifest,
  };
}
