export function timeToMinutes(time: string): number {
  if (!time) return 0;
  const [h, m] = time.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function minutesToTime(minutes: number): string {
  const norm = Math.max(0, Math.min(1439, minutes));
  const h = Math.floor(norm / 60);
  const m = norm % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
}

export function formatTime12h(time: string): string {
  if (!time) return '';
  const [hStr, mStr] = time.split(':');
  let h = parseInt(hStr, 10);
  const m = mStr || '00';
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12;
  if (h === 0) h = 12;
  return `${h}:${m} ${ampm}`;
}

export function calculateDurationMinutes(startTime: string, endTime: string): number {
  const start = timeToMinutes(startTime);
  const end = timeToMinutes(endTime);
  if (end >= start) {
    return end - start;
  }
  // Wrap around midnight
  return (1440 - start) + end;
}

export function formatDuration(minutes: number): string {
  if (minutes <= 0) return '0 min';
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

export function isTimeOverlapping(startA: string, endA: string, startB: string, endB: string): boolean {
  const sA = timeToMinutes(startA);
  const eA = timeToMinutes(endA);
  const sB = timeToMinutes(startB);
  const eB = timeToMinutes(endB);

  return sA < eB && sB < eA;
}

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatDateLabel(dateStr: string): string {
  const today = getTodayDateString();
  const [y, m, d] = dateStr.split('-').map(Number);
  const targetDate = new Date(y, m - 1, d);

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = `${tomorrow.getFullYear()}-${String(tomorrow.getMonth() + 1).padStart(2, '0')}-${String(tomorrow.getDate()).padStart(2, '0')}`;

  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;

  const weekday = targetDate.toLocaleDateString(undefined, { weekday: 'short' });
  const monthName = targetDate.toLocaleDateString(undefined, { month: 'short' });

  if (dateStr === today) {
    return `Today (${weekday}, ${monthName} ${d})`;
  } else if (dateStr === tomorrowStr) {
    return `Tomorrow (${weekday}, ${monthName} ${d})`;
  } else if (dateStr === yesterdayStr) {
    return `Yesterday (${weekday}, ${monthName} ${d})`;
  } else {
    return `${weekday}, ${monthName} ${d}`;
  }
}

import { DayOccupancySummary, SleepConfig } from '../types/routine';

export type { DayOccupancySummary };

export function calculateFreeTimeSlots(
  tasks: { startTime: string; endTime: string }[],
  collegeConfig: {
    enabled: boolean;
    startTime: string;
    endTime: string;
    activeDays: number[];
    dayStartHour?: string;
    dayEndHour?: string;
  },
  dateStr: string,
  sleepConfig?: SleepConfig
): DayOccupancySummary {
  const [y, m, d] = dateStr.split('-').map(Number);
  const targetDate = new Date(y, m - 1, d);
  const dayOfWeek = targetDate.getDay();

  let dayStartMin = timeToMinutes(collegeConfig.dayStartHour || '05:30');
  let dayEndMin = timeToMinutes(collegeConfig.dayEndHour || '22:30');
  let sleepMinutes = 0;

  if (sleepConfig && sleepConfig.enabled) {
    dayStartMin = timeToMinutes(sleepConfig.wakeTime || '05:30');
    dayEndMin = timeToMinutes(sleepConfig.bedTime || '22:30');
    sleepMinutes = calculateDurationMinutes(
      sleepConfig.bedTime || '22:30',
      sleepConfig.wakeTime || '05:30'
    );
  }

  const wakingMinutes = Math.max(0, dayEndMin - dayStartMin);

  // Intervals: [start, end]
  const busyIntervals: [number, number][] = [];

  // 1. College hours if active day
  let collegeMinutes = 0;
  if (collegeConfig.enabled && collegeConfig.activeDays.includes(dayOfWeek)) {
    const cStart = timeToMinutes(collegeConfig.startTime);
    const cEnd = timeToMinutes(collegeConfig.endTime);
    busyIntervals.push([cStart, cEnd]);
    collegeMinutes = Math.max(0, cEnd - cStart);
  }

  // 2. All routine tasks
  let routineMinutes = 0;
  tasks.forEach((t) => {
    const s = timeToMinutes(t.startTime);
    const e = timeToMinutes(t.endTime);
    if (e > s) {
      busyIntervals.push([s, e]);
      routineMinutes += (e - s);
    }
  });

  // Sort intervals by start
  busyIntervals.sort((a, b) => a[0] - b[0]);

  // Merge overlapping intervals
  const merged: [number, number][] = [];
  busyIntervals.forEach(([s, e]) => {
    const clampedS = Math.max(dayStartMin, s);
    const clampedE = Math.min(dayEndMin, e);
    if (clampedE <= clampedS) return;

    if (merged.length === 0) {
      merged.push([clampedS, clampedE]);
    } else {
      const prev = merged[merged.length - 1];
      if (clampedS <= prev[1]) {
        prev[1] = Math.max(prev[1], clampedE);
      } else {
        merged.push([clampedS, clampedE]);
      }
    }
  });

  // Find gaps in [dayStartMin, dayEndMin]
  const freeSlots: {
    id: string;
    startTime: string;
    endTime: string;
    durationMinutes: number;
    period: 'morning' | 'afternoon' | 'evening' | 'night';
  }[] = [];

  let pointer = dayStartMin;
  merged.forEach(([start, end], idx) => {
    if (start > pointer) {
      const dur = start - pointer;
      if (dur >= 15) {
        // At least 15 mins to be assignable
        const period =
          pointer < 720
            ? 'morning'
            : pointer < 1020
            ? 'afternoon'
            : pointer < 1260
            ? 'evening'
            : 'night';

        freeSlots.push({
          id: `free-${idx}-${pointer}`,
          startTime: minutesToTime(pointer),
          endTime: minutesToTime(start),
          durationMinutes: dur,
          period,
        });
      }
    }
    pointer = Math.max(pointer, end);
  });

  // Tail gap until dayEndMin
  if (pointer < dayEndMin) {
    const dur = dayEndMin - pointer;
    if (dur >= 15) {
      const period = pointer < 1020 ? 'afternoon' : pointer < 1260 ? 'evening' : 'night';
      freeSlots.push({
        id: `free-tail-${pointer}`,
        startTime: minutesToTime(pointer),
        endTime: minutesToTime(dayEndMin),
        durationMinutes: dur,
        period,
      });
    }
  }

  const freeMinutes = freeSlots.reduce((sum, slot) => sum + slot.durationMinutes, 0);

  return {
    wakingMinutes,
    sleepMinutes,
    collegeMinutes,
    routineMinutes,
    freeMinutes,
    freeSlots,
  };
}

export function getWeekRange(dateStr: string = getTodayDateString()): {
  weekStart: string;
  weekEnd: string;
  label: string;
  formattedRange: string;
} {
  const [y, m, d] = dateStr.split('-').map(Number);
  const target = new Date(y, m - 1, d);
  const day = target.getDay(); // 0 is Sunday, 1 is Monday ... 6 is Saturday
  // Distance to Monday (if day is 0/Sunday, distance is -6 days; if day is 1/Monday, distance is 0)
  const distToMonday = day === 0 ? -6 : 1 - day;

  const monday = new Date(target);
  monday.setDate(target.getDate() + distToMonday);

  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);

  const formatYMD = (date: Date) => {
    const yr = date.getFullYear();
    const mo = String(date.getMonth() + 1).padStart(2, '0');
    const da = String(date.getDate()).padStart(2, '0');
    return `${yr}-${mo}-${da}`;
  };

  const monLabel = monday.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  const sunLabel = sunday.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });

  return {
    weekStart: formatYMD(monday),
    weekEnd: formatYMD(sunday),
    label: `Week of ${monLabel}`,
    formattedRange: `${monLabel} – ${sunLabel}`,
  };
}


