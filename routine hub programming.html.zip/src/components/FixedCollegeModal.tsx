import React, { useState } from 'react';
import {
  X,
  GraduationCap,
  Briefcase,
  Lock,
  Plus,
  Trash2,
  Clock,
  Building,
  Check,
  ShieldCheck,
  Edit3,
} from 'lucide-react';
import { CollegeClassSlot, CollegeConfig, CommitmentType } from '../types/routine';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTime12h,
} from '../utils/dateUtils';
import { Sparkles, Upload } from 'lucide-react';

interface FixedCollegeModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: CollegeConfig;
  onSave: (config: CollegeConfig) => void;
  onOpenUploadModal?: () => void;
}

const DAYS_OF_WEEK = [
  { day: 1, label: 'Mon' },
  { day: 2, label: 'Tue' },
  { day: 3, label: 'Wed' },
  { day: 4, label: 'Thu' },
  { day: 5, label: 'Fri' },
  { day: 6, label: 'Sat' },
  { day: 0, label: 'Sun' },
];

export const FixedCollegeModal: React.FC<FixedCollegeModalProps> = ({
  isOpen,
  onClose,
  config,
  onSave,
  onOpenUploadModal,
}) => {
  const [commitmentType, setCommitmentType] = useState<CommitmentType>(
    config.commitmentType || 'college'
  );
  const [collegeName, setCollegeName] = useState(config.collegeName);
  const [startTime, setStartTime] = useState(config.startTime);
  const [endTime, setEndTime] = useState(config.endTime);
  const [activeDays, setActiveDays] = useState<number[]>(config.activeDays);
  const [slots, setSlots] = useState<CollegeClassSlot[]>(config.slots);

  // Slot form state
  const [editingSlotId, setEditingSlotId] = useState<string | null>(null);
  const [newSlotName, setNewSlotName] = useState('');
  const [newSlotRoom, setNewSlotRoom] = useState('');
  const [newSlotStart, setNewSlotStart] = useState('09:00');
  const [newSlotEnd, setNewSlotEnd] = useState('10:30');
  const [newSlotType, setNewSlotType] = useState<
    'lecture' | 'lab' | 'break' | 'tutorial' | 'meeting' | 'shift' | 'deep_work'
  >('lecture');
  const [showAddSlot, setShowAddSlot] = useState(false);

  if (!isOpen) return null;

  const toggleDay = (day: number) => {
    if (activeDays.includes(day)) {
      if (activeDays.length > 1) {
        setActiveDays(activeDays.filter((d) => d !== day));
      }
    } else {
      setActiveDays([...activeDays, day].sort());
    }
  };

  const handleStartEditSlot = (slot: CollegeClassSlot) => {
    setEditingSlotId(slot.id);
    setNewSlotName(slot.name);
    setNewSlotRoom(slot.room || '');
    setNewSlotStart(slot.startTime);
    setNewSlotEnd(slot.endTime);
    setNewSlotType(slot.type);
    setShowAddSlot(true);
  };

  const handleCancelSlotForm = () => {
    setShowAddSlot(false);
    setEditingSlotId(null);
    setNewSlotName('');
    setNewSlotRoom('');
  };

  const handleSaveSlot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSlotName.trim()) return;

    if (editingSlotId) {
      // Update existing slot
      setSlots(
        slots
          .map((s) =>
            s.id === editingSlotId
              ? {
                  ...s,
                  name: newSlotName.trim(),
                  room: newSlotRoom.trim() || undefined,
                  startTime: newSlotStart,
                  endTime: newSlotEnd,
                  type: newSlotType,
                }
              : s
          )
          .sort((a, b) => a.startTime.localeCompare(b.startTime))
      );
    } else {
      // Add new slot
      const newSlot: CollegeClassSlot = {
        id: `slot-${Date.now()}`,
        name: newSlotName.trim(),
        room: newSlotRoom.trim() || undefined,
        startTime: newSlotStart,
        endTime: newSlotEnd,
        type: newSlotType,
      };

      setSlots([...slots, newSlot].sort((a, b) => a.startTime.localeCompare(b.startTime)));
    }

    handleCancelSlotForm();
  };

  const handleRemoveSlot = (id: string) => {
    setSlots(slots.filter((s) => s.id !== id));
  };

  const handleSave = () => {
    onSave({
      ...config,
      enabled: true,
      commitmentType,
      collegeName: collegeName.trim() || (commitmentType === 'job' ? 'My Workplace' : 'My College'),
      startTime,
      endTime,
      activeDays,
      slots,
    });
    onClose();
  };

  const totalDuration = calculateDurationMinutes(startTime, endTime);
  const isJob = commitmentType === 'job';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-sky-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center border border-sky-500/30">
              {isJob ? <Briefcase className="w-5 h-5" /> : <GraduationCap className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">
                  {isJob ? 'Mandatory Workplace & Job Hours' : 'Fixed College Hours & Timetable'}
                </h3>
                <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  Protected
                </span>
              </div>
              <p className="text-xs text-sky-300/80">
                {isJob
                  ? 'Mandatory work hours are kept separate so your daily routine tracks pure self-upgrade.'
                  : 'College hours are kept separate so your daily routine tracks pure self-upgrade.'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          
          {/* Commitment Type Selector: College vs Job/Work */}
          <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
            <label className="text-xs font-semibold text-slate-300 block">
              Mandatory Schedule Mode:
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setCommitmentType('college')}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                  commitmentType === 'college'
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-600/30 border border-sky-400/40'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                <span>College / University</span>
              </button>
              <button
                type="button"
                onClick={() => setCommitmentType('job')}
                className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                  commitmentType === 'job'
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-600/30 border border-cyan-400/40'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <Briefcase className="w-4 h-4" />
                <span>Job / Workplace</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-500">
              {isJob
                ? 'Protects your day job / workplace shifts without cluttering your daily self-upgrade routine checklist.'
                : 'Protects university lectures and practical labs so your routine focuses strictly on after-college habits.'}
            </p>
          </div>

          {/* AI Timetable PDF/Photo Upload Action Banner */}
          {onOpenUploadModal && (
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-sky-950/80 via-slate-900 to-indigo-950/80 border border-sky-500/40 flex items-center justify-between gap-3 shadow-sm">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0 border border-sky-500/30">
                  <Upload className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                    <span>{isJob ? 'Have a Shift Schedule / Shift Roster?' : 'Have a Timetable PDF or Photo?'}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-sky-500/20 text-sky-300 border border-sky-500/30">
                      AI Auto-Scan
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {isJob
                      ? 'Scan your work shifts schedule to automatically extract hours and meetings.'
                      : 'Scan your college schedule to automatically fill hours, subjects & rooms.'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenUploadModal();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-md transition-all shrink-0 hover:scale-[1.02]"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Upload File</span>
              </button>
            </div>
          )}

          {/* College or Workplace Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1 flex items-center gap-1.5">
              <Building className="w-3.5 h-3.5 text-sky-400" />
              {isJob ? 'Company / Workplace Name' : 'College / Campus Name'}
            </label>
            <input
              type="text"
              value={collegeName}
              onChange={(e) => setCollegeName(e.target.value)}
              placeholder={isJob ? 'e.g. Acme Corp / Tech HQ' : 'e.g. Engineering & Technology Campus'}
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:border-sky-500 transition-colors"
            />
          </div>

          {/* College Start & End Time */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-sky-400" />
                Fixed College Window
              </span>
              <span className="text-xs font-mono text-sky-300 font-semibold">
                Total: {formatDuration(totalDuration)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  College Begins (Start Time)
                </label>
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">
                  College Finishes (End Time)
                </label>
                <input
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Active Days */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              College Operating Days
            </label>
            <div className="flex flex-wrap items-center gap-1.5">
              {DAYS_OF_WEEK.map((d) => {
                const isActive = activeDays.includes(d.day);
                return (
                  <button
                    key={d.day}
                    type="button"
                    onClick={() => toggleDay(d.day)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                      isActive
                        ? 'bg-sky-600 border-sky-400 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {d.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Internal Class Schedule / Timetable Breakdown */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-sky-400" />
                Internal Lectures & Labs ({slots.length})
              </label>
              <button
                type="button"
                onClick={() => setShowAddSlot(!showAddSlot)}
                className="text-xs text-sky-400 hover:text-sky-300 font-medium flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                {showAddSlot ? 'Cancel' : 'Add Period / Class'}
              </button>
            </div>

            {/* Add or Edit Class Form */}
            {showAddSlot && (
              <form
                onSubmit={handleSaveSlot}
                className="p-3.5 rounded-xl bg-slate-950 border border-sky-500/40 space-y-3"
              >
                <div className="text-xs font-bold text-sky-300">
                  {editingSlotId ? 'Edit / Swap College Period' : 'Add New Class / Lecture'}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    value={newSlotName}
                    onChange={(e) => setNewSlotName(e.target.value)}
                    placeholder="Subject Name (e.g. Operating Systems)"
                    className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-500"
                  />
                  <input
                    type="text"
                    value={newSlotRoom}
                    onChange={(e) => setNewSlotRoom(e.target.value)}
                    placeholder="Room/Lab (e.g. Hall 204)"
                    className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-0.5">Start</label>
                    <input
                      type="time"
                      value={newSlotStart}
                      onChange={(e) => setNewSlotStart(e.target.value)}
                      className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-0.5">End</label>
                    <input
                      type="time"
                      value={newSlotEnd}
                      onChange={(e) => setNewSlotEnd(e.target.value)}
                      className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-0.5">Type</label>
                    <select
                      value={newSlotType}
                      onChange={(e) => setNewSlotType(e.target.value as any)}
                      className="w-full px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-white"
                    >
                      <option value="lecture">Lecture</option>
                      <option value="lab">Lab / Practical</option>
                      <option value="meeting">Meeting / Sync</option>
                      <option value="shift">Work Shift</option>
                      <option value="deep_work">Deep Work Block</option>
                      <option value="break">Lunch / Break</option>
                      <option value="tutorial">Tutorial</option>
                    </select>
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleCancelSlotForm}
                    className="px-3 py-1 rounded-lg text-slate-400 hover:text-white text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-3 py-1 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold"
                  >
                    {editingSlotId ? 'Save Changes' : 'Add Period'}
                  </button>
                </div>
              </form>
            )}

            {/* List of Slots */}
            <div className="space-y-2">
              {slots.map((slot) => (
                <div
                  key={slot.id}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs hover:border-slate-700"
                >
                  <div className="min-w-0">
                    <div className="font-semibold text-white truncate">{slot.name}</div>
                    <div className="text-[11px] text-slate-400">
                      {formatTime12h(slot.startTime)} - {formatTime12h(slot.endTime)}
                      {slot.room ? ` • ${slot.room}` : ''}
                      <span className="ml-1.5 px-1.5 py-0.2 rounded bg-slate-800 text-sky-300 uppercase text-[9px] font-bold">
                        {slot.type}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 ml-2">
                    <button
                      type="button"
                      onClick={() => handleStartEditSlot(slot)}
                      className="p-1 rounded text-slate-400 hover:text-sky-300 transition-colors"
                      title="Edit / swap period"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveSlot(slot.id)}
                      className="p-1 rounded text-slate-500 hover:text-rose-400 transition-colors"
                      title="Remove period"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-emerald-400">
            <Check className="w-4 h-4" />
            <span>Fixed hours active on your routine</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-xl text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white shadow-md shadow-sky-600/30 transition-all hover:scale-[1.02]"
            >
              Save College Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
