import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import {
  Plus,
  Mail,
  Lock,
  User,
  Eye,
  EyeOff,
  ArrowLeft,
  CheckCircle2,
  LogOut,
  Sparkles,
  ShieldCheck,
  AlertCircle,
  KeyRound,
  RefreshCw,
  Copy,
  Check,
  ChevronRight,
} from 'lucide-react';
import { UserAccount } from '../types/routine';
import { sounds } from '../utils/audio';

export type AuthModalMode = 'main' | 'google' | 'login' | 'register' | 'reset';

interface AuthSessionModalProps {
  isOpen: boolean;
  initialMode?: AuthModalMode;
  contextReason?: string;
  activeUser: UserAccount | null;
  accounts: UserAccount[];
  onAuthenticated: (user: UserAccount, isNewAccount?: boolean) => void;
  onResetPassword?: (email: string, newPassword: string) => UserAccount | null;
  onSignOut: () => void;
  onContinueAsGuest: () => void;
  soundEnabled?: boolean;
}

const AVATAR_COLORS = [
  'from-cyan-400 to-indigo-600',
  'from-emerald-400 to-teal-600',
  'from-violet-400 to-fuchsia-600',
  'from-amber-400 to-orange-600',
  'from-rose-400 to-pink-600',
];

function pickAvatarColor(seed: string): string {
  let sum = 0;
  for (let i = 0; i < seed.length; i++) {
    sum += seed.charCodeAt(i);
  }
  return AVATAR_COLORS[sum % AVATAR_COLORS.length];
}

function generateSecurityCode(): string {
  const digits = Math.floor(100000 + Math.random() * 900000);
  return `RH-${digits}`;
}

const GoogleLogoSvg: React.FC<{ className?: string }> = ({ className = 'w-4 h-4 shrink-0' }) => (
  <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
    <path
      fill="#EA4335"
      d="M12 5c1.6 0 3 .6 4.1 1.7l3.1-3.1C17.3 1.8 14.8 1 12 1 7.4 1 3.5 3.6 1.6 7.4l3.7 2.8C6.2 7.2 8.9 5 12 5z"
    />
    <path
      fill="#4285F4"
      d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.6l3.7 2.9c2.2-2 3.7-5 3.7-8.7z"
    />
    <path
      fill="#FBBC05"
      d="M5.3 14.8c-.2-.8-.4-1.6-.4-2.5s.2-1.7.4-2.5L1.6 7C.6 9 0 11.2 0 13.5s.6 4.5 1.6 6.5l3.7-2.9z"
    />
    <path
      fill="#34A853"
      d="M12 24c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3.1 0-5.8-2.1-6.7-5l-3.7 2.8C3.5 20.9 7.4 24 12 24z"
    />
  </svg>
);

export const AuthSessionModal: React.FC<AuthSessionModalProps> = ({
  isOpen,
  initialMode = 'main',
  contextReason,
  activeUser,
  accounts,
  onAuthenticated,
  onResetPassword,
  onSignOut,
  onContinueAsGuest,
  soundEnabled = true,
}) => {
  const [mode, setMode] = useState<AuthModalMode>(initialMode);
  const [nameInput, setNameInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [syncEnabled, setSyncEnabled] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Google Login & Account Picker State
  const [googleEmail, setGoogleEmail] = useState('bbiswanath025@gmail.com');
  const [googleName, setGoogleName] = useState('Biswanath');
  const [showCustomGoogleForm, setShowCustomGoogleForm] = useState(false);

  // Password Reset Flow State
  const [resetEmail, setResetEmail] = useState('');
  const [resetStep, setResetStep] = useState<'request' | 'verify'>('request');
  const [generatedCode, setGeneratedCode] = useState('');
  const [inputCode, setInputCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [codeCopied, setCodeCopied] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setErrorMsg(null);
      setSuccessMsg(null);
      setShowCustomGoogleForm(false);
      if (initialMode === 'reset' && activeUser) {
        setResetEmail(activeUser.email);
      }
    }
  }, [isOpen, initialMode, activeUser]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onContinueAsGuest();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onContinueAsGuest]);

  if (!isOpen) return null;

  const triggerHapticAndSound = () => {
    if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
      try {
        navigator.vibrate(10);
      } catch {
        // ignore vibration error
      }
    }
    if (soundEnabled) {
      sounds.playNotificationPing();
    }
  };

  // Build deduplicated list of Google accounts for the 1-tap picker
  const defaultGoogleProfile: UserAccount = {
    id: 'google-primary-biswanath',
    name: 'Biswanath',
    email: 'bbiswanath025@gmail.com',
    provider: 'google',
    avatarColor: pickAvatarColor('bbiswanath025@gmail.com'),
    createdAt: new Date().toISOString(),
    syncEnabled: true,
  };

  const savedGoogleAccounts = accounts.filter((a) => a.provider === 'google');
  const hasDefaultInSaved = savedGoogleAccounts.some(
    (a) => a.email.toLowerCase() === defaultGoogleProfile.email.toLowerCase()
  );
  const googlePickerAccounts: UserAccount[] = hasDefaultInSaved
    ? savedGoogleAccounts
    : [defaultGoogleProfile, ...savedGoogleAccounts];

  const primaryGoogleAccount =
    (activeUser?.provider === 'google' ? activeUser : null) ||
    googlePickerAccounts[0] ||
    defaultGoogleProfile;

  const handleInstantGoogleSignIn = (targetAccount: UserAccount) => {
    setErrorMsg(null);
    setSuccessMsg(null);
    const existing = accounts.find(
      (acc) => acc.email.toLowerCase() === targetAccount.email.toLowerCase()
    );

    triggerHapticAndSound();
    if (existing) {
      onAuthenticated(
        {
          ...existing,
          name: targetAccount.name || existing.name,
          provider: 'google',
        },
        false
      );
    } else {
      const created: UserAccount = {
        ...targetAccount,
        id: `user-${Date.now()}`,
        provider: 'google',
        avatarColor: targetAccount.avatarColor || pickAvatarColor(targetAccount.email),
        createdAt: new Date().toISOString(),
        syncEnabled: true,
      };
      onAuthenticated(created, true);
    }
  };

  const handleGoogleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    const trimmedEmail = googleEmail.trim().toLowerCase();
    const trimmedName =
      googleName.trim() ||
      trimmedEmail
        .split('@')[0]
        .replace(/[._0-9]+/g, ' ')
        .replace(/\b\w/g, (l) => l.toUpperCase()) ||
      'Achiever';

    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setErrorMsg('Please enter a valid Google email address.');
      return;
    }

    const existing = accounts.find(
      (acc) => acc.email.toLowerCase() === trimmedEmail
    );

    if (existing) {
      triggerHapticAndSound();
      onAuthenticated(
        {
          ...existing,
          name: trimmedName || existing.name,
          provider: 'google',
        },
        false
      );
      return;
    }

    const newAccount: UserAccount = {
      id: `user-${Date.now()}`,
      name: trimmedName,
      email: trimmedEmail,
      provider: 'google',
      avatarColor: pickAvatarColor(trimmedEmail),
      createdAt: new Date().toISOString(),
      syncEnabled: true,
    };

    triggerHapticAndSound();
    onAuthenticated(newAccount, true);
  };

  const openPasswordResetForEmail = (prefillEmail?: string) => {
    setErrorMsg(null);
    setSuccessMsg(null);
    const targetEmail = (
      prefillEmail ??
      emailInput ??
      activeUser?.email ??
      accounts[0]?.email ??
      ''
    )
      .trim()
      .toLowerCase();
    setResetEmail(targetEmail);
    setResetStep('request');
    setGeneratedCode('');
    setInputCode('');
    setNewPassword('');
    setConfirmPassword('');
    setMode('reset');
  };

  const handleRequestResetCode = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const trimmedEmail = resetEmail.trim().toLowerCase();
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setErrorMsg('Please enter a valid email address to receive a reset code.');
      return;
    }

    const existing = accounts.find(
      (acc) => acc.email.toLowerCase() === trimmedEmail
    );

    if (
      !existing &&
      trimmedEmail !== defaultGoogleProfile.email.toLowerCase()
    ) {
      setErrorMsg(
        'No account found with this email on this device. You can create a new account or select one of your saved profiles below.'
      );
      return;
    }

    const code = generateSecurityCode();
    setGeneratedCode(code);
    setInputCode(code); // Pre-fill for effortless UX while still showing verification box
    setResetStep('verify');
    triggerHapticAndSound();
  };

  const handleVerifyAndResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const trimmedEmail = resetEmail.trim().toLowerCase();
    const normalizedInputCode = inputCode.trim().toUpperCase();

    if (!normalizedInputCode || normalizedInputCode !== generatedCode.toUpperCase()) {
      setErrorMsg('Invalid verification security code. Click "Auto-Fill Code" above to match.');
      return;
    }

    if (!newPassword || newPassword.length < 4) {
      setErrorMsg('New password must be at least 4 characters long.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setErrorMsg('Passwords do not match. Please verify both password fields.');
      return;
    }

    if (onResetPassword) {
      const updatedUser = onResetPassword(trimmedEmail, newPassword);
      if (updatedUser) {
        triggerHapticAndSound();
        onAuthenticated(updatedUser, false);
        return;
      }
    }

    const existing = accounts.find(
      (acc) => acc.email.toLowerCase() === trimmedEmail
    );

    const updatedAccount: UserAccount = existing
      ? {
          ...existing,
          password: newPassword,
        }
      : {
          ...defaultGoogleProfile,
          id: `user-${Date.now()}`,
          email: trimmedEmail,
          name:
            trimmedEmail === defaultGoogleProfile.email.toLowerCase()
              ? defaultGoogleProfile.name
              : trimmedEmail.split('@')[0],
          password: newPassword,
        };

    triggerHapticAndSound();
    onAuthenticated(updatedAccount, !existing);
  };

  const handleCopyCode = () => {
    if (!generatedCode) return;
    setInputCode(generatedCode);
    setCodeCopied(true);
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(generatedCode).catch(() => {});
    }
    setTimeout(() => setCodeCopied(false), 2000);
  };

  const handleEmailLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const trimmedEmail = emailInput.trim().toLowerCase();
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    if (!passwordInput || passwordInput.length < 4) {
      setErrorMsg('Please enter your password (at least 4 characters).');
      return;
    }

    const existing = accounts.find(
      (acc) => acc.email.toLowerCase() === trimmedEmail
    );

    if (!existing) {
      setErrorMsg(
        'No account found with this email yet. Click "+ Create new account" below to register.'
      );
      return;
    }

    if (existing.password && existing.password !== passwordInput) {
      setErrorMsg('Incorrect password. Please try again or click "Forgot password?" to reset it.');
      return;
    }

    // If account was originally created via Google without a password, save this password now
    const authenticatedUser: UserAccount = existing.password
      ? existing
      : { ...existing, password: passwordInput };

    triggerHapticAndSound();
    onAuthenticated(authenticatedUser, false);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const trimmedName = nameInput.trim();
    const trimmedEmail = emailInput.trim().toLowerCase();

    if (!trimmedName) {
      setErrorMsg('Please enter your name so we can personalize your dashboard.');
      return;
    }
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    if (!passwordInput || passwordInput.length < 4) {
      setErrorMsg('Please create a password with at least 4 characters.');
      return;
    }

    const existing = accounts.find(
      (acc) => acc.email.toLowerCase() === trimmedEmail
    );

    if (existing) {
      const updatedAccount: UserAccount = {
        ...existing,
        name: trimmedName,
        password: passwordInput,
        syncEnabled,
      };
      triggerHapticAndSound();
      onAuthenticated(updatedAccount, false);
      return;
    }

    const newAccount: UserAccount = {
      id: `user-${Date.now()}`,
      name: trimmedName,
      email: trimmedEmail,
      provider: 'email',
      avatarColor: pickAvatarColor(trimmedEmail),
      createdAt: new Date().toISOString(),
      password: passwordInput,
      syncEnabled,
    };

    triggerHapticAndSound();
    onAuthenticated(newAccount, true);
  };

  const passwordStrength =
    newPassword.length === 0
      ? 0
      : newPassword.length < 4
      ? 1
      : newPassword.length < 8
      ? 2
      : 3;

  const content = (
    <div className="fixed inset-0 z-[120] flex flex-col justify-between bg-[#040711]/95 backdrop-blur-2xl overflow-y-auto animate-fadeIn select-none">
      {/* Ambient Mobile Aurora Background Orbs */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed -top-28 -left-20 w-80 h-80 rounded-full bg-cyan-500/20 blur-[100px] aurora-orb-float"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none fixed top-1/3 -right-24 w-96 h-96 rounded-full bg-violet-500/20 blur-[110px] aurora-orb-float-delayed"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none fixed -bottom-28 left-1/4 w-80 h-80 rounded-full bg-emerald-500/15 blur-[95px] aurora-orb-float"
      />

      {/* Top Navigation Bar */}
      <div className="relative z-10 w-full border-b border-white/10 bg-slate-950/60 backdrop-blur-xl px-4 sm:px-8 py-3.5 flex items-center justify-between">
        <button
          type="button"
          onClick={onContinueAsGuest}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 via-cyan-400 to-indigo-600 p-0.5 shadow-[0_0_16px_rgba(34,211,238,0.35)]">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <span className="font-luxury-mono text-[10px] font-bold text-amber-300">
                &gt;_
              </span>
            </div>
          </div>
          <span className="font-sans text-base sm:text-lg font-extrabold tracking-tight text-white">
            RoutineHub<span className="text-amber-400">.me</span>
          </span>
        </button>

        <div className="flex items-center gap-2">
          {activeUser && (
            <span className="hidden sm:inline-flex items-center gap-1.5 text-xs text-emerald-300 font-luxury-mono px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-400/30">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              Signed in as {activeUser.name}
            </span>
          )}
          <button
            type="button"
            onClick={onContinueAsGuest}
            className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-cyan-500/15 border border-white/10 hover:border-cyan-400/40 text-xs font-semibold text-slate-300 hover:text-cyan-200 transition-all cursor-pointer"
          >
            {activeUser ? 'Back to Dashboard' : 'Continue as Guest'}
          </button>
        </div>
      </div>

      {/* Main Centered Window Card */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 py-6 sm:py-10">
        <div className="relative w-full max-w-[92vw] sm:w-[440px] sm:max-w-[440px] group">
          {/* Outer Aurora Rim Glow */}
          <div
            aria-hidden="true"
            className="absolute -inset-1 rounded-[28px] bg-gradient-to-b from-cyan-500/25 via-violet-500/20 to-amber-500/20 blur-xl opacity-80 group-hover:opacity-100 transition duration-500 pointer-events-none"
          />

          {/* Terminal Session Card Container */}
          <div className="relative rounded-[24px] aurora-hero-surface bg-[#0a0f1d]/95 border border-cyan-500/30 shadow-[0_24px_60px_rgba(0,0,0,0.85)] overflow-hidden">
            {/* Window Top Bar: Traffic Light Dots + AUTH_SESSION.PY */}
            <div className="px-4 py-3 border-b border-white/10 bg-slate-950/70 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onContinueAsGuest}
                  title="Close & return to dashboard"
                  aria-label="Close login window"
                  className="w-3 h-3 rounded-full bg-[#ff5f56] hover:brightness-110 transition-transform active:scale-90 cursor-pointer shadow-[0_0_6px_rgba(255,95,86,0.6)]"
                />
                <button
                  type="button"
                  onClick={() => {
                    setErrorMsg(null);
                    setSuccessMsg(null);
                    setMode('main');
                  }}
                  title="Reset view"
                  aria-label="Reset view"
                  className="w-3 h-3 rounded-full bg-[#ffbd2e] hover:brightness-110 transition-transform active:scale-90 cursor-pointer shadow-[0_0_6px_rgba(255,189,46,0.6)]"
                />
                <button
                  type="button"
                  onClick={() => {
                    setErrorMsg(null);
                    setSuccessMsg(null);
                    setMode('register');
                  }}
                  title="Create new account"
                  aria-label="Create new account"
                  className="w-3 h-3 rounded-full bg-[#27c93f] hover:brightness-110 transition-transform active:scale-90 cursor-pointer shadow-[0_0_6px_rgba(39,201,63,0.6)]"
                />
              </div>

              <span className="font-luxury-mono text-[11px] tracking-widest text-slate-400 uppercase">
                AUTH_SESSION.PY
              </span>
            </div>

            {/* Card Content Body */}
            <div className="p-6 sm:p-7 space-y-5">
              {/* Contextual Action Banner when triggered by Assign Task, Add College Timetable, Work and Job */}
              {contextReason && (
                <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/20 via-cyan-500/15 to-violet-500/20 border border-amber-400/50 shadow-[0_0_20px_rgba(251,191,36,0.18)] flex items-start gap-3 text-left animate-fadeIn">
                  <div className="w-9 h-9 rounded-xl bg-amber-400/20 border border-amber-400/40 text-amber-300 flex items-center justify-center shrink-0 mt-0.5">
                    <ShieldCheck className="w-5 h-5 text-amber-300" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-xs font-black uppercase tracking-wide text-amber-300">
                        Sign In Required:
                      </span>
                      <span className="text-xs font-extrabold text-white">
                        {contextReason}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
                      Please sign in with Google or Email to save, customize, and sync your{' '}
                      <span className="text-cyan-300 font-semibold">{contextReason}</span> across devices.
                    </p>
                  </div>
                </div>
              )}

              {/* ===============================================================
                  MODE 1: MAIN INITIALIZE LOGIN VIEW
                 =============================================================== */}
              {mode === 'main' && (
                <>
                  <div className="text-center space-y-1.5">
                    <h1 className="font-sans text-2xl sm:text-3xl font-black tracking-tight text-white">
                      {contextReason ? (
                        <>
                          Sign In for{' '}
                          <span className="bg-gradient-to-r from-amber-300 via-yellow-400 to-cyan-300 bg-clip-text text-transparent">
                            {contextReason}
                          </span>
                        </>
                      ) : (
                        <>
                          Initialize{' '}
                          <span className="bg-gradient-to-r from-amber-300 via-yellow-400 to-cyan-300 bg-clip-text text-transparent">
                            Login
                          </span>
                        </>
                      )}
                    </h1>
                    <p className="font-luxury-mono text-xs text-slate-400">
                      One-Tap Google Sign-In, Email Login &amp; Password Recovery
                    </p>
                  </div>

                  {/* Active Profile Banner with Quick Password Reset & Sign Out */}
                  {activeUser && (
                    <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-400/35 space-y-3">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div
                            className={`w-9 h-9 rounded-xl bg-gradient-to-br ${activeUser.avatarColor} flex items-center justify-center text-white font-bold text-xs shrink-0 shadow-md`}
                          >
                            {activeUser.name.slice(0, 2).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <div className="text-xs font-bold text-white truncate flex items-center gap-1.5">
                              <span>{activeUser.name}</span>
                              <span className="text-[10px] font-luxury-mono text-emerald-300">
                                · Active
                              </span>
                            </div>
                            <div className="text-[11px] font-luxury-mono text-slate-300 truncate">
                              {activeUser.email}
                            </div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={onSignOut}
                          className="px-2.5 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-400/30 text-[11px] font-semibold text-rose-200 flex items-center gap-1 shrink-0 cursor-pointer transition-colors"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>Sign Out</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-2 pt-1 border-t border-white/10">
                        <button
                          type="button"
                          onClick={() => openPasswordResetForEmail(activeUser.email)}
                          className="flex-1 py-1.5 px-3 rounded-xl bg-slate-900/90 hover:bg-cyan-500/15 border border-white/10 hover:border-cyan-400/40 text-[11px] font-semibold text-cyan-200 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                        >
                          <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Change / Reset Password</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setMode('google')}
                          className="py-1.5 px-3 rounded-xl bg-slate-900/90 hover:bg-amber-500/15 border border-white/10 hover:border-amber-400/40 text-[11px] font-semibold text-amber-200 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                        >
                          <GoogleLogoSvg className="w-3.5 h-3.5" />
                          <span>Switch</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* ONE-TAP GOOGLE SIGN-IN CARD */}
                  <div className="rounded-2xl bg-slate-900/90 border border-amber-400/35 p-3.5 space-y-2.5 shadow-[0_0_25px_rgba(251,191,36,0.12)]">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <GoogleLogoSvg className="w-4 h-4" />
                        <span className="text-[11px] font-bold text-slate-200 tracking-wide">
                          Sign in with Google
                        </span>
                      </div>
                      <span className="text-[10px] font-luxury-mono text-amber-300">
                        1-Tap Instant Sync
                      </span>
                    </div>

                    {/* One-Tap Primary Account Button */}
                    <button
                      type="button"
                      onClick={() => handleInstantGoogleSignIn(primaryGoogleAccount)}
                      style={{ touchAction: 'manipulation' }}
                      className="w-full p-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-300 hover:from-amber-300 hover:to-yellow-200 text-slate-950 flex items-center justify-between gap-3 shadow-[0_0_20px_rgba(251,191,36,0.3)] active:scale-[0.98] transition-all cursor-pointer group/gbtn"
                    >
                      <div className="flex items-center gap-2.5 min-w-0 text-left">
                        <div className="w-9 h-9 rounded-lg bg-slate-950 text-amber-300 font-extrabold text-xs flex items-center justify-center shrink-0 border border-slate-800">
                          {primaryGoogleAccount.name.slice(0, 2).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs sm:text-sm font-black text-slate-950 truncate">
                            Continue as {primaryGoogleAccount.name}
                          </div>
                          <div className="text-[11px] font-medium text-slate-800 truncate">
                            {primaryGoogleAccount.email}
                          </div>
                        </div>
                      </div>
                      <div className="w-7 h-7 rounded-lg bg-slate-950/15 flex items-center justify-center shrink-0 group-hover/gbtn:translate-x-0.5 transition-transform">
                        <ChevronRight className="w-4 h-4 text-slate-950 stroke-[2.5]" />
                      </div>
                    </button>

                    {/* Choose another Google account trigger */}
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMsg(null);
                        setMode('google');
                      }}
                      className="w-full py-1.5 text-[11px] font-semibold text-amber-300/90 hover:text-amber-200 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <span>Choose another Google account or email</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Secondary Auth Actions */}
                  <div className="space-y-2.5">
                    {/* Email & Password Login Button */}
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMsg(null);
                        setMode('login');
                      }}
                      style={{ touchAction: 'manipulation' }}
                      className="w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-400/30 hover:border-cyan-400/60 text-cyan-200 hover:text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
                    >
                      <Mail className="w-4 h-4 text-cyan-400" />
                      <span>Email &amp; Password Login</span>
                    </button>

                    <div className="grid grid-cols-2 gap-2.5">
                      {/* + Create new account Button */}
                      <button
                        type="button"
                        onClick={() => {
                          setErrorMsg(null);
                          setMode('register');
                        }}
                        style={{ touchAction: 'manipulation' }}
                        className="min-h-[44px] px-3 py-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800/90 border border-white/15 hover:border-emerald-400/50 text-slate-200 hover:text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5 text-emerald-400 stroke-[2.5] shrink-0" />
                        <span className="truncate">Create Account</span>
                      </button>

                      {/* Direct Password Reset Button */}
                      <button
                        type="button"
                        onClick={() => openPasswordResetForEmail()}
                        style={{ touchAction: 'manipulation' }}
                        className="min-h-[44px] px-3 py-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800/90 border border-white/15 hover:border-violet-400/50 text-slate-200 hover:text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] cursor-pointer"
                      >
                        <KeyRound className="w-3.5 h-3.5 text-violet-400 shrink-0" />
                        <span className="truncate">Reset Password</span>
                      </button>
                    </div>
                  </div>

                  {/* Quick Switcher for Saved Accounts on Device */}
                  {accounts.length > 0 && (
                    <div className="pt-1 space-y-2">
                      <div className="text-[11px] font-luxury-mono text-slate-400 flex items-center justify-between">
                        <span>Saved profiles on this device</span>
                        <span className="text-cyan-400">{accounts.length}</span>
                      </div>
                      <div className="space-y-1.5 max-h-32 overflow-y-auto pr-1">
                        {accounts.map((acc) => {
                          const isCurrent = activeUser?.id === acc.id;
                          return (
                            <div
                              key={acc.id}
                              className={`flex items-center justify-between gap-2 p-2 rounded-xl border transition-all ${
                                isCurrent
                                  ? 'bg-cyan-500/15 border-cyan-400/50'
                                  : 'bg-slate-900/70 border-white/10 hover:border-cyan-400/30'
                              }`}
                            >
                              <button
                                type="button"
                                onClick={() => {
                                  triggerHapticAndSound();
                                  onAuthenticated(acc, false);
                                }}
                                className="flex items-center gap-2.5 min-w-0 flex-1 text-left cursor-pointer"
                              >
                                <div
                                  className={`w-8 h-8 rounded-lg bg-gradient-to-br ${acc.avatarColor} flex items-center justify-center text-white font-bold text-xs shrink-0`}
                                >
                                  {acc.name.slice(0, 2).toUpperCase()}
                                </div>
                                <div className="min-w-0">
                                  <div className="text-xs font-bold text-white truncate flex items-center gap-1.5">
                                    <span>{acc.name}</span>
                                    {isCurrent && (
                                      <span className="text-[10px] font-luxury-mono text-emerald-400">
                                        (Active)
                                      </span>
                                    )}
                                  </div>
                                  <div className="text-[10px] font-luxury-mono text-slate-400 truncate">
                                    {acc.email} · {acc.provider}
                                  </div>
                                </div>
                              </button>

                              <div className="flex items-center gap-1 shrink-0">
                                <button
                                  type="button"
                                  onClick={() => openPasswordResetForEmail(acc.email)}
                                  title="Reset password for this account"
                                  className="px-2 py-1 rounded-lg bg-white/5 hover:bg-violet-500/20 border border-white/10 hover:border-violet-400/40 text-[10px] font-semibold text-slate-300 hover:text-violet-200 flex items-center gap-1 cursor-pointer transition-colors"
                                >
                                  <KeyRound className="w-3 h-3 text-violet-400" />
                                  <span>Reset</span>
                                </button>
                                {isCurrent && (
                                  <button
                                    type="button"
                                    onClick={onSignOut}
                                    title="Sign out of this account"
                                    className="px-2 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 border border-rose-400/30 text-[10px] font-semibold text-rose-300 flex items-center gap-1 cursor-pointer"
                                  >
                                    <LogOut className="w-3 h-3" />
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* EOF Divider */}
                  <div className="flex items-center gap-3 pt-1">
                    <div className="h-px flex-1 bg-white/10" />
                    <span className="font-luxury-mono text-[10px] uppercase tracking-widest text-slate-500">
                      EOF
                    </span>
                    <div className="h-px flex-1 bg-white/10" />
                  </div>

                  {/* Footer Status Text */}
                  <p className="text-center font-luxury-mono text-[11px] italic text-slate-400">
                    &ldquo;Mobile Aurora routine sync &amp; account storage ready...&rdquo;
                  </p>
                </>
              )}

              {/* ===============================================================
                  MODE 2: GOOGLE SIGN-IN & ONE-TAP ACCOUNT PICKER
                 =============================================================== */}
              {mode === 'google' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMsg(null);
                        setMode('main');
                      }}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Back</span>
                    </button>
                    <span className="font-luxury-mono text-[10px] text-amber-300 uppercase flex items-center gap-1.5">
                      <GoogleLogoSvg className="w-3.5 h-3.5" />
                      <span>Google Identity</span>
                    </span>
                  </div>

                  <div className="text-center space-y-1">
                    <h2 className="font-sans text-xl font-extrabold text-white">
                      Choose an{' '}
                      <span className="text-amber-300">Account</span>
                    </h2>
                    <p className="text-xs text-slate-400">
                      One-tap Google sign-in to sync RoutineHub.me
                    </p>
                  </div>

                  {/* 1-Tap Google Account Picker List */}
                  <div className="space-y-2">
                    <span className="text-[11px] font-luxury-mono text-slate-400">
                      Select a Google profile for instant login:
                    </span>
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {googlePickerAccounts.map((acc) => {
                        const isCurrent =
                          activeUser?.email.toLowerCase() === acc.email.toLowerCase();
                        return (
                          <button
                            key={acc.id}
                            type="button"
                            onClick={() => handleInstantGoogleSignIn(acc)}
                            className={`w-full p-3 rounded-xl border flex items-center justify-between transition-all cursor-pointer text-left ${
                              isCurrent
                                ? 'bg-amber-400/15 border-amber-400/50 shadow-[0_0_15px_rgba(251,191,36,0.15)]'
                                : 'bg-slate-900/90 hover:bg-amber-400/10 border-white/10 hover:border-amber-400/40'
                            }`}
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <div
                                className={`w-9 h-9 rounded-xl bg-gradient-to-br ${acc.avatarColor} flex items-center justify-center text-white font-bold text-xs shrink-0 relative`}
                              >
                                {acc.name.slice(0, 2).toUpperCase()}
                                <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-slate-950 border border-white/20 flex items-center justify-center">
                                  <GoogleLogoSvg className="w-2.5 h-2.5" />
                                </span>
                              </div>
                              <div className="min-w-0">
                                <div className="text-xs font-bold text-white truncate flex items-center gap-1.5">
                                  <span>{acc.name}</span>
                                  {isCurrent && (
                                    <span className="text-[10px] font-luxury-mono text-emerald-300">
                                      · Signed In
                                    </span>
                                  )}
                                </div>
                                <div className="text-[11px] font-luxury-mono text-slate-400 truncate">
                                  {acc.email}
                                </div>
                              </div>
                            </div>
                            <span className="text-[11px] font-bold text-amber-300 shrink-0 flex items-center gap-1">
                              <span>Continue</span>
                              <ChevronRight className="w-3.5 h-3.5" />
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Toggle / Expand Custom Google Account Input */}
                  {!showCustomGoogleForm ? (
                    <button
                      type="button"
                      onClick={() => setShowCustomGoogleForm(true)}
                      className="w-full py-2.5 px-4 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-white/10 hover:border-amber-400/40 text-xs font-semibold text-slate-200 hover:text-amber-200 flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <Plus className="w-4 h-4 text-amber-400" />
                      <span>Use another Google account</span>
                    </button>
                  ) : (
                    <form
                      onSubmit={handleGoogleSubmit}
                      className="p-3.5 rounded-2xl bg-slate-900/80 border border-amber-400/30 space-y-3 animate-fadeIn"
                    >
                      <div className="text-xs font-bold text-amber-300 flex items-center justify-between">
                        <span>Add Google Account</span>
                        <button
                          type="button"
                          onClick={() => setShowCustomGoogleForm(false)}
                          className="text-[11px] text-slate-400 hover:text-white cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>

                      {errorMsg && (
                        <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                          <span>{errorMsg}</span>
                        </div>
                      )}

                      <div className="space-y-2.5">
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                            Display Name
                          </label>
                          <div className="relative">
                            <User className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                            <input
                              type="text"
                              value={googleName}
                              onChange={(e) => setGoogleName(e.target.value)}
                              placeholder="Your name (e.g. Biswanath)"
                              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-white/15 focus:border-amber-400 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                            Google Email Address
                          </label>
                          <div className="relative">
                            <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                            <input
                              type="email"
                              value={googleEmail}
                              onChange={(e) => setGoogleEmail(e.target.value)}
                              placeholder="name@gmail.com"
                              required
                              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-white/15 focus:border-amber-400 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none"
                            />
                          </div>
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-300 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-extrabold text-xs uppercase tracking-wide flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(251,191,36,0.3)] active:scale-[0.98] transition-all cursor-pointer"
                      >
                        <ShieldCheck className="w-4 h-4" />
                        <span>Sign in with Google</span>
                      </button>
                    </form>
                  )}
                </div>
              )}

              {/* ===============================================================
                  MODE 3: EMAIL & PASSWORD LOGIN VIEW
                 =============================================================== */}
              {mode === 'login' && (
                <form onSubmit={handleEmailLoginSubmit} className="space-y-4">
                  <div className="flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMsg(null);
                        setMode('main');
                      }}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Back</span>
                    </button>
                    <span className="font-luxury-mono text-[10px] text-cyan-300 uppercase">
                      Email Authentication
                    </span>
                  </div>

                  <div className="text-center space-y-1">
                    <h2 className="font-sans text-xl font-extrabold text-white">
                      Email{' '}
                      <span className="bg-gradient-to-r from-cyan-300 to-violet-300 bg-clip-text text-transparent">
                        Sign In
                      </span>
                    </h2>
                    <p className="text-xs text-slate-400">
                      Enter your registered email and password
                    </p>
                  </div>

                  {errorMsg && (
                    <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/40 text-xs text-rose-200 space-y-2">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                        <span>{errorMsg}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => openPasswordResetForEmail(emailInput)}
                        className="w-full py-1.5 px-3 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/30 text-[11px] font-bold text-rose-100 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                      >
                        <KeyRound className="w-3.5 h-3.5" />
                        <span>Reset Password Now</span>
                      </button>
                    </div>
                  )}

                  <div className="space-y-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="email"
                          value={emailInput}
                          onChange={(e) => setEmailInput(e.target.value)}
                          placeholder="you@example.com"
                          required
                          className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-white/15 focus:border-cyan-400 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[11px] font-semibold text-slate-300">
                          Password
                        </label>
                        <button
                          type="button"
                          onClick={() => openPasswordResetForEmail(emailInput)}
                          className="text-[11px] font-semibold text-amber-300 hover:text-amber-200 transition-colors cursor-pointer flex items-center gap-1"
                        >
                          <KeyRound className="w-3 h-3" />
                          <span>Forgot password?</span>
                        </button>
                      </div>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type={showPassword ? 'text' : 'password'}
                          value={passwordInput}
                          onChange={(e) => setPasswordInput(e.target.value)}
                          placeholder="Enter your password"
                          required
                          className="w-full pl-9 pr-10 py-2.5 rounded-xl bg-slate-900 border border-white/15 focus:border-cyan-400 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword((prev) => !prev)}
                          aria-label={showPassword ? 'Hide password' : 'Show password'}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white cursor-pointer"
                        >
                          {showPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-500 to-indigo-600 text-slate-950 font-extrabold text-xs sm:text-sm uppercase tracking-wide flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(34,211,238,0.35)] active:scale-[0.98] transition-all cursor-pointer"
                  >
                    <span>Sign In to RoutineHub</span>
                  </button>

                  <div className="flex items-center justify-between pt-1 text-xs">
                    <button
                      type="button"
                      onClick={() => openPasswordResetForEmail(emailInput)}
                      className="text-slate-400 hover:text-amber-300 font-semibold cursor-pointer"
                    >
                      Reset password
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMsg(null);
                        setMode('register');
                      }}
                      className="text-cyan-300 hover:text-cyan-200 font-semibold cursor-pointer"
                    >
                      + Create new account
                    </button>
                  </div>
                </form>
              )}

              {/* ===============================================================
                  MODE 4: + CREATE NEW ACCOUNT VIEW
                 =============================================================== */}
              {mode === 'register' && (
                <form onSubmit={handleRegisterSubmit} className="space-y-4">
                  <div className="flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMsg(null);
                        setMode('main');
                      }}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Back</span>
                    </button>
                    <span className="font-luxury-mono text-[10px] text-emerald-400 uppercase">
                      New Profile Setup
                    </span>
                  </div>

                  <div className="text-center space-y-1">
                    <h2 className="font-sans text-xl font-extrabold text-white">
                      Create{' '}
                      <span className="bg-gradient-to-r from-emerald-300 via-cyan-300 to-violet-300 bg-clip-text text-transparent">
                        New Account
                      </span>
                    </h2>
                    <p className="text-xs text-slate-400">
                      Save your daily routine, timetable &amp; 80% streak profile
                    </p>
                  </div>

                  {errorMsg && (
                    <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  <div className="space-y-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                        Full Name
                      </label>
                      <div className="relative">
                        <User className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={nameInput}
                          onChange={(e) => setNameInput(e.target.value)}
                          placeholder="e.g. Biswanath"
                          required
                          className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-white/15 focus:border-emerald-400 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="email"
                          value={emailInput}
                          onChange={(e) => setEmailInput(e.target.value)}
                          placeholder="you@example.com"
                          required
                          className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-white/15 focus:border-emerald-400 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                        Create Password
                      </label>
                      <div className="relative">
                        <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          type={showPassword ? 'text' : 'password'}
                          value={passwordInput}
                          onChange={(e) => setPasswordInput(e.target.value)}
                          placeholder="At least 4 characters"
                          required
                          className="w-full pl-9 pr-10 py-2.5 rounded-xl bg-slate-900 border border-white/15 focus:border-emerald-400 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword((prev) => !prev)}
                          aria-label={showPassword ? 'Hide password' : 'Show password'}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white cursor-pointer"
                        >
                          {showPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    </div>

                    <label className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/80 border border-white/10 cursor-pointer">
                      <span className="text-xs text-slate-300 flex items-center gap-2">
                        <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Auto-save routine snapshot to profile</span>
                      </span>
                      <input
                        type="checkbox"
                        checked={syncEnabled}
                        onChange={(e) => setSyncEnabled(e.target.checked)}
                        className="w-4 h-4 accent-cyan-400 rounded cursor-pointer"
                      />
                    </label>
                  </div>

                  <button
                    type="submit"
                    className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-indigo-500 text-slate-950 font-extrabold text-xs sm:text-sm uppercase tracking-wide flex items-center justify-center gap-2 shadow-[0_0_22px_rgba(16,185,129,0.35)] active:scale-[0.98] transition-all cursor-pointer"
                  >
                    <Plus className="w-4 h-4 stroke-[2.5]" />
                    <span>Create Account &amp; Launch</span>
                  </button>

                  <div className="text-center pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMsg(null);
                        setMode('login');
                      }}
                      className="text-xs text-slate-400 hover:text-cyan-300 font-semibold cursor-pointer"
                    >
                      Already have an account? Sign in with Email
                    </button>
                  </div>
                </form>
              )}

              {/* ===============================================================
                  MODE 5: IN-APP PASSWORD RESET & RECOVERY FLOW
                 =============================================================== */}
              {mode === 'reset' && (
                <div className="space-y-4 animate-fadeIn">
                  <div className="flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => {
                        setErrorMsg(null);
                        setSuccessMsg(null);
                        setMode('login');
                      }}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Back to Login</span>
                    </button>
                    <span className="font-luxury-mono text-[10px] text-violet-300 uppercase flex items-center gap-1">
                      <KeyRound className="w-3 h-3 text-violet-400" />
                      <span>Password Recovery</span>
                    </span>
                  </div>

                  <div className="text-center space-y-1">
                    <h2 className="font-sans text-xl font-extrabold text-white">
                      Reset{' '}
                      <span className="bg-gradient-to-r from-violet-300 via-cyan-300 to-emerald-300 bg-clip-text text-transparent">
                        Password
                      </span>
                    </h2>
                    <p className="text-xs text-slate-400">
                      {resetStep === 'request'
                        ? 'Generate an in-app security code to reset your password'
                        : 'Verify your security code and set a new password'}
                    </p>
                  </div>

                  {errorMsg && (
                    <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      <span>{errorMsg}</span>
                    </div>
                  )}

                  {successMsg && (
                    <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-xs text-emerald-200 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{successMsg}</span>
                    </div>
                  )}

                  {resetStep === 'request' ? (
                    <form onSubmit={handleRequestResetCode} className="space-y-4">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Account Email Address
                        </label>
                        <div className="relative">
                          <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type="email"
                            value={resetEmail}
                            onChange={(e) => setResetEmail(e.target.value)}
                            placeholder="Enter your account email"
                            required
                            className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-white/15 focus:border-violet-400 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none"
                          />
                        </div>
                      </div>

                      {/* Quick-select saved accounts on device */}
                      {accounts.length > 0 && (
                        <div className="space-y-1.5">
                          <span className="text-[11px] font-luxury-mono text-slate-400">
                            Or tap a saved account on this device:
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {accounts.map((acc) => (
                              <button
                                key={acc.id}
                                type="button"
                                onClick={() => {
                                  setResetEmail(acc.email);
                                  setErrorMsg(null);
                                }}
                                className={`px-2.5 py-1.5 rounded-lg text-[11px] font-luxury-mono border transition-all cursor-pointer ${
                                  resetEmail.toLowerCase() === acc.email.toLowerCase()
                                    ? 'bg-violet-500/20 border-violet-400 text-violet-200'
                                    : 'bg-slate-900 border-white/10 text-slate-300 hover:border-violet-400/40'
                                }`}
                              >
                                {acc.email}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      <button
                        type="submit"
                        className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-gradient-to-r from-violet-500 via-cyan-400 to-emerald-400 text-slate-950 font-extrabold text-xs sm:text-sm uppercase tracking-wide flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(139,92,246,0.35)] active:scale-[0.98] transition-all cursor-pointer"
                      >
                        <KeyRound className="w-4 h-4" />
                        <span>Generate In-App Reset Code</span>
                      </button>
                    </form>
                  ) : (
                    <form onSubmit={handleVerifyAndResetPassword} className="space-y-3.5">
                      {/* In-App Security Code Display Box */}
                      <div className="p-3 rounded-2xl bg-violet-500/15 border border-violet-400/40 space-y-2">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-semibold text-violet-200 flex items-center gap-1.5">
                            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                            <span>In-App Security Reset Code</span>
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              const fresh = generateSecurityCode();
                              setGeneratedCode(fresh);
                              setInputCode(fresh);
                            }}
                            className="text-slate-300 hover:text-white inline-flex items-center gap-1 cursor-pointer"
                            title="Generate new code"
                          >
                            <RefreshCw className="w-3 h-3" />
                            <span>New code</span>
                          </button>
                        </div>

                        <div className="flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-950/90 border border-white/10">
                          <span className="font-luxury-mono text-base font-black tracking-widest text-amber-300 pl-1">
                            {generatedCode}
                          </span>
                          <button
                            type="button"
                            onClick={handleCopyCode}
                            className="px-2.5 py-1 rounded-lg bg-violet-500/25 hover:bg-violet-500/35 border border-violet-400/40 text-[11px] font-semibold text-violet-100 flex items-center gap-1 cursor-pointer transition-colors"
                          >
                            {codeCopied ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-400" />
                                <span>Auto-Filled</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Copy &amp; Auto-Fill</span>
                              </>
                            )}
                          </button>
                        </div>
                        <div className="text-[10px] font-luxury-mono text-slate-300 truncate">
                          Account: <span className="text-cyan-300">{resetEmail}</span>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Verification Code
                        </label>
                        <input
                          type="text"
                          value={inputCode}
                          onChange={(e) => setInputCode(e.target.value)}
                          placeholder="RH-XXXXXX"
                          required
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-white/15 focus:border-violet-400 font-luxury-mono text-xs text-white uppercase tracking-wider focus:outline-none"
                        />
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="block text-[11px] font-semibold text-slate-300">
                            New Password
                          </label>
                          {newPassword.length > 0 && (
                            <span
                              className={`text-[10px] font-luxury-mono ${
                                passwordStrength === 1
                                  ? 'text-rose-400'
                                  : passwordStrength === 2
                                  ? 'text-amber-300'
                                  : 'text-emerald-400'
                              }`}
                            >
                              {passwordStrength === 1
                                ? 'Too short'
                                : passwordStrength === 2
                                ? 'Good strength'
                                : 'Strong password'}
                            </span>
                          )}
                        </div>
                        <div className="relative">
                          <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type={showPassword ? 'text' : 'password'}
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            placeholder="At least 4 characters"
                            required
                            className="w-full pl-9 pr-10 py-2 rounded-xl bg-slate-900 border border-white/15 focus:border-emerald-400 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword((prev) => !prev)}
                            aria-label={showPassword ? 'Hide password' : 'Show password'}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white cursor-pointer"
                          >
                            {showPassword ? (
                              <EyeOff className="w-4 h-4" />
                            ) : (
                              <Eye className="w-4 h-4" />
                            )}
                          </button>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Confirm New Password
                        </label>
                        <div className="relative">
                          <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                          <input
                            type={showPassword ? 'text' : 'password'}
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            placeholder="Re-enter new password"
                            required
                            className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-white/15 focus:border-emerald-400 text-base sm:text-xs text-white placeholder-slate-500 focus:outline-none"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-violet-500 text-slate-950 font-extrabold text-xs sm:text-sm uppercase tracking-wide flex items-center justify-center gap-2 shadow-[0_0_22px_rgba(16,185,129,0.35)] active:scale-[0.98] transition-all cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
                        <span>Update Password &amp; Sign In</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setResetStep('request')}
                        className="w-full text-center text-[11px] text-slate-400 hover:text-cyan-300 cursor-pointer"
                      >
                        Change email address
                      </button>
                    </form>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Return Link matching Screenshot: "cd .. / back to site" */}
        <button
          type="button"
          onClick={onContinueAsGuest}
          className="mt-6 font-luxury-mono text-xs sm:text-sm text-slate-400 hover:text-white transition-colors flex items-center gap-2 cursor-pointer py-2 px-4 rounded-xl hover:bg-white/5"
        >
          <span className="text-cyan-400 font-bold">cd</span>
          <span className="text-white font-bold">..</span>
          <span className="text-slate-500">/</span>
          <span>{activeUser ? 'back to dashboard' : 'continue to site'}</span>
        </button>
      </div>
    </div>
  );

  return typeof document !== 'undefined'
    ? createPortal(content, document.body)
    : content;
};
