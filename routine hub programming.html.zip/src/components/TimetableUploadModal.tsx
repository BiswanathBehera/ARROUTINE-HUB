import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Upload,
  FileText,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  GraduationCap,
  Briefcase,
  Trash2,
  Plus,
  RefreshCw,
  Camera,
  FileCheck,
  Zap,
  ShieldCheck,
  ClipboardPaste,
} from 'lucide-react';
import { CollegeClassSlot, CollegeConfig, CommitmentType } from '../types/routine';
import {
  calculateDurationMinutes,
  formatTime12h,
} from '../utils/dateUtils';
import { sounds } from '../utils/audio';

interface TimetableUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  collegeConfig: CollegeConfig;
  onApplyTimetable: (updatedConfig: CollegeConfig) => void;
}

type SlotType = CollegeClassSlot['type'];

interface ExtractedSlot {
  id: string;
  day: number; // 1=Mon .. 6=Sat, 0=Sun
  dayName: string;
  name: string;
  startTime: string;
  endTime: string;
  room?: string;
  professor?: string;
  type: SlotType;
  selected: boolean;
}

const WEEKDAYS = [
  { day: 1, name: 'Monday', short: 'Mon' },
  { day: 2, name: 'Tuesday', short: 'Tue' },
  { day: 3, name: 'Wednesday', short: 'Wed' },
  { day: 4, name: 'Thursday', short: 'Thu' },
  { day: 5, name: 'Friday', short: 'Fri' },
  { day: 6, name: 'Saturday', short: 'Sat' },
];

const VALID_SLOT_TYPES: SlotType[] = [
  'lecture',
  'lab',
  'tutorial',
  'break',
  'shift',
  'meeting',
  'deep_work',
];

// Client-side instant cache for repeat file scans
const clientScanCache = new Map<string, any>();

// Sample College Timetable
const SAMPLE_COLLEGE_DATA = {
  scheduleType: 'college' as CommitmentType,
  collegeName: 'National Institute of Engineering',
  overallStartTime: '09:00',
  overallEndTime: '16:30',
  activeDays: [1, 2, 3, 4, 5],
  slots: [
    { day: 1, dayName: 'Monday', name: 'Data Structures & Algorithms', startTime: '09:00', endTime: '10:30', room: 'Hall 302', professor: 'Dr. Sharma', type: 'lecture' },
    { day: 1, dayName: 'Monday', name: 'Computer Architecture', startTime: '10:45', endTime: '12:15', room: 'Hall 305', professor: 'Prof. Miller', type: 'lecture' },
    { day: 1, dayName: 'Monday', name: 'Lunch Break', startTime: '12:15', endTime: '13:15', room: 'Cafeteria', professor: '', type: 'break' },
    { day: 1, dayName: 'Monday', name: 'DSA Laboratory & Coding', startTime: '13:15', endTime: '15:15', room: 'CS Lab 2', professor: 'Dr. Sharma', type: 'lab' },
    { day: 2, dayName: 'Tuesday', name: 'Operating Systems', startTime: '09:00', endTime: '10:30', room: 'Hall 201', professor: 'Dr. Jenkins', type: 'lecture' },
    { day: 2, dayName: 'Tuesday', name: 'Discrete Mathematics', startTime: '10:45', endTime: '12:15', room: 'Hall 104', professor: 'Prof. Roy', type: 'lecture' },
    { day: 2, dayName: 'Tuesday', name: 'Lunch Break', startTime: '12:15', endTime: '13:15', room: 'Cafeteria', professor: '', type: 'break' },
    { day: 2, dayName: 'Tuesday', name: 'OS Systems Kernel Lab', startTime: '13:15', endTime: '15:15', room: 'Linux Lab', professor: 'Dr. Jenkins', type: 'lab' },
    { day: 3, dayName: 'Wednesday', name: 'Database Management Systems', startTime: '09:00', endTime: '10:30', room: 'Hall 302', professor: 'Dr. Anita Desai', type: 'lecture' },
    { day: 3, dayName: 'Wednesday', name: 'Computer Networks', startTime: '10:45', endTime: '12:15', room: 'Hall 202', professor: 'Prof. Kumar', type: 'lecture' },
    { day: 3, dayName: 'Wednesday', name: 'Lunch Break', startTime: '12:15', endTime: '13:15', room: 'Cafeteria', professor: '', type: 'break' },
    { day: 3, dayName: 'Wednesday', name: 'DBMS SQL & NoSQL Lab', startTime: '13:15', endTime: '15:15', room: 'Database Lab', professor: 'Dr. Anita Desai', type: 'lab' },
    { day: 4, dayName: 'Thursday', name: 'Software Engineering & Agile', startTime: '09:30', endTime: '11:00', room: 'Hall 304', professor: 'Dr. Wright', type: 'lecture' },
    { day: 4, dayName: 'Thursday', name: 'Linear Algebra & Statistics', startTime: '11:15', endTime: '12:45', room: 'Hall 102', professor: 'Prof. Vance', type: 'lecture' },
    { day: 4, dayName: 'Thursday', name: 'Lunch Break', startTime: '12:45', endTime: '13:30', room: 'Cafeteria', professor: '', type: 'break' },
    { day: 4, dayName: 'Thursday', name: 'Web Engineering Tutorial', startTime: '13:30', endTime: '15:00', room: 'Hall 105', professor: 'Prof. Vance', type: 'tutorial' },
    { day: 5, dayName: 'Friday', name: 'Theory of Computation', startTime: '09:00', endTime: '10:30', room: 'Hall 302', professor: 'Dr. Roy', type: 'lecture' },
    { day: 5, dayName: 'Friday', name: 'Computer Networks Practical Lab', startTime: '10:45', endTime: '12:45', room: 'Network Lab', professor: 'Prof. Kumar', type: 'lab' },
    { day: 5, dayName: 'Friday', name: 'Lunch Break', startTime: '12:45', endTime: '13:45', room: 'Cafeteria', professor: '', type: 'break' },
    { day: 5, dayName: 'Friday', name: 'Seminar & Project Work', startTime: '13:45', endTime: '15:30', room: 'Seminar Hall', professor: 'Faculty Panel', type: 'tutorial' },
  ],
};

// Sample Work / Job Shift Schedule
const SAMPLE_WORK_DATA = {
  scheduleType: 'job' as CommitmentType,
  collegeName: 'Apex Cloud Systems HQ',
  overallStartTime: '09:30',
  overallEndTime: '17:30',
  activeDays: [1, 2, 3, 4, 5],
  slots: [
    { day: 1, dayName: 'Monday', name: 'Morning Standup & Sprint Triage', startTime: '09:30', endTime: '10:15', room: 'War Room B / Zoom', professor: 'Sarah Chen (Lead)', type: 'meeting' },
    { day: 1, dayName: 'Monday', name: 'Core Backend Feature Shift', startTime: '10:15', endTime: '13:00', room: 'Floor 4 Desk 12', professor: 'Platform Team', type: 'deep_work' },
    { day: 1, dayName: 'Monday', name: 'Team Lunch & Recharge', startTime: '13:00', endTime: '14:00', room: 'Bistro Lounge', professor: '', type: 'break' },
    { day: 1, dayName: 'Monday', name: 'API Architecture & PR Reviews', startTime: '14:00', endTime: '17:30', room: 'Floor 4 Desk 12', professor: 'Sarah Chen (Lead)', type: 'shift' },
    { day: 2, dayName: 'Tuesday', name: 'Daily Engineering Sync', startTime: '09:30', endTime: '10:00', room: 'Room 204', professor: 'Sarah Chen (Lead)', type: 'meeting' },
    { day: 2, dayName: 'Tuesday', name: 'Production Microservices Shift', startTime: '10:00', endTime: '13:00', room: 'Floor 4 Desk 12', professor: 'Core Eng', type: 'deep_work' },
    { day: 2, dayName: 'Tuesday', name: 'Midday Break', startTime: '13:00', endTime: '14:00', room: 'Cafeteria', professor: '', type: 'break' },
    { day: 2, dayName: 'Tuesday', name: 'Client Integration & QA Shift', startTime: '14:00', endTime: '17:30', room: 'Lab Bay 3', professor: 'David Ross (PM)', type: 'shift' },
    { day: 3, dayName: 'Wednesday', name: 'Product & Design Huddle', startTime: '09:30', endTime: '10:30', room: 'Boardroom A', professor: 'David Ross (PM)', type: 'meeting' },
    { day: 3, dayName: 'Wednesday', name: 'Deep Work: System Optimization', startTime: '10:30', endTime: '13:00', room: 'Quiet Zone', professor: 'Platform Team', type: 'deep_work' },
    { day: 3, dayName: 'Wednesday', name: 'Lunch Break', startTime: '13:00', endTime: '14:00', room: 'Cafeteria', professor: '', type: 'break' },
    { day: 3, dayName: 'Wednesday', name: 'Deployment & Monitoring Shift', startTime: '14:00', endTime: '17:30', room: 'Ops Center', professor: 'DevOps Lead', type: 'shift' },
    { day: 4, dayName: 'Thursday', name: 'Morning Standup', startTime: '09:30', endTime: '10:00', room: 'Zoom', professor: 'Sarah Chen (Lead)', type: 'meeting' },
    { day: 4, dayName: 'Thursday', name: 'Feature Development Block', startTime: '10:00', endTime: '13:00', room: 'Floor 4 Desk 12', professor: 'Platform Team', type: 'deep_work' },
    { day: 4, dayName: 'Thursday', name: 'Lunch Break', startTime: '13:00', endTime: '14:00', room: 'Cafeteria', professor: '', type: 'break' },
    { day: 4, dayName: 'Thursday', name: 'Cross-Team Architecture Sync', startTime: '14:00', endTime: '15:30', room: 'Conf Room C', professor: 'VP Engineering', type: 'meeting' },
    { day: 4, dayName: 'Thursday', name: 'Codebase Refactoring Shift', startTime: '15:30', endTime: '17:30', room: 'Floor 4 Desk 12', professor: 'Platform Team', type: 'shift' },
    { day: 5, dayName: 'Friday', name: 'Sprint Demo & Retrospective', startTime: '09:30', endTime: '11:00', room: 'Main Auditorium', professor: 'Sarah Chen (Lead)', type: 'meeting' },
    { day: 5, dayName: 'Friday', name: 'Bug Bash & Documentation Shift', startTime: '11:00', endTime: '13:00', room: 'Floor 4 Desk 12', professor: 'QA Lead', type: 'shift' },
    { day: 5, dayName: 'Friday', name: 'Team Lunch', startTime: '13:00', endTime: '14:00', room: 'Roof Terrace', professor: '', type: 'break' },
    { day: 5, dayName: 'Friday', name: 'Next Week Planning & Wrap-up', startTime: '14:00', endTime: '16:30', room: 'Floor 4 Desk 12', professor: 'Sarah Chen (Lead)', type: 'deep_work' },
  ],
};

// Ultra-Fast Turbo Client-Side Optimizer:
// Downscales large 15MB camera photos to crisp 1280px JPEGs at 0.80 quality in <80ms.
// Reduces payload size by ~97% so upload + Gemini Flash-Lite vision inference finishes in 1-3 seconds.
const optimizeImageForFastAnalysis = async (
  file: File
): Promise<{ base64: string; previewUrl: string; optimizedMime: string; compressionRatio: number }> => {
  return new Promise((resolve, reject) => {
    const isImage = file.type.startsWith('image/');
    if (!isImage) {
      const reader = new FileReader();
      reader.onload = () =>
        resolve({
          base64: reader.result as string,
          previewUrl: '',
          optimizedMime: file.type || 'application/pdf',
          compressionRatio: 0,
        });
      reader.onerror = reject;
      reader.readAsDataURL(file);
      return;
    }

    const objectUrl = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      const maxDim = 1280; // 1280px is optimal for Gemini 3.1 Flash-Lite Vision speed & OCR accuracy
      let { width, height } = img;
      if (width > maxDim || height > maxDim) {
        if (width > height) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        const fallbackReader = new FileReader();
        fallbackReader.onload = () =>
          resolve({
            base64: fallbackReader.result as string,
            previewUrl: fallbackReader.result as string,
            optimizedMime: file.type,
            compressionRatio: 0,
          });
        fallbackReader.readAsDataURL(file);
        return;
      }

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);
      const compressedBase64 = canvas.toDataURL('image/jpeg', 0.8);
      const approxBytes = Math.round((compressedBase64.length * 3) / 4);
      const savedPct =
        file.size > approxBytes ? Math.round(((file.size - approxBytes) / file.size) * 100) : 0;

      resolve({
        base64: compressedBase64,
        previewUrl: compressedBase64,
        optimizedMime: 'image/jpeg',
        compressionRatio: savedPct,
      });
    };
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      const fallbackReader = new FileReader();
      fallbackReader.onload = () =>
        resolve({
          base64: fallbackReader.result as string,
          previewUrl: fallbackReader.result as string,
          optimizedMime: file.type,
          compressionRatio: 0,
        });
      fallbackReader.onerror = reject;
      fallbackReader.readAsDataURL(file);
    };
    img.src = objectUrl;
  });
};

export const TimetableUploadModal: React.FC<TimetableUploadModalProps> = ({
  isOpen,
  onClose,
  collegeConfig,
  onApplyTimetable,
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileBase64, setFileBase64] = useState<string | null>(null);
  const [optimizedMime, setOptimizedMime] = useState<string>('image/jpeg');
  const [compressionRatio, setCompressionRatio] = useState<number>(0);
  const [filePreviewUrl, setFilePreviewUrl] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisStatus, setAnalysisStatus] = useState<string>('');
  const [elapsedMs, setElapsedMs] = useState<number>(0);
  const [lastScanDurationMs, setLastScanDurationMs] = useState<number | null>(null);
  const [wasCachedScan, setWasCachedScan] = useState<boolean>(false);
  const [autoAnalyze, setAutoAnalyze] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Review step state
  const [step, setStep] = useState<'upload' | 'review'>('upload');
  const [extractedScheduleType, setExtractedScheduleType] = useState<CommitmentType>(
    collegeConfig.commitmentType || 'college'
  );
  const [extractedCollegeName, setExtractedCollegeName] = useState(
    collegeConfig.collegeName || 'My College'
  );
  const [extractedStartTime, setExtractedStartTime] = useState(
    collegeConfig.startTime || '09:00'
  );
  const [extractedEndTime, setExtractedEndTime] = useState(
    collegeConfig.endTime || '16:30'
  );
  const [extractedActiveDays, setExtractedActiveDays] = useState<number[]>(
    collegeConfig.activeDays || [1, 2, 3, 4, 5]
  );
  const [extractedSlots, setExtractedSlots] = useState<ExtractedSlot[]>([]);
  const [reviewDayTab, setReviewDayTab] = useState<number>(1);
  const [replaceExisting, setReplaceExisting] = useState(true);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const isJobMode = extractedScheduleType === 'job';

  const processExtractedResult = (
    data: {
      scheduleType?: CommitmentType | string;
      collegeName?: string;
      overallStartTime?: string;
      overallEndTime?: string;
      activeDays?: number[];
      slots?: any[];
      durationMs?: number;
      cached?: boolean;
    },
    measuredMs?: number
  ) => {
    const detectedType: CommitmentType =
      data.scheduleType === 'job' || data.scheduleType === 'work' ? 'job' : 'college';
    setExtractedScheduleType(detectedType);

    if (data.collegeName && data.collegeName.trim()) {
      setExtractedCollegeName(data.collegeName.trim());
    } else {
      setExtractedCollegeName(detectedType === 'job' ? 'My Workplace' : 'My College');
    }

    if (data.overallStartTime) {
      setExtractedStartTime(data.overallStartTime);
    }
    if (data.overallEndTime) {
      setExtractedEndTime(data.overallEndTime);
    }
    if (data.activeDays && Array.isArray(data.activeDays) && data.activeDays.length > 0) {
      const sorted = [...data.activeDays].sort();
      setExtractedActiveDays(sorted);
      setReviewDayTab(sorted[0]);
    }

    const formattedSlots: ExtractedSlot[] = (data.slots || []).map(
      (slot: any, idx: number) => {
        const rawDay = Number(slot.day) || 1;
        const validDay = rawDay >= 0 && rawDay <= 6 ? rawDay : 1;
        const dayObj = WEEKDAYS.find((w) => w.day === validDay);
        const normalizedType: SlotType = VALID_SLOT_TYPES.includes(slot.type)
          ? slot.type
          : detectedType === 'job'
          ? 'shift'
          : 'lecture';

        return {
          id: `ext-${Date.now()}-${idx}-${Math.random().toString(36).substr(2, 4)}`,
          day: validDay,
          dayName: slot.dayName || dayObj?.name || 'Monday',
          name: slot.name || (detectedType === 'job' ? 'Work Shift' : 'Lecture'),
          startTime: slot.startTime || '09:00',
          endTime: slot.endTime || '10:00',
          room: slot.room || undefined,
          professor: slot.professor || undefined,
          type: normalizedType,
          selected: true,
        };
      }
    );

    setLastScanDurationMs(measuredMs ?? data.durationMs ?? null);
    setWasCachedScan(Boolean(data.cached));
    setExtractedSlots(formattedSlots);
    setStep('review');
    sounds.playComplete();
  };

  const runTurboAnalysis = async (
    base64Data: string,
    fileObj: File,
    mimeOverride?: string
  ) => {
    const cacheKey = `${fileObj.name}:${fileObj.size}:${fileObj.lastModified}`;
    if (clientScanCache.has(cacheKey)) {
      const cached = clientScanCache.get(cacheKey);
      processExtractedResult({ ...cached, cached: true }, 15);
      return;
    }

    setIsAnalyzing(true);
    setErrorMessage(null);
    setAnalysisStatus('Turbo Flash-Lite engine scanning schedule...');
    setElapsedMs(0);
    const startTimestamp = Date.now();
    const intervalTimer = setInterval(() => {
      setElapsedMs(Date.now() - startTimestamp);
    }, 80);

    const statusTimer1 = setTimeout(() => {
      setAnalysisStatus('Auto-detecting College Timetable vs Work Schedule...');
    }, 350);

    const statusTimer2 = setTimeout(() => {
      setAnalysisStatus('Extracting slots, 24h timings & locations...');
    }, 900);

    try {
      const response = await fetch('/api/parse-timetable', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          data: base64Data,
          mimeType: mimeOverride || fileObj.type,
          filename: fileObj.name,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${response.status}`);
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.error || 'Failed to parse schedule.');
      }

      if (!result.slots || result.slots.length === 0) {
        throw new Error(
          'No classes or work shifts could be detected in this document. Please ensure the schedule photo or PDF is clearly visible.'
        );
      }

      const totalElapsed = Date.now() - startTimestamp;
      clientScanCache.set(cacheKey, result);
      processExtractedResult(result, totalElapsed);
    } catch (err: any) {
      console.error('Schedule turbo analysis failed:', err);
      setErrorMessage(
        err.message || 'Error parsing schedule. Please check your image/PDF or try another file.'
      );
    } finally {
      clearInterval(intervalTimer);
      clearTimeout(statusTimer1);
      clearTimeout(statusTimer2);
      setIsAnalyzing(false);
      setAnalysisStatus('');
    }
  };

  const handleFileChange = async (file: File) => {
    setErrorMessage(null);
    setSelectedFile(file);

    const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
    const isImage = file.type.startsWith('image/');

    if (!isPdf && !isImage) {
      setErrorMessage(
        'Please select a valid image file (PNG, JPG, WEBP) or a PDF schedule document.'
      );
      return;
    }

    try {
      setAnalysisStatus('Optimizing document for Turbo Scan...');
      const { base64, previewUrl, optimizedMime: optMime, compressionRatio: ratio } =
        await optimizeImageForFastAnalysis(file);
      setFileBase64(base64);
      setOptimizedMime(optMime);
      setCompressionRatio(ratio);
      setFilePreviewUrl(previewUrl || null);

      // Instant Auto-Analyze as soon as file is selected/dropped/pasted
      if (autoAnalyze) {
        await runTurboAnalysis(base64, file, optMime);
      }
    } catch {
      setErrorMessage('Failed to read the file. Please try selecting it again.');
    }
  };

  // Support Ctrl+V / Cmd+V clipboard paste for instant screenshot scanning
  useEffect(() => {
    if (!isOpen || step !== 'upload') return;

    const handlePaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        if (item.type.startsWith('image/') || item.type === 'application/pdf') {
          const pastedFile = item.getAsFile();
          if (pastedFile) {
            e.preventDefault();
            handleFileChange(pastedFile);
            break;
          }
        }
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, [isOpen, step, autoAnalyze]);

  if (!isOpen) return null;

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const handleStartAnalysis = async () => {
    if (!fileBase64 || !selectedFile) {
      setErrorMessage('Please select a timetable or work schedule image/PDF first.');
      return;
    }
    await runTurboAnalysis(fileBase64, selectedFile, optimizedMime);
  };

  const handleLoadSample = (sampleType: 'college' | 'job') => {
    setErrorMessage(null);
    processExtractedResult(
      sampleType === 'job' ? SAMPLE_WORK_DATA : SAMPLE_COLLEGE_DATA,
      120
    );
  };

  const handleToggleDayActive = (day: number) => {
    if (extractedActiveDays.includes(day)) {
      if (extractedActiveDays.length > 1) {
        setExtractedActiveDays(extractedActiveDays.filter((d) => d !== day));
      }
    } else {
      setExtractedActiveDays([...extractedActiveDays, day].sort());
    }
  };

  const handleToggleSlotSelect = (id: string) => {
    setExtractedSlots((prev) =>
      prev.map((s) => (s.id === id ? { ...s, selected: !s.selected } : s))
    );
  };

  const handleDeleteSlot = (id: string) => {
    setExtractedSlots((prev) => prev.filter((s) => s.id !== id));
  };

  const handleAddCustomSlot = (day: number) => {
    const newSlot: ExtractedSlot = {
      id: `manual-${Date.now()}`,
      day,
      dayName: WEEKDAYS.find((w) => w.day === day)?.name || 'Monday',
      name: isJobMode ? 'New Work Shift / Meeting' : 'New Class',
      startTime: '10:00',
      endTime: '11:15',
      room: '',
      professor: '',
      type: isJobMode ? 'shift' : 'lecture',
      selected: true,
    };
    setExtractedSlots((prev) => [...prev, newSlot]);
  };

  const handleApply = () => {
    const selectedSlots = extractedSlots.filter((s) => s.selected);

    // Group by day of week
    const weeklyMap: Record<number, CollegeClassSlot[]> = {};
    WEEKDAYS.forEach((w) => {
      weeklyMap[w.day] = [];
    });

    // If merging, preserve existing days
    if (!replaceExisting && collegeConfig.weeklyTimetable) {
      Object.keys(collegeConfig.weeklyTimetable).forEach((dStr) => {
        const d = Number(dStr);
        weeklyMap[d] = [...(collegeConfig.weeklyTimetable![d] || [])];
      });
    }

    selectedSlots.forEach((slot) => {
      const classSlot: CollegeClassSlot = {
        id: slot.id,
        name: slot.name,
        room: slot.room || undefined,
        professor: slot.professor || undefined,
        startTime: slot.startTime,
        endTime: slot.endTime,
        type: slot.type,
        dayOfWeek: slot.day,
      };

      if (!weeklyMap[slot.day]) {
        weeklyMap[slot.day] = [];
      }
      weeklyMap[slot.day].push(classSlot);
    });

    // Sort each day's slots by startTime
    Object.keys(weeklyMap).forEach((dStr) => {
      const d = Number(dStr);
      weeklyMap[d].sort((a, b) => a.startTime.localeCompare(b.startTime));
    });

    // Determine default slots (from Monday or first active day)
    const firstActive = extractedActiveDays[0] || 1;
    const defaultSlots = weeklyMap[firstActive] || selectedSlots.slice(0, 5);

    const updatedConfig: CollegeConfig = {
      ...collegeConfig,
      enabled: true,
      commitmentType: extractedScheduleType,
      collegeName:
        extractedCollegeName.trim() ||
        (extractedScheduleType === 'job' ? 'My Workplace' : 'My College'),
      startTime: extractedStartTime,
      endTime: extractedEndTime,
      activeDays: extractedActiveDays,
      slots: defaultSlots,
      weeklyTimetable: weeklyMap,
    };

    onApplyTimetable(updatedConfig);
    sounds.playComplete();
    onClose();
  };

  const filteredSlotsForTab = extractedSlots.filter((s) => s.day === reviewDayTab);
  const totalSelectedCount = extractedSlots.filter((s) => s.selected).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-6 flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-gradient-to-r from-sky-950/70 via-slate-900 to-indigo-950/70 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-sky-500/20 shrink-0">
              {isJobMode ? (
                <Briefcase className="w-5 h-5" />
              ) : (
                <GraduationCap className="w-5 h-5" />
              )}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-base font-bold text-white tracking-tight">
                  Turbo Scan: College Timetable & Work Schedule (PDF / Photo)
                </h3>
                <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  <Zap className="w-3 h-3 text-amber-400" />
                  1–3s Flash-Lite Turbo
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Drop, select, or paste (Ctrl+V) any College Timetable or Work/Job Shift Schedule for instant AI extraction.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
          {step === 'upload' ? (
            /* STEP 1: File Upload & Instant Auto-Scan */
            <div className="space-y-4">
              {/* Top Mode Bar: Instant Auto-Analyze Toggle + Clipboard Paste Hint */}
              <div className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl bg-slate-950/90 border border-slate-800">
                <div className="flex items-center gap-2 text-xs text-slate-300">
                  <Zap className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="font-semibold text-white">Ultra-Fast Turbo Mode:</span>
                  <span className="text-slate-400 hidden sm:inline">
                    Auto-compresses photos (~97% smaller) & scans immediately on select
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => setAutoAnalyze(!autoAnalyze)}
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-all ${
                    autoAnalyze
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-slate-900 text-slate-400 border-slate-700'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      autoAnalyze ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'
                    }`}
                  />
                  <span>Instant Auto-Scan: {autoAnalyze ? 'ON' : 'OFF'}</span>
                </button>
              </div>

              {/* Live Loading Overlay (shown immediately when auto-analyzing) */}
              {isAnalyzing && (
                <div className="p-5 rounded-2xl bg-gradient-to-r from-sky-950/80 via-slate-900 to-indigo-950/80 border border-sky-500/50 text-center space-y-3 animate-fadeIn shadow-lg">
                  <div className="flex items-center justify-center gap-2">
                    <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-sky-500/20 text-sky-400 animate-spin">
                      <RefreshCw className="w-5 h-5" />
                    </div>
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold font-mono">
                      <Zap className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                      {(elapsedMs / 1000).toFixed(1)}s elapsed
                    </span>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center justify-center gap-2">
                      <span>Turbo-Scanning Schedule Document</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold border border-amber-400/30">
                        Flash-Lite Minimal Thinking
                      </span>
                    </h4>
                    <p className="text-xs text-sky-300 font-mono mt-1">
                      {analysisStatus || 'Extracting classes, work shifts & timings...'}
                    </p>
                    {compressionRatio > 0 && (
                      <p className="text-[11px] text-emerald-400 mt-1 font-medium">
                        Optimized image payload ({compressionRatio}% smaller) for 1–3s extraction
                      </p>
                    )}
                  </div>
                  <div className="w-56 mx-auto bg-slate-900 h-2 rounded-full overflow-hidden p-0.5 border border-slate-800">
                    <div className="h-full bg-gradient-to-r from-amber-400 via-sky-400 to-indigo-500 animate-pulse w-full rounded-full" />
                  </div>
                </div>
              )}

              {/* Drag and Drop Zone */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragOver(true);
                }}
                onDragLeave={() => setIsDragOver(false)}
                onDrop={handleDrop}
                onClick={() => !isAnalyzing && fileInputRef.current?.click()}
                className={`relative border-2 border-dashed rounded-2xl p-6 sm:p-7 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-3 ${
                  isDragOver
                    ? 'border-sky-400 bg-sky-950/40 scale-[1.01]'
                    : selectedFile
                    ? 'border-emerald-500/50 bg-slate-950/80 hover:border-emerald-400'
                    : 'border-slate-700 bg-slate-950/60 hover:border-sky-500/60 hover:bg-slate-950'
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={(e) => e.target.files?.[0] && handleFileChange(e.target.files[0])}
                  accept="image/*,.pdf,application/pdf"
                  className="hidden"
                />

                <input
                  type="file"
                  ref={cameraInputRef}
                  onChange={(e) => e.target.files?.[0] && handleFileChange(e.target.files[0])}
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                />

                {selectedFile ? (
                  <div className="flex flex-col items-center gap-2">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
                      {selectedFile.type === 'application/pdf' ||
                      selectedFile.name.toLowerCase().endsWith('.pdf') ? (
                        <FileText className="w-6 h-6" />
                      ) : (
                        <FileCheck className="w-6 h-6" />
                      )}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white max-w-sm truncate">
                        {selectedFile.name}
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                        {compressionRatio > 0
                          ? ` • Compressed ${compressionRatio}% for Turbo Scan`
                          : ' • Ready for Turbo AI extraction'}
                      </p>
                    </div>
                    <span className="text-[11px] text-sky-400 hover:underline mt-0.5 font-medium">
                      Click to choose another PDF or photo
                    </span>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-2">
                      <div className="w-12 h-12 rounded-2xl bg-sky-500/15 border border-sky-500/30 text-sky-400 flex items-center justify-center shadow-inner">
                        <Upload className="w-6 h-6" />
                      </div>
                      <div className="w-12 h-12 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 text-indigo-400 flex items-center justify-center shadow-inner">
                        <Briefcase className="w-6 h-6" />
                      </div>
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">
                        Drop or Click to Select College Timetable or Work / Job Schedule
                      </h4>
                      <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                        Automatically starts analyzing the moment you pick a PDF, photo, or paste a screenshot with <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 font-mono text-[10px]">Ctrl+V</kbd>.
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                      <span className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-sky-300 font-medium">
                        🎓 College Timetables
                      </span>
                      <span className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-cyan-300 font-medium">
                        💼 Work / Shift Rosters
                      </span>
                      <span className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 font-mono">
                        PDF / JPG / PNG / WEBP
                      </span>
                    </div>
                  </>
                )}
              </div>

              {/* Action Buttons: Camera Capture + Sample College & Work Loaders */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => cameraInputRef.current?.click()}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 font-medium transition-colors"
                  >
                    <Camera className="w-3.5 h-3.5 text-sky-400" />
                    <span>Camera Snapshot</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleLoadSample('college')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-950/60 hover:bg-sky-900/60 border border-sky-500/30 text-xs text-sky-300 font-medium transition-colors"
                    title="Instant test with a sample college class timetable"
                  >
                    <GraduationCap className="w-3.5 h-3.5 text-sky-400" />
                    <span>Sample College Timetable</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleLoadSample('job')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-500/30 text-xs text-cyan-300 font-medium transition-colors"
                    title="Instant test with a sample work / job shift schedule"
                  >
                    <Briefcase className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Sample Work Schedule</span>
                  </button>
                </div>

                {selectedFile && (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedFile(null);
                      setFileBase64(null);
                      setFilePreviewUrl(null);
                    }}
                    className="text-xs text-slate-400 hover:text-rose-400 transition-colors"
                  >
                    Remove File
                  </button>
                )}
              </div>

              {/* Image Preview Thumbnail if available */}
              {filePreviewUrl && !isAnalyzing && (
                <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 space-y-2">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Document Preview:
                  </span>
                  <div className="relative rounded-lg overflow-hidden max-h-48 border border-slate-800 flex items-center justify-center bg-slate-900">
                    <img
                      src={filePreviewUrl}
                      alt="Schedule Preview"
                      className="object-contain max-h-48 w-auto mx-auto"
                    />
                  </div>
                </div>
              )}

              {/* Error message */}
              {errorMessage && (
                <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200 flex items-start gap-2.5 animate-fadeIn">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-semibold block">Extraction Issue:</strong>
                    <span>{errorMessage}</span>
                  </div>
                </div>
              )}

              {/* Dual-Mode Capabilities Card */}
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-2 text-xs">
                <span className="font-bold text-slate-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Auto-Detects Both College Timetables & Work / Job Schedules:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="p-2.5 rounded-lg bg-slate-900/70 border border-slate-800">
                    <div className="font-semibold text-sky-300 flex items-center gap-1.5 mb-1">
                      <GraduationCap className="w-3.5 h-3.5" />
                      <span>College & University Mode</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Extracts lectures, coding/science labs, tutorials, room numbers, professors & lunch breaks.
                    </p>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900/70 border border-slate-800">
                    <div className="font-semibold text-cyan-300 flex items-center gap-1.5 mb-1">
                      <Briefcase className="w-3.5 h-3.5" />
                      <span>Work & Job Shift Mode</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Extracts work shifts, standups/meetings, deep work blocks, office/desk locations & team leads.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* STEP 2: Review & Edit Extracted Schedule */
            <div className="space-y-5 animate-fadeIn">
              {/* Auto-Detected Schedule Type & Speed Banner */}
              <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-sky-950/60 border border-emerald-500/30">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    Auto-Detected:
                  </span>
                  <div className="inline-flex items-center p-0.5 rounded-lg bg-slate-950 border border-slate-800">
                    <button
                      type="button"
                      onClick={() => setExtractedScheduleType('college')}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold transition-all ${
                        !isJobMode
                          ? 'bg-sky-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <GraduationCap className="w-3.5 h-3.5" />
                      <span>College Timetable</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setExtractedScheduleType('job')}
                      className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold transition-all ${
                        isJobMode
                          ? 'bg-cyan-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      <Briefcase className="w-3.5 h-3.5" />
                      <span>Work / Job Schedule</span>
                    </button>
                  </div>
                </div>

                {lastScanDurationMs !== null && (
                  <span className="inline-flex items-center gap-1 text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                    <Zap className="w-3 h-3 text-amber-400" />
                    {wasCachedScan
                      ? 'Instant Cache (<0.05s)'
                      : `Scanned in ${(lastScanDurationMs / 1000).toFixed(1)}s`}
                  </span>
                )}
              </div>

              {/* Overview & Settings Header */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
                  <div>
                    <span className="text-[10px] font-bold text-sky-400 uppercase tracking-wider block">
                      {isJobMode ? 'Recognized Company / Workplace' : 'Recognized Institution / College'}
                    </span>
                    <input
                      type="text"
                      value={extractedCollegeName}
                      onChange={(e) => setExtractedCollegeName(e.target.value)}
                      placeholder={isJobMode ? 'Company or Workplace Name' : 'College Name'}
                      className="text-base font-bold text-white bg-transparent border-b border-dashed border-slate-600 focus:border-sky-400 focus:outline-none pb-0.5 mt-0.5 w-full sm:w-80"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">
                      {isJobMode ? 'Detected shifts/blocks:' : 'Detected periods:'}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-sky-500/20 text-sky-300 font-mono font-bold text-xs border border-sky-500/30">
                      {totalSelectedCount} of {extractedSlots.length} selected
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Daily Start Time */}
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      {isJobMode ? 'Earliest Shift Start' : 'Earliest Class Start'}
                    </label>
                    <input
                      type="time"
                      value={extractedStartTime}
                      onChange={(e) => setExtractedStartTime(e.target.value)}
                      className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs font-mono focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  {/* Daily End Time */}
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      {isJobMode ? 'Latest Shift End' : 'Latest Class End'}
                    </label>
                    <input
                      type="time"
                      value={extractedEndTime}
                      onChange={(e) => setExtractedEndTime(e.target.value)}
                      className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs font-mono focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  {/* Active Days Toggle */}
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      {isJobMode ? 'Work Operating Days' : 'College Operating Days'}
                    </label>
                    <div className="flex items-center gap-1">
                      {WEEKDAYS.map((w) => {
                        const isActive = extractedActiveDays.includes(w.day);
                        return (
                          <button
                            key={w.day}
                            type="button"
                            onClick={() => handleToggleDayActive(w.day)}
                            className={`w-7 h-7 rounded text-[10px] font-bold transition-all ${
                              isActive
                                ? 'bg-sky-600 text-white shadow-sm'
                                : 'bg-slate-900 text-slate-500 hover:text-white border border-slate-800'
                            }`}
                            title={w.name}
                          >
                            {w.short[0]}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>

              {/* Day Tabs */}
              <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2">
                <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
                  {WEEKDAYS.map((w) => {
                    const isCurrentTab = reviewDayTab === w.day;
                    const daySlotCount = extractedSlots.filter((s) => s.day === w.day).length;

                    return (
                      <button
                        key={w.day}
                        onClick={() => setReviewDayTab(w.day)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all shrink-0 ${
                          isCurrentTab
                            ? 'bg-sky-600 text-white shadow-md shadow-sky-600/30'
                            : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                        }`}
                      >
                        <span>{w.name}</span>
                        <span
                          className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                            isCurrentTab
                              ? 'bg-sky-800 text-white'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {daySlotCount}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <button
                  type="button"
                  onClick={() => handleAddCustomSlot(reviewDayTab)}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs rounded-lg bg-sky-950/60 border border-sky-500/30 text-sky-300 hover:bg-sky-900/60 transition-colors shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isJobMode ? 'Add Shift / Meeting' : 'Add Class'}</span>
                </button>
              </div>

              {/* Extracted Slots List for active day */}
              <div className="space-y-2.5">
                {filteredSlotsForTab.length === 0 ? (
                  <div className="text-center py-8 rounded-xl border border-dashed border-slate-800 bg-slate-950/50">
                    <p className="text-xs text-slate-400">
                      No {isJobMode ? 'shifts or meetings' : 'periods'} found for{' '}
                      {WEEKDAYS.find((w) => w.day === reviewDayTab)?.name}.
                    </p>
                    <button
                      type="button"
                      onClick={() => handleAddCustomSlot(reviewDayTab)}
                      className="mt-2 text-xs text-sky-400 hover:underline font-semibold"
                    >
                      + Add a {isJobMode ? 'shift / meeting' : 'class'} for this day
                    </button>
                  </div>
                ) : (
                  filteredSlotsForTab.map((slot) => {
                    const duration = calculateDurationMinutes(slot.startTime, slot.endTime);

                    return (
                      <div
                        key={slot.id}
                        className={`p-3.5 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                          slot.selected
                            ? 'bg-slate-950/90 border-slate-800 hover:border-slate-700'
                            : 'bg-slate-950/40 border-slate-900 opacity-60'
                        }`}
                      >
                        {/* Checkbox & Basic Info */}
                        <div className="flex items-start gap-3 min-w-0">
                          <input
                            type="checkbox"
                            checked={slot.selected}
                            onChange={() => handleToggleSlotSelect(slot.id)}
                            className="w-4 h-4 rounded mt-1 bg-slate-900 border-slate-700 text-sky-500 focus:ring-0 cursor-pointer"
                            title="Include in schedule"
                          />

                          <div className="min-w-0 space-y-1">
                            <input
                              type="text"
                              value={slot.name}
                              onChange={(e) => {
                                const val = e.target.value;
                                setExtractedSlots((prev) =>
                                  prev.map((s) => (s.id === slot.id ? { ...s, name: val } : s))
                                );
                              }}
                              className="font-bold text-white text-xs bg-slate-900/60 px-2 py-0.5 rounded border border-transparent focus:border-sky-500 focus:outline-none w-full sm:w-64"
                              placeholder={
                                isJobMode ? 'Shift / Meeting / Work Block' : 'Subject / Period Name'
                              }
                            />

                            <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
                              <span className="font-mono text-sky-300 font-medium">
                                {formatTime12h(slot.startTime)} – {formatTime12h(slot.endTime)} ({duration}m)
                              </span>

                              {slot.room && (
                                <span className="bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800 text-slate-300">
                                  {isJobMode ? 'Loc:' : 'Room:'} {slot.room}
                                </span>
                              )}

                              {slot.professor && (
                                <span className="text-slate-400 italic">
                                  {isJobMode ? 'Lead:' : 'Prof:'} {slot.professor}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Timing, Type and Delete */}
                        <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                          <input
                            type="time"
                            value={slot.startTime}
                            onChange={(e) => {
                              const val = e.target.value;
                              setExtractedSlots((prev) =>
                                prev.map((s) => (s.id === slot.id ? { ...s, startTime: val } : s))
                              );
                            }}
                            className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-white font-mono"
                          />

                          <span className="text-slate-500 text-xs">–</span>

                          <input
                            type="time"
                            value={slot.endTime}
                            onChange={(e) => {
                              const val = e.target.value;
                              setExtractedSlots((prev) =>
                                prev.map((s) => (s.id === slot.id ? { ...s, endTime: val } : s))
                              );
                            }}
                            className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-white font-mono"
                          />

                          <select
                            value={slot.type}
                            onChange={(e) => {
                              const val = e.target.value as SlotType;
                              setExtractedSlots((prev) =>
                                prev.map((s) => (s.id === slot.id ? { ...s, type: val } : s))
                              );
                            }}
                            className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-slate-300"
                          >
                            <option value="lecture">Lecture</option>
                            <option value="lab">Lab</option>
                            <option value="tutorial">Tutorial</option>
                            <option value="shift">Work Shift</option>
                            <option value="meeting">Meeting</option>
                            <option value="deep_work">Deep Work</option>
                            <option value="break">Break</option>
                          </select>

                          <button
                            type="button"
                            onClick={() => handleDeleteSlot(slot.id)}
                            className="p-1 rounded text-slate-500 hover:text-rose-400 hover:bg-slate-900 transition-colors"
                            title="Delete slot"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Assignment Options */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                  Schedule Assignment Preferences:
                </span>

                <div className="p-3 rounded-lg bg-sky-950/40 border border-sky-800/50 flex items-start gap-2.5 text-xs">
                  <ShieldCheck className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                  <div className="text-slate-300 text-[11px] leading-relaxed">
                    <strong className="text-sky-300 block">
                      {isJobMode
                        ? 'Anchored as Protected Workplace / Job Hours:'
                        : 'Anchored as Fixed College Timetable:'}
                    </strong>
                    {isJobMode
                      ? 'Your work shifts and meetings are locked into your weekly capacity radar so your personal routine stays 100% focused on your after-work goals.'
                      : 'Classes are saved to your weekly timetable as protected fixed tasks so your daily routine stays 100% focused on your skill upgrades.'}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center gap-4 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="radio"
                      name="replaceMerge"
                      checked={replaceExisting}
                      onChange={() => setReplaceExisting(true)}
                      className="text-sky-500 focus:ring-0"
                    />
                    <span>
                      Replace current {isJobMode ? 'work schedule' : 'college timetable'}
                    </span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                    <input
                      type="radio"
                      name="replaceMerge"
                      checked={!replaceExisting}
                      onChange={() => setReplaceExisting(false)}
                      className="text-sky-500 focus:ring-0"
                    />
                    <span>Merge with existing schedule</span>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between shrink-0">
          {step === 'upload' ? (
            <>
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <ClipboardPaste className="w-4 h-4 text-sky-400" />
                <span>Tip: Press Ctrl+V anywhere to paste & auto-scan a screenshot</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={!selectedFile || isAnalyzing}
                  onClick={handleStartAnalysis}
                  className={`flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-semibold text-white shadow-lg transition-all ${
                    !selectedFile || isAnalyzing
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      : 'bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 shadow-sky-600/30 hover:scale-[1.02]'
                  }`}
                >
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Turbo Scanning...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5 text-amber-300" />
                      <span>Scan Schedule Now</span>
                    </>
                  )}
                </button>
              </div>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setStep('upload')}
                className="text-xs text-slate-400 hover:text-white font-medium"
              >
                ← Scan Another Document
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-800 transition-colors"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  onClick={handleApply}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/30 transition-all hover:scale-[1.02]"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    Assign to {isJobMode ? 'Work Schedule' : 'College Schedule'} ({totalSelectedCount}{' '}
                    {isJobMode ? 'Shifts' : 'Classes'})
                  </span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
