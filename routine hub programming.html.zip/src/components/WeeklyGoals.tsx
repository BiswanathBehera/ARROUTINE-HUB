import React, { useState, useMemo } from 'react';
import {
  Target,
  Plus,
  CheckCircle2,
  Circle,
  ChevronDown,
  ChevronUp,
  Award,
  Sparkles,
  TrendingUp,
  MoreVertical,
  Edit2,
  Trash2,
  RotateCcw,
  Check,
  Calendar,
  Layers,
  Flag,
  ListChecks,
} from 'lucide-react';
import { WeeklyGoal, TaskCategory, WeeklyGoalMilestone } from '../types/routine';
import { CATEGORIES } from '../utils/categories';
import { getWeekRange } from '../utils/dateUtils';
import { sounds } from '../utils/audio';

interface WeeklyGoalsProps {
  goals: WeeklyGoal[];
  onUpdateGoals: (goals: WeeklyGoal[]) => void;
  onOpenAddGoal: () => void;
  onEditGoal: (goal: WeeklyGoal) => void;
  selectedDate: string;
  soundEnabled?: boolean;
}

export const WeeklyGoals: React.FC<WeeklyGoalsProps> = ({
  goals,
  onUpdateGoals,
  onOpenAddGoal,
  onEditGoal,
  selectedDate,
  soundEnabled = true,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'all' | 'active' | 'completed' | TaskCategory>('all');
  const [expandedGoalIds, setExpandedGoalIds] = useState<Set<string>>(() => new Set());
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const weekInfo = useMemo(() => getWeekRange(selectedDate), [selectedDate]);

  // Overall progress statistics
  const stats = useMemo(() => {
    const total = goals.length;
    if (total === 0) return { total: 0, completed: 0, percentage: 0 };
    const completed = goals.filter((g) => g.completed || g.currentValue >= g.targetValue).length;
    const percentage = Math.round((completed / total) * 100);
    return { total, completed, percentage };
  }, [goals]);

  // Filtered goals
  const filteredGoals = useMemo(() => {
    return goals.filter((g) => {
      const isDone = g.completed || g.currentValue >= g.targetValue;
      if (activeFilter === 'all') return true;
      if (activeFilter === 'active') return !isDone;
      if (activeFilter === 'completed') return isDone;
      return g.category === activeFilter;
    });
  }, [goals, activeFilter]);

  // Step increment / decrement progress
  const handleStepProgress = (goalId: string, delta: number) => {
    onUpdateGoals(
      goals.map((g) => {
        if (g.id !== goalId) return g;
        const nextVal = Math.max(0, g.currentValue + delta);
        const wasCompleted = g.completed || g.currentValue >= g.targetValue;
        const nowCompleted = nextVal >= g.targetValue;

        if (!wasCompleted && nowCompleted && soundEnabled) {
          sounds.playComplete();
        } else if (soundEnabled && delta > 0) {
          sounds.playNotificationPing();
        }

        return {
          ...g,
          currentValue: nextVal,
          completed: nowCompleted,
        };
      })
    );
  };

  // Toggle goal completed directly
  const handleToggleCompleted = (goalId: string) => {
    onUpdateGoals(
      goals.map((g) => {
        if (g.id !== goalId) return g;
        const nextState = !g.completed;
        const nextVal = nextState ? Math.max(g.currentValue, g.targetValue) : g.currentValue;

        if (nextState && soundEnabled) {
          sounds.playComplete();
        }

        return {
          ...g,
          completed: nextState,
          currentValue: nextVal,
        };
      })
    );
  };

  // Toggle milestone checkbox
  const handleToggleMilestone = (goalId: string, milestoneId: string) => {
    onUpdateGoals(
      goals.map((g) => {
        if (g.id !== goalId || !g.milestones) return g;

        const nextMilestones = g.milestones.map((m) =>
          m.id === milestoneId ? { ...m, completed: !m.completed } : m
        );

        // Optionally synchronize currentValue with number of completed milestones
        const completedMilestones = nextMilestones.filter((m) => m.completed).length;
        const nowCompleted = completedMilestones >= g.targetValue;

        if (nowCompleted && !g.completed && soundEnabled) {
          sounds.playComplete();
        } else if (soundEnabled) {
          sounds.playNotificationPing();
        }

        return {
          ...g,
          milestones: nextMilestones,
          currentValue: Math.max(g.currentValue, completedMilestones),
          completed: nowCompleted || g.completed,
        };
      })
    );
  };

  const handleDeleteGoal = (goalId: string) => {
    if (window.confirm('Are you sure you want to remove this weekly objective?')) {
      onUpdateGoals(goals.filter((g) => g.id !== goalId));
      setActiveMenuId(null);
    }
  };

  const handleResetProgress = (goalId: string) => {
    onUpdateGoals(
      goals.map((g) => {
        if (g.id !== goalId) return g;
        return {
          ...g,
          currentValue: 0,
          completed: false,
          milestones: g.milestones?.map((m) => ({ ...m, completed: false })),
        };
      })
    );
    setActiveMenuId(null);
  };

  const toggleExpand = (goalId: string) => {
    setExpandedGoalIds((prev) => {
      const next = new Set(prev);
      if (next.has(goalId)) {
        next.delete(goalId);
      } else {
        next.add(goalId);
      }
      return next;
    });
  };

  // Distinct categories present in goals
  const availableCategories = useMemo(() => {
    const cats = new Set(goals.map((g) => g.category));
    return Array.from(cats);
  }, [goals]);

  return (
    <div className="bg-slate-900/60 backdrop-blur-xl border border-slate-800/80 rounded-2xl p-5 shadow-2xl transition-all relative">
      
      {/* Top Banner & Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-indigo-500/20 to-violet-500/10 border border-indigo-500/30 text-indigo-400 shrink-0">
            <Target className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
                Weekly Goals & Long-Term Objectives
              </h2>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-500/15 border border-indigo-500/30 text-indigo-300">
                <Calendar className="w-3 h-3" />
                {weekInfo.formattedRange}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Track multi-day targets for programming, trading, video editing, study hours, and workouts
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 self-start md:self-auto">
          <button
            onClick={onOpenAddGoal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-600/20 transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Objective</span>
          </button>

          <button
            onClick={() => setIsCollapsed((prev) => !prev)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition-colors"
            title={isCollapsed ? 'Expand Weekly Goals' : 'Collapse Weekly Goals'}
          >
            {isCollapsed ? (
              <>
                <span>Expand</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </>
            ) : (
              <>
                <span>Collapse</span>
                <ChevronUp className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      </div>

      {/* Aggregate Weekly Progress Bar */}
      <div className="mt-4 bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center">
            <Award
              className={`w-5 h-5 ${
                stats.percentage === 100
                  ? 'text-amber-400 animate-bounce'
                  : stats.percentage >= 60
                  ? 'text-indigo-400'
                  : 'text-slate-500'
              }`}
            />
          </div>
          <div>
            <div className="text-xs font-semibold text-white flex items-center gap-1.5">
              <span>Weekly Completion:</span>
              <span className="text-indigo-400 font-mono">
                {stats.completed} of {stats.total} Goals
              </span>
              <span className="text-slate-400 font-normal">({stats.percentage}%)</span>
            </div>
            <p className="text-[11px] text-slate-400">
              {stats.percentage === 100
                ? '🏆 Outstanding work! All weekly objectives crushed.'
                : stats.percentage >= 60
                ? '🚀 Strong momentum! On track to finish all targets.'
                : '🎯 Stay consistent! Every daily routine session counts.'}
            </p>
          </div>
        </div>

        {/* Progress Gauge */}
        <div className="w-full sm:w-60 flex flex-col gap-1">
          <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                stats.percentage === 100
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                  : stats.percentage >= 60
                  ? 'bg-gradient-to-r from-indigo-500 to-violet-400'
                  : 'bg-gradient-to-r from-amber-500 to-indigo-500'
              }`}
              style={{ width: `${stats.percentage}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-slate-400 font-mono px-0.5">
            <span>0%</span>
            <span>50%</span>
            <span>100% Target</span>
          </div>
        </div>
      </div>

      {/* Collapsible Content */}
      {!isCollapsed && (
        <div className="mt-4 space-y-4">
          
          {/* Filter Pills */}
          <div className="flex items-center justify-between flex-wrap gap-2 pt-1">
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => setActiveFilter('all')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                  activeFilter === 'all'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                All Goals ({goals.length})
              </button>

              <button
                onClick={() => setActiveFilter('active')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                  activeFilter === 'active'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                Active ({goals.filter((g) => !g.completed && g.currentValue < g.targetValue).length})
              </button>

              <button
                onClick={() => setActiveFilter('completed')}
                className={`px-2.5 py-1 text-xs rounded-lg font-medium transition-all ${
                  activeFilter === 'completed'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                Completed ({stats.completed})
              </button>

              {/* Category Filter Pills */}
              <div className="hidden sm:flex items-center gap-1 border-l border-slate-800 pl-2">
                {availableCategories.map((catKey) => {
                  const catInfo = CATEGORIES[catKey];
                  const count = goals.filter((g) => g.category === catKey).length;
                  return (
                    <button
                      key={catKey}
                      onClick={() => setActiveFilter(catKey)}
                      className={`px-2 py-1 text-xs rounded-lg font-medium flex items-center gap-1 transition-all ${
                        activeFilter === catKey
                          ? `${catInfo.badgeBg} ${catInfo.badgeText} border ${catInfo.badgeBorder}`
                          : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                      }`}
                    >
                      <catInfo.icon className="w-3 h-3" />
                      <span>{catInfo.label.split(' ')[0]}</span>
                      <span className="text-[10px] opacity-70 font-mono">({count})</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="text-[11px] text-slate-400">
              Showing {filteredGoals.length} {filteredGoals.length === 1 ? 'objective' : 'objectives'}
            </div>
          </div>

          {/* Goal Cards Grid */}
          {filteredGoals.length === 0 ? (
            <div className="p-8 text-center bg-slate-950/40 rounded-xl border border-dashed border-slate-800">
              <Sparkles className="w-8 h-8 text-indigo-400/60 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-300">No weekly objectives found in this view</p>
              <p className="text-xs text-slate-500 mt-1">
                Click "+ Add Objective" above to define targets for study, trading, video editing, coding, or workouts.
              </p>
              <button
                onClick={onOpenAddGoal}
                className="mt-3 px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Create Weekly Goal</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {filteredGoals.map((goal) => {
                const catInfo = CATEGORIES[goal.category] || CATEGORIES.programming;
                const IconComponent = catInfo.icon;
                const isGoalDone = goal.completed || goal.currentValue >= goal.targetValue;
                const progressPct = Math.min(
                  100,
                  Math.round((goal.currentValue / Math.max(1, goal.targetValue)) * 100)
                );
                const isExpanded = expandedGoalIds.has(goal.id);
                const hasMilestones = goal.milestones && goal.milestones.length > 0;
                const completedMilestones =
                  goal.milestones?.filter((m) => m.completed).length || 0;

                return (
                  <div
                    key={goal.id}
                    className={`group relative rounded-xl border p-4 transition-all ${
                      isGoalDone
                        ? 'bg-emerald-950/20 border-emerald-500/30'
                        : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {/* Top Row: Category, Priority, Options Menu */}
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg text-xs font-medium border ${catInfo.badgeBg} ${catInfo.badgeText} ${catInfo.badgeBorder}`}
                        >
                          <IconComponent className="w-3 h-3" />
                          <span>{catInfo.label}</span>
                        </span>

                        {goal.priority && (
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-md font-semibold uppercase tracking-wider border ${
                              goal.priority === 'high'
                                ? 'bg-rose-500/10 text-rose-300 border-rose-500/20'
                                : goal.priority === 'medium'
                                ? 'bg-amber-500/10 text-amber-300 border-amber-500/20'
                                : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'
                            }`}
                          >
                            {goal.priority}
                          </span>
                        )}

                        {isGoalDone && (
                          <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 font-semibold px-2 py-0.5 rounded-md bg-emerald-500/15 border border-emerald-500/30">
                            <Check className="w-3 h-3" />
                            Completed
                          </span>
                        )}
                      </div>

                      {/* Dropdown Menu Toggle */}
                      <div className="relative">
                        <button
                          onClick={() =>
                            setActiveMenuId(activeMenuId === goal.id ? null : goal.id)
                          }
                          className="p-1 text-slate-500 hover:text-slate-300 rounded-lg hover:bg-slate-800 transition-colors"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </button>

                        {activeMenuId === goal.id && (
                          <div className="absolute right-0 top-6 z-20 w-36 bg-slate-900 border border-slate-700 rounded-xl shadow-xl py-1 text-xs">
                            <button
                              onClick={() => {
                                onEditGoal(goal);
                                setActiveMenuId(null);
                              }}
                              className="w-full px-3 py-1.5 text-left text-slate-300 hover:bg-slate-800 hover:text-white flex items-center gap-2"
                            >
                              <Edit2 className="w-3.5 h-3.5 text-indigo-400" />
                              <span>Edit Goal</span>
                            </button>
                            <button
                              onClick={() => handleResetProgress(goal.id)}
                              className="w-full px-3 py-1.5 text-left text-slate-300 hover:bg-slate-800 hover:text-white flex items-center gap-2"
                            >
                              <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                              <span>Reset to 0</span>
                            </button>
                            <button
                              onClick={() => handleDeleteGoal(goal.id)}
                              className="w-full px-3 py-1.5 text-left text-rose-400 hover:bg-rose-950/50 flex items-center gap-2 border-t border-slate-800"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Delete</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Goal Title & Status */}
                    <div className="flex items-start gap-2.5 my-2">
                      <button
                        type="button"
                        onClick={() => handleToggleCompleted(goal.id)}
                        className="mt-0.5 shrink-0 text-slate-500 hover:text-emerald-400 transition-colors"
                        title={isGoalDone ? 'Mark as active' : 'Mark as complete'}
                      >
                        {isGoalDone ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-500/20" />
                        ) : (
                          <Circle className="w-5 h-5 text-slate-600 hover:text-indigo-400" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0">
                        <h4
                          className={`text-sm font-semibold leading-snug break-words ${
                            isGoalDone ? 'text-slate-300 line-through' : 'text-white'
                          }`}
                        >
                          {goal.title}
                        </h4>

                        {goal.notes && (
                          <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                            {goal.notes}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Progress Numeric & Stepper Bar */}
                    <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400">Progress Tracker:</span>
                        <div className="flex items-center gap-1.5 font-mono">
                          <span
                            className={`font-bold ${
                              isGoalDone ? 'text-emerald-400' : 'text-indigo-300'
                            }`}
                          >
                            {goal.currentValue}
                          </span>
                          <span className="text-slate-500">/</span>
                          <span className="text-slate-300 font-medium">{goal.targetValue}</span>
                          <span className="text-slate-400 text-[11px] ml-0.5">{goal.unit}</span>
                          <span
                            className={`ml-1 text-[11px] font-semibold px-1.5 py-0.2 rounded ${
                              isGoalDone
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : 'bg-slate-800 text-slate-300'
                            }`}
                          >
                            {progressPct}%
                          </span>
                        </div>
                      </div>

                      {/* Progress Bar with Gradient */}
                      <div className="h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                        <div
                          className={`h-full transition-all duration-300 rounded-full ${
                            isGoalDone
                              ? 'bg-emerald-400'
                              : 'bg-gradient-to-r from-indigo-500 to-violet-400'
                          }`}
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>

                      {/* Stepper Buttons for Fast Daily Logging */}
                      <div className="flex items-center justify-between pt-1">
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleStepProgress(goal.id, -1)}
                            disabled={goal.currentValue <= 0}
                            className="px-2 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:opacity-30 disabled:pointer-events-none text-slate-300 hover:text-white border border-slate-800 text-xs font-mono font-medium transition-colors cursor-pointer"
                            title="Decrement progress by 1"
                          >
                            -1 {goal.unit}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleStepProgress(goal.id, 1)}
                            className="px-2.5 py-1 rounded-lg bg-indigo-600/80 hover:bg-indigo-600 text-white text-xs font-mono font-semibold border border-indigo-500/30 transition-all cursor-pointer shadow-sm shadow-indigo-600/20"
                            title="Increment progress by 1"
                          >
                            +1 {goal.unit}
                          </button>
                        </div>

                        {/* Milestone Toggle trigger */}
                        {hasMilestones && (
                          <button
                            type="button"
                            onClick={() => toggleExpand(goal.id)}
                            className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium transition-colors"
                          >
                            <ListChecks className="w-3.5 h-3.5" />
                            <span>
                              {completedMilestones}/{goal.milestones?.length} Steps
                            </span>
                            {isExpanded ? (
                              <ChevronUp className="w-3 h-3" />
                            ) : (
                              <ChevronDown className="w-3 h-3" />
                            )}
                          </button>
                        )}
                      </div>

                      {/* Collapsible Sub-milestones */}
                      {hasMilestones && isExpanded && (
                        <div className="mt-2.5 pt-2.5 border-t border-slate-800/80 space-y-1.5 bg-slate-950/60 p-2.5 rounded-lg">
                          <span className="text-[11px] font-semibold text-slate-400 block mb-1">
                            Checklist Milestones:
                          </span>
                          {goal.milestones?.map((ms) => (
                            <button
                              key={ms.id}
                              type="button"
                              onClick={() => handleToggleMilestone(goal.id, ms.id)}
                              className="w-full flex items-center gap-2 p-1.5 rounded hover:bg-slate-900 text-left transition-colors text-xs"
                            >
                              <CheckCircle2
                                className={`w-3.5 h-3.5 shrink-0 transition-colors ${
                                  ms.completed ? 'text-emerald-400' : 'text-slate-600'
                                }`}
                              />
                              <span
                                className={
                                  ms.completed
                                    ? 'line-through text-slate-500'
                                    : 'text-slate-200'
                                }
                              >
                                {ms.title}
                              </span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
