import React, { useEffect, useState } from 'react';
import {
  X,
  Clock,
  Plus,
  Trash2,
  AlertTriangle,
  Lock,
  Sparkles,
  Lightbulb,
  Tag,
  BookOpen,
  Moon,
} from 'lucide-react';
import { CollegeConfig, Priority, SleepConfig, Task, TaskCategory } from '../types/routine';
import { CATEGORY_LIST } from '../utils/categories';
import {
  calculateDurationMinutes,
  formatDuration,
  formatTime12h,
  isTimeOverlapping,
  minutesToTime,
  timeToMinutes,
} from '../utils/dateUtils';
import { sounds } from '../utils/audio';

interface TaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (task: Omit<Task, 'id'>, existingId?: string) => void;
  taskToEdit?: Task | null;
  collegeConfig: CollegeConfig;
  sleepConfig?: SleepConfig;
  selectedDate: string;
}

export const TaskModal: React.FC<TaskModalProps> = ({
  isOpen,
  onClose,
  onSave,
  taskToEdit,
  collegeConfig,
  sleepConfig,
  selectedDate,
}) => {
  const [title, setTitle] = useState('');
  const [topic, setTopic] = useState('');
  const [learned, setLearned] = useState('');
  const [category, setCategory] = useState<TaskCategory>('study');
  const [startTime, setStartTime] = useState('17:00');
  const [endTime, setEndTime] = useState('18:00');
  const [priority, setPriority] = useState<Priority>('medium');
  const [notes, setNotes] = useState('');
  const [subtasks, setSubtasks] = useState<{ id: string; title: string; completed: boolean }[]>([]);
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');

  // Conflict warning
  const [hasCollegeConflict, setHasCollegeConflict] = useState(false);

  useEffect(() => {
    if (taskToEdit) {
      setTitle(taskToEdit.title);
      setTopic(taskToEdit.topic || '');
      setLearned(taskToEdit.learned || '');
      setCategory(taskToEdit.category);
      setStartTime(taskToEdit.startTime);
      setEndTime(taskToEdit.endTime);
      setPriority(taskToEdit.priority);
      setNotes(taskToEdit.notes || '');
      setSubtasks(taskToEdit.subtasks || []);
    } else {
      // Default to an evening slot outside college hours
      setTitle('');
      setTopic('');
      setLearned('');
      setCategory('study');
      setStartTime('17:00');
      setEndTime('18:00');
      setPriority('medium');
      setNotes('');
      setSubtasks([]);
    }
  }, [taskToEdit, isOpen]);

  // Check overlap with fixed college hours
  useEffect(() => {
    if (collegeConfig.enabled && startTime && endTime) {
      const conflict = isTimeOverlapping(
        startTime,
        endTime,
        collegeConfig.startTime,
        collegeConfig.endTime
      );
      setHasCollegeConflict(conflict);
    } else {
      setHasCollegeConflict(false);
    }
  }, [startTime, endTime, collegeConfig]);

  if (!isOpen) return null;

  const durationMin = calculateDurationMinutes(startTime, endTime);

  const applyDuration = (addedMinutes: number) => {
    const sMin = timeToMinutes(startTime);
    const newEndMin = sMin + addedMinutes;
    setEndTime(minutesToTime(newEndMin));
  };

  const handleResolveConflict = () => {
    // Automatically set start to college endTime and end to +1 hour
    const cEndMin = timeToMinutes(collegeConfig.endTime);
    const newStart = minutesToTime(cEndMin + 15); // 15 mins buffer
    const newEnd = minutesToTime(cEndMin + 75);
    setStartTime(newStart);
    setEndTime(newEnd);
  };

  const handleAddSubtask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubtaskTitle.trim()) return;
    setSubtasks([
      ...subtasks,
      {
        id: `sub-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        title: newSubtaskTitle.trim(),
        completed: false,
      },
    ]);
    setNewSubtaskTitle('');
  };

  const handleRemoveSubtask = (id: string) => {
    setSubtasks(subtasks.filter((s) => s.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onSave(
      {
        title: title.trim(),
        topic: topic.trim() || undefined,
        learned: learned.trim() || undefined,
        category,
        startTime,
        endTime,
        priority,
        completed: taskToEdit ? taskToEdit.completed : false,
        notes: notes.trim(),
        subtasks,
        date: selectedDate,
      },
      taskToEdit?.id ? taskToEdit.id : undefined
    );
    onClose();
  };

  // Quick preset title suggestions by category
  const getSuggestions = () => {
    switch (category) {
      case 'study':
        return ['Math & Calculus Notes', 'DSA Algorithm Revision', 'Prepare Lab Journal', 'Exam Paper Solving'];
      case 'trading':
        return ['Morning Watchlist & Chart Setup', 'Post-Market Journal Review', 'Crypto Support/Resistance Analysis', 'Forex Session'];
      case 'video_editing':
        return ['Trim A-Roll & Cut Timeline', 'Color Grading & LUT Application', 'Sound Design & Audio Ducking', 'YouTube Thumbnail Export'];
      case 'programming':
        return ['Solve 2 LeetCode Mediums', 'Full-Stack Auth Feature', 'Bug Fix & Code Refactor', 'System Design Notes'];
      case 'exercise':
        return ['Full Body Gym Workout', '5km Outdoor Run', 'HIIT & Mobility Stretch', 'Evening Calisthenics'];
      default:
        return ['Daily Review', 'Reading 20 Pages', 'Organize Workdesk'];
    }
  };

  const getTopicSuggestions = () => {
    switch (category) {
      case 'study':
        return ['Binary Trees & AVL', 'Operating Systems Paging', 'Computer Networks TCP/IP', 'Linear Algebra'];
      case 'trading':
        return ['Fair Value Gaps (FVG)', 'Support & Resistance', 'Liquidity Sweep', 'Risk Management 1:2'];
      case 'video_editing':
        return ['Audio Ducking & Levels', 'Jump-Cut Pacing', 'Color Grade LUTs', 'Thumbnail Composition'];
      case 'programming':
        return ['Dynamic Programming', 'Graph BFS/DFS', 'JWT Authentication', 'State Optimization'];
      case 'exercise':
        return ['Progressive Overload', 'Bench Press Path', 'Zone 2 Cardio', 'Shoulder Mobility'];
      default:
        return ['Core Concepts', 'Habit Building', 'Key Learnings'];
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/20 text-indigo-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold text-white tracking-tight">
              {taskToEdit?.id ? 'Edit Routine Task' : 'Add Dynamic Routine Task'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          
          {/* Category Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Select Category
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {CATEGORY_LIST.filter((c) => c.id !== 'college').map((cat) => {
                const Icon = cat.icon;
                const isSelected = category === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCategory(cat.id)}
                    className={`flex items-center gap-2 p-2 rounded-xl border text-xs font-medium transition-all ${
                      isSelected
                        ? `${cat.badgeBg} ${cat.badgeText} border-indigo-500 shadow-sm shadow-indigo-500/20 ring-1 ring-indigo-500`
                        : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" style={{ color: cat.colorHex }} />
                    <span className="truncate">{cat.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Task Title */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Task Title / Routine Name
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. LeetCode DSA, Trading Chart Review, Gym Workout..."
              className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500 transition-colors placeholder:text-slate-600"
            />

            {/* Quick Title Suggestions */}
            <div className="flex flex-wrap items-center gap-1.5 mt-2">
              <span className="text-[10px] text-slate-500">Suggestions:</span>
              {getSuggestions().map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setTitle(s)}
                  className="text-[11px] px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 transition-colors"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* Topic / Subject Input */}
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-indigo-500/20 space-y-2">
            <label className="block text-xs font-semibold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
              Focus Topic / Subject Area (Optional)
            </label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Binary Search Trees, Order Blocks, Jump-cut pacing, Bench Press form..."
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-indigo-500 placeholder:text-slate-600"
            />

            {/* Quick Topic Suggestions */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[10px] text-slate-500">Topic ideas:</span>
              {getTopicSuggestions().map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTopic(t)}
                  className="text-[10px] px-2 py-0.5 rounded-md bg-slate-800 hover:bg-indigo-950/80 text-indigo-200 border border-slate-700/80 transition-colors"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Time Picker & Duration */}
          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-indigo-400" />
                  Start Time
                </label>
                <input
                  type="time"
                  required
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-indigo-400" />
                  End Time
                </label>
                <input
                  type="time"
                  required
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>
            </div>

            {/* Duration shortcuts */}
            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-slate-400 font-mono">
                Duration: <strong className="text-white">{formatDuration(durationMin)}</strong>
              </span>

              <div className="flex items-center gap-1">
                <span className="text-[11px] text-slate-500">Quick set:</span>
                {[30, 45, 60, 90, 120].map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => applyDuration(m)}
                    className="text-[10px] px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
                  >
                    {m < 60 ? `${m}m` : `${m / 60}h`}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* College Conflict Alert Banner */}
          {hasCollegeConflict && (
            <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/50 space-y-2">
              <div className="flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <h5 className="text-xs font-bold text-amber-200">
                    Conflict with Fixed College Hours!
                  </h5>
                  <p className="text-[11px] text-amber-300/80 leading-relaxed mt-0.5">
                    Your college hours are locked from{' '}
                    <strong>
                      {formatTime12h(collegeConfig.startTime)} to{' '}
                      {formatTime12h(collegeConfig.endTime)}
                    </strong>
                    . This task overlaps with college time.
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end">
                <button
                  type="button"
                  onClick={handleResolveConflict}
                  className="text-xs px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 font-semibold transition-colors flex items-center gap-1"
                >
                  <Lock className="w-3 h-3 text-amber-400" />
                  Auto-reschedule after College ({formatTime12h(collegeConfig.endTime)})
                </button>
              </div>
            </div>
          )}

          {/* Sleep Window Overlap Warning */}
          {(sleepConfig?.enabled ?? true) &&
            (timeToMinutes(startTime) < timeToMinutes(sleepConfig?.wakeTime || '05:30') ||
              timeToMinutes(endTime) > timeToMinutes(sleepConfig?.bedTime || '22:30') ||
              timeToMinutes(startTime) >= timeToMinutes(sleepConfig?.bedTime || '22:30')) && (
              <div className="p-3.5 rounded-xl bg-indigo-950/60 border border-indigo-500/40 space-y-2">
                <div className="flex items-start gap-2.5">
                  <Moon className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-xs font-bold text-indigo-200">
                      Restorative Sleep Protection Notice
                    </h5>
                    <p className="text-[11px] text-indigo-300/80 leading-relaxed mt-0.5">
                      Your locked sleep schedule is set from{' '}
                      <strong>
                        {formatTime12h(sleepConfig?.bedTime || '22:30')} to{' '}
                        {formatTime12h(sleepConfig?.wakeTime || '05:30')}
                      </strong>{' '}
                      (7h rest). Scheduling tasks in sleep hours can impact daily energy and recovery.
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-end">
                  <button
                    type="button"
                    onClick={() => {
                      setEndTime(sleepConfig?.bedTime || '22:30');
                    }}
                    className="text-xs px-2.5 py-1 rounded-lg bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-200 border border-indigo-500/40 font-semibold transition-colors flex items-center gap-1"
                  >
                    <Moon className="w-3 h-3 text-indigo-400" />
                    Snap End Time to Bedtime ({formatTime12h(sleepConfig?.bedTime || '22:30')})
                  </button>
                </div>
              </div>
            )}

          {/* Priority */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Priority
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['low', 'medium', 'high'] as Priority[]).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPriority(p)}
                  className={`py-2 text-xs font-semibold rounded-xl border uppercase tracking-wider transition-all ${
                    priority === p
                      ? p === 'high'
                        ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                        : p === 'medium'
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                        : 'bg-slate-700 border-slate-500 text-white'
                      : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:bg-slate-800'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* What I Have Learned */}
          <div className="p-3.5 rounded-xl bg-amber-950/20 border border-amber-500/30 space-y-1.5">
            <label className="block text-xs font-semibold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              What I Have Learned / Key Takeaways
            </label>
            <textarea
              rows={3}
              value={learned}
              onChange={(e) => setLearned(e.target.value)}
              placeholder="Record key concepts learned, formulas understood, trade insights, code discoveries, form breakthroughs..."
              className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-amber-500 placeholder:text-slate-600 leading-relaxed"
            />
            <p className="text-[10px] text-amber-400/80">
              Tip: Log your discoveries after completing the task to retain what you've studied!
            </p>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Routine Notes / Goals (Optional)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Focus on candlestick patterns, complete Chapter 4, 3 sets of bench..."
              className="w-full px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs focus:outline-none focus:border-indigo-500 transition-colors placeholder:text-slate-600"
            />
          </div>

          {/* Checklist / Subtasks */}
          <div className="space-y-2">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Action Checklist / Subtasks ({subtasks.length})
            </label>

            <div className="flex gap-2">
              <input
                type="text"
                value={newSubtaskTitle}
                onChange={(e) => setNewSubtaskTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddSubtask(e);
                  }
                }}
                placeholder="Add checklist step..."
                className="flex-1 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-white text-xs focus:outline-none focus:border-indigo-500 placeholder:text-slate-600"
              />
              <button
                type="button"
                onClick={handleAddSubtask}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-indigo-300 text-xs font-semibold rounded-lg border border-slate-700 transition-colors flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                Add
              </button>
            </div>

            {subtasks.length > 0 && (
              <div className="space-y-1.5 max-h-32 overflow-y-auto pt-1">
                {subtasks.map((sub) => (
                  <div
                    key={sub.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-950/60 border border-slate-800 text-xs"
                  >
                    <span className="text-slate-200 truncate">{sub.title}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveSubtask(sub.id)}
                      className="text-slate-500 hover:text-rose-400 transition-colors p-0.5 ml-2"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer CTA */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white shadow-md shadow-indigo-600/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              {taskToEdit ? 'Save Changes' : 'Add to Routine'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
